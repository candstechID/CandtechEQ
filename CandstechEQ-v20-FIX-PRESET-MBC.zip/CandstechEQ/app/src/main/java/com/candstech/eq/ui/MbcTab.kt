package com.candstech.eq.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.engine.CandstechEqEngine
import com.candstech.eq.engine.MbcBandState
@Composable
fun MbcTab(engine: CandstechEqEngine, liveSpectrum: FloatArray = FloatArray(0)) {
    val state by engine.state.collectAsState()
    val bands = state.mbcBands
    val bandColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFF8A00))
    val bandRanges = listOf(20.0 to state.mbcCrossoverSub.toDouble(), state.mbcCrossoverSub.toDouble() to state.mbcCrossoverLowMid.toDouble(), state.mbcCrossoverLowMid.toDouble() to state.mbcCrossoverHigh.toDouble(), state.mbcCrossoverHigh.toDouble() to 20000.0)
    fun updateBand(idx: Int, fn: (MbcBandState) -> MbcBandState) {
        val list = bands.toMutableList()
        if (idx in list.indices) { list[idx] = fn(list[idx]); engine.update { st -> st.copy(mbcBands = list) } }
    }
    fun grForBand(idx: Int): Float {
        if (!state.mbcEnabled) return 0f
        val (fLow, fHigh) = bandRanges[idx]
        var sum = 0f; var n = 0
        for (i in liveSpectrum.indices) {
            val freq = 20.0 * Math.pow(20000.0 / 20.0, i.toDouble() / 32.0)
            if (freq in fLow..fHigh) { sum += liveSpectrum[i]; n++ }
        }
        if (n == 0) return 0f
        val avg = sum / n
        val levelDb = avg * 40f - 40f
        val band = bands.getOrNull(idx) ?: return 0f
        if (!band.enabled) return 0f
        val over = (levelDb - band.thresholdDb).coerceAtLeast(0f)
        return (over * (1f - 1f / band.ratio.coerceAtLeast(1f))).coerceIn(0f, 20f)
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Multiband Compressor - 4 Band", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Sub / LowMid / Mid / Hi dikompres terpisah. Masing-masing ada Gain sendiri. REAL ke DynamicsProcessing MBC 4 band.", color = CandstechColors.Grey, fontSize = 13.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Multiband Compressor", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                        Text(if (state.mbcEnabled) "AKTIF - 4 band jalan" else "NONAKTIF", color = if (state.mbcEnabled) CandstechColors.Yellow else CandstechColors.Grey, fontSize = 12.sp)
                    }
                    Switch(checked = state.mbcEnabled, onCheckedChange = { newVal -> engine.update { st -> st.copy(mbcEnabled = newVal) } }, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
                }
            }
        }
        item {
            Text("Preset cepat", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Vokal" to listOf(MbcBandState("Sub", true, -26f, 2f, 15f, 120f, -1f), MbcBandState("LowMid", true, -18f, 2.5f, 10f, 100f, 0f), MbcBandState("Mid", true, -16f, 3f, 8f, 90f, 0.5f), MbcBandState("Hi", true, -20f, 2f, 5f, 80f, 0f)),
                    "Drum" to listOf(MbcBandState("Sub", true, -14f, 4f, 5f, 80f, 1f), MbcBandState("LowMid", true, -16f, 3f, 8f, 90f, 0f), MbcBandState("Mid", true, -18f, 3f, 8f, 90f, 0f), MbcBandState("Hi", true, -18f, 3f, 5f, 70f, 0f)),
                    "Mastering" to listOf(MbcBandState("Sub", true, -12f, 2f, 20f, 200f, 0f), MbcBandState("LowMid", true, -12f, 2f, 15f, 180f, 0f), MbcBandState("Mid", true, -12f, 2f, 15f, 180f, 0f), MbcBandState("Hi", true, -14f, 1.8f, 10f, 150f, 0f))
                ).forEach { (name, preset) ->
                    Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(CandstechColors.Card).clickable { engine.update { st -> st.copy(mbcBands = preset, mbcEnabled = true) } }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(name, color = CandstechColors.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Crossover Sub / LowMid  ${state.mbcCrossoverSub.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverSub, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverSub = newVal) } }, valueRange = 60f..250f, colors = SliderDefaults.colors(thumbColor = Color(0xFFAA55FF), activeTrackColor = Color(0xFFAA55FF), inactiveTrackColor = CandstechColors.CardBorder))
                    Text("Crossover LowMid / Mid  ${state.mbcCrossoverLowMid.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverLowMid, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverLowMid = newVal) } }, valueRange = 250f..2000f, colors = SliderDefaults.colors(thumbColor = Color(0xFF4AA8FF), activeTrackColor = Color(0xFF4AA8FF), inactiveTrackColor = CandstechColors.CardBorder))
                    Text("Crossover Mid / Hi  ${state.mbcCrossoverHigh.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverHigh, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverHigh = newVal) } }, valueRange = 1000f..12000f, colors = SliderDefaults.colors(thumbColor = Color(0xFFFF8A00), activeTrackColor = Color(0xFFFF8A00), inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        items(bands.size) { idx ->
            val band = bands[idx]; val col = bandColors[idx]
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(col))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${band.name}  (${bandRanges[idx].first.toInt()} - ${bandRanges[idx].second.toInt()} Hz)", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                            Text(if (band.enabled) "Aktif" else "Bypass", color = if (band.enabled) col else CandstechColors.Grey, fontSize = 12.sp)
                        }
                        Switch(checked = band.enabled, onCheckedChange = { newVal -> updateBand(idx) { oldBand -> oldBand.copy(enabled = newVal) } }, colors = SwitchDefaults.colors(checkedTrackColor = col, checkedThumbColor = CandstechColors.Black))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val gr = grForBand(idx)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("GR (estimasi)", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(modifier = Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF2A2A2A))) {
                            Box(modifier = Modifier.fillMaxHeight().fillMaxWidth((gr / 20f).coerceIn(0f, 1f)).background(Color(0xFFFF5252)))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("-${"%.1f".format(gr)} dB", color = if (gr > 0.5f) Color(0xFFFF5252) else CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    MbcSlider("Threshold  ${"%.0f".format(band.thresholdDb)} dB", band.thresholdDb, -40f..0f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(thresholdDb = newVal) } }
                    MbcSlider("Ratio  ${"%.1f".format(band.ratio)} : 1", band.ratio, 1f..10f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(ratio = newVal) } }
                    MbcSlider("Attack  ${"%.0f".format(band.attackMs)} ms", band.attackMs, 1f..100f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(attackMs = newVal) } }
                    MbcSlider("Release  ${"%.0f".format(band.releaseMs)} ms", band.releaseMs, 10f..500f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(releaseMs = newVal) } }
                    MbcSlider("Gain  ${"%.1f".format(band.gainDb)} dB", band.gainDb, -6f..6f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(gainDb = newVal) } }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}
@Composable
fun MbcSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, col: Color, onChange: (Float) -> Unit) {
    Column {
        Text(label, color = CandstechColors.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Slider(value = value, onValueChange = onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = col, activeTrackColor = col, inactiveTrackColor = CandstechColors.CardBorder))
    }
}
