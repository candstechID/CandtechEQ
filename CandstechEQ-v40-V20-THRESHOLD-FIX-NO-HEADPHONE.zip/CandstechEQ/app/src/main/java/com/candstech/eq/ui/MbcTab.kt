package com.candstech.eq.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.engine.CandstechEqEngine
import com.candstech.eq.engine.MbcBandState
// Level Meter per band - kayak di kompresor hardware: bar hijau-kuning-merah + garis threshold + peak hold putih
@Composable
fun BandLevelMeter(levelDb: Float, thresholdDb: Float, bandColor: Color) {
    var peakHold by remember { mutableStateOf(-90f) }
    // Peak hold: naik langsung, turun pelan 0.4dB per frame (60fps -> ~1 detik balik)
    if (levelDb > peakHold) peakHold = levelDb else peakHold = (peakHold - 0.4f).coerceAtLeast(levelDb).coerceAtLeast(-90f)
    val levelNorm = ((levelDb + 60f) / 60f).coerceIn(0f, 1f)
    val thrNorm = ((thresholdDb + 60f) / 60f).coerceIn(0f, 1f)
    val peakNorm = ((peakHold + 60f) / 60f).coerceIn(0f, 1f)
    val isOver = levelDb > thresholdDb && levelDb > -89f
    val isClip = levelDb > -3f
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("LEVEL METER", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isClip) Text("CLIP!", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (isOver) Text("NGOMPRES", color = bandColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(if (levelDb <= -89f) "-inf dB" else "${"%.1f".format(levelDb)} dB", color = if (isOver) bandColor else CandstechColors.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Box(modifier = Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1A1A1E))) {
            // Bar level - gradient hijau -> kuning -> merah
            if (levelNorm > 0f) {
                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(levelNorm).background(Brush.horizontalGradient(listOf(Color(0xFF00E676), Color(0xFFFFD600), Color(0xFFFF5252)))))
            }
            // Garis skala -40, -20
            Box(modifier = Modifier.fillMaxHeight().width(1.dp).offset(x = 0.dp).background(Color.White.copy(alpha = 0.15f)))
            // Garis threshold - putih tebal, ini patokan kompresor
            Box(modifier = Modifier.fillMaxHeight().width(3.dp).offset(x = 0.dp).background(Color.White))
            // Peak hold - garis putih tipis di puncak
            if (peakHold > -89f) {
                Box(modifier = Modifier.fillMaxHeight().width(2.dp).offset(x = 0.dp).background(Color.White.copy(alpha = 0.9f)))
            }
            // Overlay untuk posisi threshold & peak yang bener pakai BoxWithConstraints tidak bisa di dalam Box biasa, pakai Row dengan weight
            Row(modifier = Modifier.fillMaxSize()) {
                Spacer(modifier = Modifier.weight(thrNorm.coerceIn(0.01f, 0.99f)))
                Box(modifier = Modifier.fillMaxHeight().width(3.dp).background(Color.White))
                Spacer(modifier = Modifier.weight((1f - thrNorm).coerceIn(0.01f, 0.99f)))
            }
            if (peakHold > -89f) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Spacer(modifier = Modifier.weight(peakNorm.coerceIn(0.01f, 0.99f)))
                    Box(modifier = Modifier.fillMaxHeight().width(2.dp).background(Color.White))
                    Spacer(modifier = Modifier.weight((1f - peakNorm).coerceIn(0.01f, 0.99f)))
                }
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("-60", color = CandstechColors.GreyDark, fontSize = 10.sp)
            Text("-40", color = CandstechColors.GreyDark, fontSize = 10.sp)
            Text("-20", color = CandstechColors.GreyDark, fontSize = 10.sp)
            Text("Thr ${"%.0f".format(thresholdDb)}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("0", color = CandstechColors.GreyDark, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(if (levelDb <= -89f) "Hening - tidak ada sinyal di band ini" else if (isOver) "Level di atas threshold (${"%.1f".format(levelDb - thresholdDb)} dB di atas) - lagi ngompres!" else "Level ${"%.1f".format(thresholdDb - levelDb)} dB di bawah threshold - belum ngompres", color = if (isOver) bandColor else CandstechColors.GreyDark, fontSize = 11.sp)
    }
}
@Composable
fun BandGrMeter(grDb: Float) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("GAIN REDUCTION", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("-${"%.1f".format(grDb)} dB", color = if (grDb > 0.5f) Color(0xFFFF5252) else CandstechColors.Grey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Box(modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1A1A1E))) {
            Box(modifier = Modifier.fillMaxHeight().fillMaxWidth((grDb / 20f).coerceIn(0f, 1f)).background(Color(0xFFFF5252)))
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text("GR = (Level - Threshold) x (1 - 1/Ratio). Estimasi dari Level RMS Android.", color = CandstechColors.GreyDark, fontSize = 10.sp)
    }
}
@Composable
fun MbcTab(engine: CandstechEqEngine, liveSpectrum: FloatArray = FloatArray(0)) {
    val state by engine.state.collectAsState()
    val bands = state.mbcBands
    val bandColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFF8A00))
    val bandRanges = listOf(20.0 to state.mbcCrossoverSub.toDouble(), state.mbcCrossoverSub.toDouble() to state.mbcCrossoverLowMid.toDouble(), state.mbcCrossoverLowMid.toDouble() to state.mbcCrossoverHigh.toDouble(), state.mbcCrossoverHigh.toDouble() to 20000.0)
    fun updateBand(idx: Int, fn: (MbcBandState) -> MbcBandState) {
        val list = bands.toMutableList()
        if (idx in list.indices) { list[idx] = fn(list[idx]); engine.update { st -> st.copy(mbcBands = list) } }
    }
    fun levelDbForBand(idx: Int): Float {
        val (fLow, fHigh) = bandRanges[idx]
        var sum = 0f; var n = 0
        for (i in liveSpectrum.indices) {
            val freq = 20.0 * Math.pow(20000.0 / 20.0, i.toDouble() / 32.0)
            if (freq in fLow..fHigh) { sum += liveSpectrum[i]; n++ }
        }
        if (n == 0) return -90f
        val avg = sum / n
        if (avg < 0.01f) return -90f
        return SpectrumAnalyzer.spectrumToDbRms(avg)
    }
    fun grForBand(idx: Int, level: Float): Float {
        if (!state.mbcEnabled) return 0f
        val band = bands.getOrNull(idx) ?: return 0f
        if (!band.enabled) return 0f
        if (level <= -89f) return 0f
        val over = (level - band.thresholdDb).coerceAtLeast(0f)
        return (over * (1f - 1f / band.ratio.coerceAtLeast(1f))).coerceIn(0f, 20f)
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Multiband Compressor - 4 Band", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Level = dB RMS. Garis putih = Threshold.", color = CandstechColors.Grey, fontSize = 12.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Multiband Compressor", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                        Text(if (state.mbcEnabled) "AKTIF - 4 band jalan" else "NONAKTIF", color = if (state.mbcEnabled) CandstechColors.Yellow else CandstechColors.Grey, fontSize = 12.sp)
                    }
                    Switch(checked = state.mbcEnabled, onCheckedChange = { newVal -> engine.update { st -> st.copy(mbcEnabled = newVal) } }, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
                }
            }
        }
        item {
            Text("Preset cepat (skala Android)", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Vokal" to listOf(MbcBandState("Sub", true, -42f, 2f, 15f, 120f, -1f), MbcBandState("LowMid", true, -35f, 2.5f, 10f, 100f, 0f), MbcBandState("Mid", true, -32f, 3f, 8f, 90f, 0.5f), MbcBandState("Hi", true, -38f, 2f, 5f, 80f, 0f)),
                    "Drum" to listOf(MbcBandState("Sub", true, -30f, 4f, 5f, 80f, 1f), MbcBandState("LowMid", true, -32f, 3f, 8f, 90f, 0f), MbcBandState("Mid", true, -34f, 3f, 8f, 90f, 0f), MbcBandState("Hi", true, -34f, 3f, 5f, 70f, 0f)),
                    "Mastering" to listOf(MbcBandState("Sub", true, -25f, 2f, 20f, 200f, 0f), MbcBandState("LowMid", true, -25f, 2f, 15f, 180f, 0f), MbcBandState("Mid", true, -25f, 2f, 15f, 180f, 0f), MbcBandState("Hi", true, -27f, 1.8f, 10f, 150f, 0f))
                ).forEach { (name, preset) ->
                    Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(CandstechColors.Card).clickable { engine.update { st -> st.copy(mbcBands = preset, mbcEnabled = true) } }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(name, color = CandstechColors.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Crossover Sub / LowMid  ${state.mbcCrossoverSub.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverSub, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverSub = newVal) } }, valueRange = 60f..250f, colors = SliderDefaults.colors(thumbColor = Color(0xFFAA55FF), activeTrackColor = Color(0xFFAA55FF), inactiveTrackColor = CandstechColors.CardBorder))
                    Text("Crossover LowMid / Mid  ${state.mbcCrossoverLowMid.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverLowMid, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverLowMid = newVal) } }, valueRange = 250f..2000f, colors = SliderDefaults.colors(thumbColor = Color(0xFF4AA8FF), activeTrackColor = Color(0xFF4AA8FF), inactiveTrackColor = CandstechColors.CardBorder))
                    Text("Crossover Mid / Hi  ${state.mbcCrossoverHigh.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(value = state.mbcCrossoverHigh, onValueChange = { newVal -> engine.update { st -> st.copy(mbcCrossoverHigh = newVal) } }, valueRange = 1000f..12000f, colors = SliderDefaults.colors(thumbColor = Color(0xFFFF8A00), activeTrackColor = Color(0xFFFF8A00), inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        items(bands.size) { idx ->
            val band = bands[idx]; val col = bandColors[idx]
            val level = levelDbForBand(idx)
            val gr = grForBand(idx, level)
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(col))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${band.name}  (${bandRanges[idx].first.toInt()} - ${bandRanges[idx].second.toInt()} Hz)", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                            Text(if (band.enabled) "Aktif" else "Bypass", color = if (band.enabled) col else CandstechColors.Grey, fontSize = 12.sp)
                        }
                        Switch(checked = band.enabled, onCheckedChange = { newVal -> updateBand(idx) { oldBand -> oldBand.copy(enabled = newVal) } }, colors = SwitchDefaults.colors(checkedTrackColor = col, checkedThumbColor = CandstechColors.Black))
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    // LEVEL METER PER BAND - INI YANG BARU
                    BandLevelMeter(levelDb = level, thresholdDb = band.thresholdDb, bandColor = col)
                    Spacer(modifier = Modifier.height(10.dp))
                    BandGrMeter(grDb = gr)
                    Spacer(modifier = Modifier.height(12.dp))
                    MbcSlider("Threshold  ${"%.0f".format(band.thresholdDb)} dB  (Android RMS, -60..0)", band.thresholdDb, -60f..0f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(thresholdDb = newVal) } }
                    MbcSlider("Ratio  ${"%.1f".format(band.ratio)} : 1", band.ratio, 1f..10f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(ratio = newVal) } }
                    MbcSlider("Attack  ${"%.0f".format(band.attackMs)} ms", band.attackMs, 1f..100f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(attackMs = newVal) } }
                    MbcSlider("Release  ${"%.0f".format(band.releaseMs)} ms", band.releaseMs, 10f..500f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(releaseMs = newVal) } }
                    MbcSlider("Gain  ${"%.1f".format(band.gainDb)} dB", band.gainDb, -6f..6f, col) { newVal -> updateBand(idx) { oldBand -> oldBand.copy(gainDb = newVal) } }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(12.dp)) }
    }
}
@Composable
fun MbcSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, col: Color, onChange: (Float) -> Unit) {
    Column {
        Text(label, color = CandstechColors.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Slider(value = value, onValueChange = onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = col, activeTrackColor = col, inactiveTrackColor = CandstechColors.CardBorder))
    }
}
