package com.candstech.eq.ui

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.Visualizer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*
/**
 * Spectrum v25 - FIX ABU-ABU NAIK FLAT
 * Masalah: abu-abu naiknya rata kayak garis lurus, bukan jagged kayak gunung.
 * Penyebab: smoothing 0.85/0.90 + pow 0.7 + range sempit bikin semua band ke-rata-rata.
 * Fix v25:
 * - Pow 0.5 (kontras tajem), range -85..-15 (lebih lebar)
 * - Pink boost: treble diboost 1.0 -> 1.9 biar tidak keliatan datar rendah
 * - Smoothing: attack 0.95 (instan), release 0.82 (cepat) -> tiap band beda, tidak rata
 * - Deteksi datar: kalau max-min < 0.08 padahal ada sinyal, kasih status DATAR
 */
class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val _status = MutableStateFlow("MENUNGGU IZIN")
    val status: StateFlow<String> = _status
    private val smoothed = FloatArray(32) { 0f }
    private var running = false
    private var usingMic = false
    private var micJob: Job? = null
    private var monitorJob: Job? = null
    private var zeroFrames = 0
    private var scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    fun start() {
        if (running) return
        running = true
        usingMic = false
        _status.value = "MENCOBA VISUALIZER..."
        tryStartVisualizer()
        monitorJob = scope.launch {
            while (running) {
                delay(500)
                val isSilent = _spectrum.value.all { it < 0.02f }
                if (isSilent && !usingMic) {
                    zeroFrames++
                    if (zeroFrames >= 6) {
                        _status.value = "VISUALIZER HENING - PINDAH KE MIC..."
                        startMicFallback()
                    }
                } else {
                    zeroFrames = 0
                    if (!usingMic && _spectrum.value.any { it > 0.02f }) _status.value = "LIVE - VISUALIZER"
                }
            }
        }
    }
    fun restart() {
        stop()
        scope.launch { delay(300); start() }
    }
    private fun tryStartVisualizer() {
        try {
            try { visualizer?.enabled = false } catch (_: Exception) {}
            try { visualizer?.release() } catch (_: Exception) {}
            val vis = Visualizer(0)
            vis.captureSize = Visualizer.getCaptureSizeRange()[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) onFftVisualizer(fft, rate)
                }
            }, 60, false, true)
            vis.enabled = true
            visualizer = vis
            usingMic = false
            _status.value = "VISUALIZER JALAN - MENUNGGU LAGU..."
        } catch (e: Exception) {
            _status.value = "VISUALIZER GAGAL - PINDAH KE MIC"
            startMicFallback()
        }
    }
    private fun onFftVisualizer(fft: ByteArray, samplingRate: Int) {
        if (usingMic) return
        val binCount = fft.size / 2
        if (binCount < 2) return
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0
        val out = FloatArray(32)
        var anySignal = false
        for (band in 0 until 32) {
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            val binLow = ((fLow / nyquist) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / nyquist) * binCount).toInt().coerceIn(binLow + 1, binCount)
            var peak = 0.0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toDouble(); val im = fft[b * 2 + 1].toDouble()
                val mag = sqrt(re * re + im * im)
                if (mag > peak) peak = mag
            }
            if (peak < 1.0) { smoothed[band] = smoothed[band] * 0.82f; out[band] = smoothed[band]; continue }
            anySignal = true
            val db = 20.0 * log10(peak / 128.0)
            // v25: range lebar -85..-15, pow 0.5 tajem, pink boost
            var v = ((db + 85.0) / 70.0).coerceIn(0.0, 1.0)
            v = v.pow(0.5)
            val bandBoost = 1.0 + (band / 31.0) * 0.9
            v = (v * 1.35 * bandBoost).coerceIn(0.0, 1.0)
            val prev = smoothed[band].toDouble()
            smoothed[band] = if (v > prev) (prev + (v - prev) * 0.95).toFloat() else (prev * 0.82 + v * 0.18).toFloat()
            out[band] = smoothed[band]
        }
        if (anySignal) zeroFrames = 0
        val mn = out.minOrNull() ?: 0f; val mx = out.maxOrNull() ?: 0f
        if (anySignal && (mx - mn) < 0.08f && mx > 0.15f) {
            _status.value = "SPEKTRUM DATAR (naik rata) - coba lagu bass kenceng"
        }
        _spectrum.value = out
    }
    private fun startMicFallback() {
        if (usingMic) return
        usingMic = true
        try { visualizer?.enabled = false } catch (_: Exception) {}
        _status.value = "MIC FALLBACK - Tangkap musik dari speaker"
        micJob?.cancel()
        micJob = scope.launch(Dispatchers.Default) {
            val sampleRate = 44100
            val bufSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(bufSize, 4096))
            } catch (e: Exception) { _status.value = "MIC GAGAL: ${e.message}"; return@launch }
            try {
                rec.startRecording()
                val buf = ShortArray(1024)
                val window = DoubleArray(1024) { i -> 0.54 - 0.46 * cos(2.0 * Math.PI * i / 1023.0) }
                while (running && usingMic) {
                    val read = rec.read(buf, 0, 1024)
                    if (read <= 0) { delay(20); continue }
                    val re = DoubleArray(1024); val im = DoubleArray(1024)
                    for (i in 0 until 1024) { re[i] = (buf[i] / 32768.0) * window[i]; im[i] = 0.0 }
                    fft(re, im)
                    val out = FloatArray(32)
                    for (band in 0 until 32) {
                        val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
                        val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
                        val binLow = ((fLow / (sampleRate / 2.0)) * 512).toInt().coerceIn(1, 511)
                        val binHigh = ((fHigh / (sampleRate / 2.0)) * 512).toInt().coerceIn(binLow + 1, 512)
                        var peak = 0.0
                        for (b in binLow until binHigh) {
                            val mag = sqrt(re[b] * re[b] + im[b] * im[b]) / 512.0
                            if (mag > peak) peak = mag
                        }
                        if (peak < 0.0005) { smoothed[band] = smoothed[band] * 0.82f; out[band] = smoothed[band]; continue }
                        val db = 20.0 * log10(peak + 1e-9)
                        var v = ((db + 65.0) / 55.0).coerceIn(0.0, 1.0)
                        v = v.pow(0.5)
                        val bandBoost = 1.0 + (band / 31.0) * 0.9
                        v = (v * 1.5 * bandBoost).coerceIn(0.0, 1.0)
                        val prev = smoothed[band].toDouble()
                        smoothed[band] = if (v > prev) (prev + (v - prev) * 0.95).toFloat() else (prev * 0.82 + v * 0.18).toFloat()
                        out[band] = smoothed[band]
                    }
                    _spectrum.value = out
                    _status.value = "LIVE - MIC (Visualizer diblokir HP)"
                    delay(16)
                }
            } catch (e: Exception) { _status.value = "MIC ERROR: ${e.message}" }
            finally { try { rec.stop() } catch (_: Exception) {}; try { rec.release() } catch (_: Exception) {} }
        }
    }
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cwr = 1.0; var cwi = 0.0
                for (k in 0 until len / 2) {
                    val uR = re[i + k]; val uI = im[i + k]
                    val vR = re[i + k + len / 2] * cwr - im[i + k + len / 2] * cwi
                    val vI = re[i + k + len / 2] * cwi + im[i + k + len / 2] * cwr
                    re[i + k] = uR + vR; im[i + k] = uI + vI
                    re[i + k + len / 2] = uR - vR; im[i + k + len / 2] = uI - vI
                    val nwr = cwr * wr - cwi * wi; val nwi = cwr * wi + cwi * wr; cwr = nwr; cwi = nwi
                }
                i += len
            }
            len = len shl 1
        }
    }
    fun stop() {
        running = false
        micJob?.cancel(); monitorJob?.cancel()
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }
    companion object {
        fun spectrumToDbRms(v: Float): Float {
            if (v < 0.01f) return -90f
            val dbPeak = (Math.pow(v.toDouble(), 1.0 / 0.7) * 70.0 - 75.0).toFloat()
            return dbPeak - 12f
        }
    }
}
