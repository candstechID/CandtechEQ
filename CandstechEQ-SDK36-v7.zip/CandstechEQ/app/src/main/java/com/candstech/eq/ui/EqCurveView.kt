package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets

/**
 * Kurva EQ - gambar total curve (graphic + parametric + AutoEq) seperti Eigentone.
 * Fader menunjukkan dB sebenarnya di tiap band.
 */
@Composable
fun EqCurveView(
    gains31: FloatArray,
    parametric: List<ParametricFilter>,
    modifier: Modifier = Modifier
) {
    val curve = BiquadFactory.totalCurve(gains31, Presets.FREQ_31, parametric)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CandstechColors.Card)
            .padding(12.dp)
    ) {
        Column {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("KURVA SUARA", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("+12 dB  •  0  •  -12 dB", color = CandstechColors.GreyDark, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Canvas(modifier = Modifier.fillMaxWidth().height(110.dp)) {
                val w = size.width
                val h = size.height
                // grid
                for (i in 0..4) {
                    val y = h * i / 4f
                    drawLine(Color(0xFF2A2A2A), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                }
                // zero line kuning
                drawLine(CandstechColors.Yellow.copy(alpha = 0.35f), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.5f)
                // curve
                val path = Path()
                curve.forEachIndexed { idx, (freq, db) ->
                    val x = (kotlin.math.ln(freq) - kotlin.math.ln(20.0)) / (kotlin.math.ln(20000.0) - kotlin.math.ln(20.0)) * w
                    val y = (h / 2 - (db.coerceIn(-12.0, 12.0) / 12.0 * h / 2)).toFloat()
                    if (idx == 0) path.moveTo(x.toFloat(), y) else path.lineTo(x.toFloat(), y)
                }
                drawPath(
                    path,
                    brush = Brush.horizontalGradient(listOf(CandstechColors.GradientStart, CandstechColors.Yellow, CandstechColors.GradientEnd)),
                    style = Stroke(width = 3f, cap = StrokeCap.Round)
                )
                // fill di bawah kurva
                val fillPath = Path().apply {
                    addPath(path)
                    lineTo(w, h / 2)
                    lineTo(0f, h / 2)
                    close()
                }
                drawPath(fillPath, brush = Brush.verticalGradient(listOf(CandstechColors.Yellow.copy(alpha = 0.18f), Color.Transparent)))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("20", "100", "1k", "10k", "20k").forEach {
                    Text(it, color = CandstechColors.GreyDark, fontSize = 10.sp)
                }
            }
        }
    }
}
