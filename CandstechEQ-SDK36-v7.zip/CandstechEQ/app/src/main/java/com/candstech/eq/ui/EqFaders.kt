package com.candstech.eq.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.Presets

/**
 * Fader EQ vertikal - 10 band default, bisa ganti 15 / 31 di Pengaturan.
 * Geser = ubah gain. Nilai tampil di atas fader.
 */
@Composable
fun EqFaders(
    gains10: List<Float>,
    onGainChange: (Int, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().height(210.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            gains10.forEachIndexed { idx, gain ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(30.dp)
                ) {
                    Text(
                        text = if (gain > 0) "+${"%.0f".format(gain)}" else "%.0f".format(gain),
                        color = if (gain == 0f) CandstechColors.Grey else CandstechColors.Yellow,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    // Slider vertikal disimulasikan dengan Slider + rotasi di versi penuh.
                    // Di sini pakai Slider horizontal yang diputar via Box agar build tetap sederhana.
                    // Untuk produksi, ganti dengan VerticalSlider custom (lihat Eigentone ui/).
                    Slider(
                        value = gain,
                        onValueChange = { onGainChange(idx, it) },
                        valueRange = -15f..15f,
                        steps = 30,
                        colors = SliderDefaults.colors(
                            thumbColor = CandstechColors.Yellow,
                            activeTrackColor = CandstechColors.Yellow,
                            inactiveTrackColor = CandstechColors.CardBorder
                        ),
                        modifier = Modifier.width(110.dp)
                    )
                    Text(
                        text = formatFreq(Presets.FREQ_10[idx]),
                        color = CandstechColors.Grey,
                        fontSize = 9.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "Geser untuk ubah gain. Tap 2x pada fader untuk reset ke 0 dB.",
            color = CandstechColors.GreyDark,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

fun formatFreq(f: Double): String = if (f >= 1000) "${(f / 1000).let { if (it % 1.0 == 0.0) it.toInt().toString() else "%.1f".format(it) }}k" else "${f.toInt()}"
