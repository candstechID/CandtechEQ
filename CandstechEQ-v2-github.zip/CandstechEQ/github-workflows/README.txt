CARA PAKAI:
1. Setelah unzip, rename folder ini dari github-workflows menjadi .github
   Di Windows: klik kanan > Rename > ketik .github
   Di Mac/Linux: mv github-workflows .github
2. Di dalamnya sudah ada folder workflows/ -> jadi .github/workflows/build.yml
3. Push ke GitHub, Actions akan jalan otomatis.

Kalau upload via GitHub Web (tanpa git):
- Di repo, klik Add file > Create new file
- Path: .github/workflows/build.yml
- Paste isi file build.yml dari folder ini
- Commit.
