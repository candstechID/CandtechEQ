# Hearing Check (hook)

Di Eigentone, hearing check adalah:
- Nada murni (sine) di tiap frekuensi, per telinga (kiri / kanan terpisah)
- User menandai ambang dengar (threshold) di tiap frekuensi
- Dari threshold itu dibuat kurva koreksi lembut per-telinga
- Kurva disimpan per pasangan headphone, digambar sebagai kurva per-telinga
- BUKAN tes medis.

Di build Candstech EQ ini, hook-nya sudah ada:
- `HeadphoneTab` di `MainActivity.kt` menampilkan card Hearing Check
- `EqState.parametric` bisa menampung hasil hearing check sebagai filter

Implementasi penuh (untuk fork penuh):
1. Buat `HearingCheckScreen.kt` dengan AudioTrack sine generator
2. Untuk tiap frekuensi [250, 500, 1000, 2000, 4000, 8000] Hz, per telinga:
   - Mainkan tone, user tap "Saya dengar" / slider threshold
   - Simpan threshold dB per frekuensi per telinga
3. Konversi threshold -> ParametricFilter (bell lebar, gain = -threshold yang dinormalisasi)
4. Simpan di `PresetStore` dengan key `hearing_<device>_<ear>`
5. Tampilkan kurva per-telinga di `EqCurveView` (tambah parameter `leftCurve`, `rightCurve`)

Perhatian: jangan klaim sebagai tes medis. Tulis di UI: "Bukan tes medis."
