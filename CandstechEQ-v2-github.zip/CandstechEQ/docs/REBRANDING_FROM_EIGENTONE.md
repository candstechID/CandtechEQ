# Rebranding Eigentone -> Candstech EQ (untuk fork penuh)

Kalau kamu clone repo asli Eigentone dan mau ubah jadi Candstech EQ 100%,
ini daftar yang harus diganti. Build di folder ini sudah menerapkan semuanya
dalam bentuk proyek mandiri, jadi file ini adalah panduan untuk fork penuh.

## 1. Package & ApplicationId

- `io.github.dragjon.eigentone` -> `com.candstech.eq`
- File:
  - `settings.gradle.kts` -> `rootProject.name = "CandstechEQ"`
  - `app/build.gradle.kts` -> `namespace`, `applicationId`
  - Semua `package io.github.dragjon.eigentone...` -> `package com.candstech.eq...`
  - `app/src/main/AndroidManifest.xml` -> package + deep link `candstech-eq://preset`

## 2. Nama & String

- `app/src/main/res/values/strings.xml` + `strings_ui.xml`
  - `Eigentone` -> `Candstech EQ`
  - Tambah string Indonesia (lihat strings.xml di build ini)
- `README.md`, `PRODUCT.md`, `DESIGN.md`, `CHANGELOG.md`
  - Ganti judul + link repo + nama brand
  - Pertahankan kredit: "Based on Eigentone by Dragjon"

## 3. Warna & Tema

- `colors.xml` / `Theme.kt` / Compose theme
  - Amber Eigentone -> Hitam `#000000` + Kuning-hijau `#D6FF00` / `#F2FF00` -> `#7AC400`
  - Lihat `app/src/main/res/values/colors.xml` dan `ui/Theme.kt` di build ini

## 4. Logo & Icon

- Ganti:
  - `app/src/main/res/drawable/` -> `candstech_logo.png` (logo yang dikirim user, ada di root `logo.png`)
  - `app/src/main/res/mipmap-*/ic_launcher.png` -> icon dari logo (background hitam + logo di tengah)
  - `fastlane/metadata/android/en-US/images/` -> screenshot + icon Play Store 512
  - Splash screen / header di `MainActivity` -> pakai `R.drawable.candstech_logo`
  - Jangan pakai logo DNA amber Eigentone lagi.

Cara buat icon dari logo (sudah dilakukan di build ini):
- Crop logo ke bbox non-hitam, resize ke 512/192/144/96/72/48, tempel di canvas hitam 1:1.

## 5. Preset

- Tambah preset CandsTech di `Presets.kt`:
  - CandsTech Signature, Vocal, Gaming, Bass Head, Cinematic
  - Lihat `dsp/Presets.kt` di build ini untuk nilai gains-nya.
- Default preset saat pertama install -> `candstech-signature`

## 6. Keystore & Signing

- JANGAN pakai `eigentone-release.jks` milik Dragjon.
- Buat keystore baru untuk `com.candstech.eq`, simpan `keystore.properties` di luar git.
- Android menolak update kalau keystore beda.

## 7. Fastlane / Play Store

- `fastlane/metadata/android/en-US/`:
  - `title.txt` -> `Candstech EQ`
  - `short_description.txt` -> `Equaliser system-wide — Your Own Tone, by CandsTech`
  - `full_description.txt` -> copy dari README build ini
  - Ganti screenshot dengan screenshot Candstech EQ

## 8. Yang TIDAK boleh diubah / dihapus

- `LICENSE` (GPL-3.0) — tetap ada
- `ATTRIBUTION.md` / kredit Eigentone — wajib dipertahankan
- `THIRD_PARTY_NOTICES.txt` — pertahankan + tambah CandsTech

## 9. Perintah fork

```bash
git clone https://github.com/Dragjon/eigentone.git candstech-eq
cd candstech-eq
git remote rename origin upstream
git remote add origin https://github.com/<username-kamu>/candstech-eq.git
# ... terapkan perubahan di atas ...
git add -A
git commit -m "Rebrand Eigentone -> Candstech EQ"
git push -u origin main
```
