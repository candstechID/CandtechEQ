// Top-level build file - Candstech EQ
// Based on Eigentone (https://github.com/Dragjon/eigentone) - GPL-3.0
// Rebranded to Candstech EQ by CandsTech. Original code (c) Dragjon, see LICENSE + ATTRIBUTION.md
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "1.9.24" apply false
}
