package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import kotlin.math.ln
val ProQColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFFD600), Color(0xFFFF6EB4), Color(0xFF00E5FF), Color(0xFFFF8A00), Color(0xFFFF5252), Color(0xFFB388FF), Color(0xFF69F0AE), Color(0xFFFFAB00), Color(0xFF40C4FF))
@Composable
fun EqCurveView(gains31: FloatArray, parametric: List<ParametricFilter>, liveSpectrum: FloatArray = FloatArray(0), spectrumStatus: String = "", spectrumSource: String = "INTERNAL", spectrumSessionId: Int = 0, spectrumSessionPkg: String = "", onRestartSpectrum: () -> Unit = {}, onSwitchToMic: () -> Unit = {}, onSwitchToInternal: () -> Unit = {}, onParametricChange: (Int, ParametricFilter) -> Unit = { _, _ -> }, modifier: Modifier = Modifier) {
    val totalCurve = BiquadFactory.totalCurve(gains31, Presets.FREQ_31, emptyList())
    val activeFilters = parametric.filter { it.enabled }
    val isLive = liveSpectrum.any { it > 0.02f }
    var dragIdx by remember { mutableStateOf(-1) }
    Box(modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF1A1A1E)).padding(12.dp)) {
        Column {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("KURVA SUARA  \u2022  Pro-Q Style", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("+12  \u2022  0  \u2022  -12", color = CandstechColors.GreyDark, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Text("\u25CF", color = CandstechColors.Yellow, fontSize = 10.sp); Text("Total", color = CandstechColors.Grey, fontSize = 10.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Text("\u25CF", color = if (isLive) Color(0xFF00E676) else Color(0xFFFF5252), fontSize = 10.sp); Text(if (isLive) "LIVE" else "DATAR", color = CandstechColors.Grey, fontSize = 10.sp) }
                if (activeFilters.isNotEmpty()) { Text("${activeFilters.size} filter", color = CandstechColors.Grey, fontSize = 10.sp) }
            }
            // STATUS SPEKTRUM + PILIH SUMBER - v27: tidak restart mulu, user pilih INTERNAL / MIC
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2A2A2E)).padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(if (spectrumStatus.isEmpty()) if (isLive) "Spektrum: LIVE" else "Spektrum: Hening - putar lagu" else "Spektrum: $spectrumStatus", color = if (isLive) Color(0xFF00E676) else Color(0xFFFFAB00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("ULANG", color = CandstechColors.Yellow, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onRestartSpectrum() }.padding(start = 8.dp))
            }
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (spectrumSource == "INTERNAL") CandstechColors.Yellow else Color(0xFF2A2A2E)).clickable { onSwitchToInternal() }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("INTERNAL", color = if (spectrumSource == "INTERNAL") CandstechColors.Black else CandstechColors.Grey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (spectrumSource == "MIC") CandstechColors.Yellow else Color(0xFF2A2A2E)).clickable { onSwitchToMic() }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("MIC (dari speaker)", color = if (spectrumSource == "MIC") CandstechColors.Black else CandstechColors.Grey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("HP ini blokir Visualizer? Pakai MIC.", color = CandstechColors.GreyDark, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            }
            // v28: Info SESSION - kunci biar INTERNAL bisa jalan tanpa MIC
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1E2A1E)).padding(horizontal = 8.dp, vertical = 6.dp)) {
                val sessionText = if (spectrumSessionId != 0) "SESSION: $spectrumSessionId ($spectrumSessionPkg) - INTERNAL ASLI, tanpa MIC" else "SESSION: 0 (Global - diblokir di HP ini)"
                Text(sessionText, color = if (spectrumSessionId != 0) Color(0xFF00E676) else Color(0xFFFFAB00), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }
            if (spectrumSessionId == 0 && spectrumSource != "MIC") {
                Text("Cara ambil SESSION Spotify: Buka Spotify > Pengaturan > Equalizer > pilih Candstech EQ. Nanti session Spotify ke-tangkap otomatis, spektrum jalan INTERNAL tanpa MIC. YouTube tidak punya menu ini, jadi untuk YouTube tetap pakai MIC.", color = CandstechColors.Grey, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(170.dp)) {
                val wPx = constraints.maxWidth.toFloat(); val hPx = constraints.maxHeight.toFloat()
                fun xFor(freq: Double): Float = ((ln(freq) - ln(20.0)) / (ln(20000.0) - ln(20.0)) * wPx).toFloat()
                fun yFor(db: Double): Float = (hPx / 2 - (db.coerceIn(-12.0, 12.0) / 12.0 * hPx / 2)).toFloat()
                fun freqFor(x: Float): Double = kotlin.math.exp(ln(20.0) + (x / wPx) * (ln(20000.0) - ln(20.0)))
                fun dbFor(y: Float): Double = ((hPx / 2 - y) / (hPx / 2) * 12.0).coerceIn(-15.0, 15.0)
                Canvas(modifier = Modifier.fillMaxSize().pointerInput(parametric) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            var best = -1; var bestDist = 60f
                            parametric.forEachIndexed { idx, f ->
                                if (!f.enabled) return@forEachIndexed
                                val dx = xFor(f.freqHz) - offset.x; val dy = yFor(f.gainDb) - offset.y
                                val d = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (d < bestDist) { bestDist = d; best = idx }
                            }
                            dragIdx = best
                        },
                        onDrag = { change, _ ->
                            if (dragIdx >= 0 && dragIdx < parametric.size) {
                                val f = parametric[dragIdx]
                                onParametricChange(dragIdx, f.copy(freqHz = freqFor(change.position.x.coerceIn(0f, wPx)), gainDb = dbFor(change.position.y.coerceIn(0f, hPx))))
                            }
                        },
                        onDragEnd = { dragIdx = -1 }, onDragCancel = { dragIdx = -1 }
                    )
                }) {
                    val w = size.width; val h = size.height
                    for (i in 0..10) { val x = w * i / 10f; drawLine(Color(0xFF2A2A30), Offset(x, 0f), Offset(x, h), strokeWidth = 0.7f) }
                    for (i in 0..4) { val y = h * i / 4f; drawLine(Color(0xFF2A2A30), Offset(0f, y), Offset(w, y), strokeWidth = 0.7f) }
                    drawLine(Color(0xFF55555E), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.2f)
                    if (liveSpectrum.isNotEmpty()) {
                        val sPath = Path(); val step = w / liveSpectrum.size
                        for (i in liveSpectrum.indices) {
                            val x = i * step; val y = h - liveSpectrum[i].coerceIn(0f, 1f) * h * 0.98f
                            if (i == 0) sPath.moveTo(0f, h) else sPath.lineTo(x, y)
                            if (i == liveSpectrum.size - 1) sPath.lineTo(w, h)
                        }
                        sPath.close()
                        drawPath(sPath, brush = Brush.verticalGradient(listOf(Color(0xFF9E9E9E).copy(alpha = 0.35f), CandstechColors.GradientEnd.copy(alpha = 0.15f), Color.Transparent)))
                        val topPath = Path()
                        for (i in liveSpectrum.indices) {
                            val x = i * step + step / 2; val y = h - liveSpectrum[i].coerceIn(0f, 1f) * h * 0.98f
                            if (i == 0) topPath.moveTo(x, y) else topPath.lineTo(x, y)
                        }
                        drawPath(topPath, color = CandstechColors.Yellow.copy(alpha = 0.95f), style = Stroke(width = 2.5f, cap = StrokeCap.Round))
                    }
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val indiv = BiquadFactory.totalCurve(FloatArray(0), Presets.FREQ_31, listOf(f))
                        val pPath = Path()
                        indiv.forEachIndexed { i2, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (i2 == 0) pPath.moveTo(x, y) else pPath.lineTo(x, y) }
                        val fill = Path().apply { addPath(pPath); lineTo(w, h / 2); lineTo(0f, h / 2); close() }
                        drawPath(fill, brush = Brush.verticalGradient(listOf(col.copy(alpha = 0.22f), Color.Transparent)))
                        drawPath(pPath, color = col.copy(alpha = 0.85f), style = Stroke(width = 2f, cap = StrokeCap.Round))
                    }
                    val path = Path()
                    totalCurve.forEachIndexed { idx, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                    drawPath(path, brush = Brush.horizontalGradient(listOf(CandstechColors.GradientStart, CandstechColors.Yellow, CandstechColors.GradientEnd)), style = Stroke(width = 3f, cap = StrokeCap.Round))
                    val fillPath = Path().apply { addPath(path); lineTo(w, h / 2); lineTo(0f, h / 2); close() }
                    drawPath(fillPath, brush = Brush.verticalGradient(listOf(CandstechColors.Yellow.copy(alpha = 0.10f), Color.Transparent)))
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val cx = xFor(f.freqHz); val cy = yFor(f.gainDb)
                        drawCircle(Color.White, radius = 11f, center = Offset(cx, cy))
                        drawCircle(col, radius = 8f, center = Offset(cx, cy))
                        drawCircle(Color.White.copy(alpha = 0.6f), radius = 11f, center = Offset(cx, cy), style = Stroke(width = 1.5f))
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("20", "100", "1k", "10k", "20k").forEach { Text(it, color = CandstechColors.GreyDark, fontSize = 10.sp) } }
        }
    }
}
