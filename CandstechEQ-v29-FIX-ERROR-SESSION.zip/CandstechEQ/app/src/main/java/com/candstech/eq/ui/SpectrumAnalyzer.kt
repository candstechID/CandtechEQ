package com.candstech.eq.ui

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.Visualizer
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*
/**
 * Spectrum v27 - STOP RESTART MULU + PILIH SUMBER
 * Masalah v26: HP user blokir Visualizer(0). v25 gerak karena diam-diam pakai MIC.
 * v26 hapus mic -> tidak ada sumber -> heartbeat restart terus (restart ke-11), spektrum 0 datar.
 * Fix v27:
 * 1. TIDAK restart mulu: max 2x auto-restart, habis itu berhenti, status = VISUALIZER DIBLOKIR HP INI.
 * 2. PILIH SUMBER: INTERNAL / MIC bisa dipilih manual lewat tombol di atas grafik.
 *    INTERNAL = Visualizer(0) audio internal. MIC = AudioRecord nangkep dari speaker.
 *    Kalau HP blokir Visualizer, satu-satunya cara spektrum gerak di HP itu adalah MIC.
 * 3. Monitor tidak restart loop: kalau 4 detik tanpa FFT, tandai BLOKIR, jangan restart lagi.
 * 4. Decay tetap ada biar tidak freeze, tapi tidak memicu restart.
 */
class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val _status = MutableStateFlow("MENUNGGU IZIN")
    val status: StateFlow<String> = _status
    private val _source = MutableStateFlow("INTERNAL")
    private val _sessionId = MutableStateFlow(0)
    val sessionId: StateFlow<Int> = _sessionId
    @Volatile var currentSessionId: Int = 0
        private set
    val source: StateFlow<String> = _source
    private val smoothed = FloatArray(32) { 0f }
    private var running = false
    private var usingMic = false
    private var blocked = false
    private var scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var monitorJob: Job? = null
    private var decayJob: Job? = null
    private var micJob: Job? = null
    @Volatile private var lastFftTime = 0L
    @Volatile private var restartCount = 0
    fun start() {
        if (running) return
        running = true
        usingMic = false
        blocked = false
        restartCount = 0
        _source.value = "INTERNAL"
        _status.value = "MENCOBA VISUALIZER (INTERNAL)..."
        tryStartVisualizer()
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (running) {
                delay(500)
                if (usingMic) continue // lagi pakai mic, jangan ganggu
                if (blocked) continue // sudah diblokir, jangan restart lagi
                val since = System.currentTimeMillis() - lastFftTime
                if (lastFftTime != 0L && since > 4000) {
                    if (restartCount < 2) {
                        restartCount++
                        _status.value = "VISUALIZER TIDAK RESPON - COBA LAGI ($restartCount/2)..."
                        try { visualizer?.enabled = false } catch (_: Exception) {}
                        try { visualizer?.release() } catch (_: Exception) {}
                        visualizer = null
                        delay(500)
                        if (running && !usingMic) tryStartVisualizer(currentSessionId)
                        lastFftTime = System.currentTimeMillis()
                    } else {
                        blocked = true
                        _status.value = "VISUALIZER DIBLOKIR HP INI - TAP MIC"
                        // Jangan restart lagi. Biarkan 0, tunggu user pilih MIC.
                    }
                }
            }
        }
        decayJob?.cancel()
        decayJob = scope.launch {
            while (running) {
                delay(50)
                if (usingMic) continue
                val since = System.currentTimeMillis() - lastFftTime
                if (lastFftTime != 0L && since > 250) {
                    var any = false
                    for (i in smoothed.indices) {
                        if (smoothed[i] > 0.01f) { smoothed[i] = smoothed[i] * 0.88f; any = true }
                    }
                    if (any) _spectrum.value = smoothed.copyOf()
                    else if (_spectrum.value.any { it > 0.01f }) _spectrum.value = FloatArray(32) { 0f }
                }
            }
        }
    }
    fun restart() {
        // ULANG manual: reset blocked, coba INTERNAL lagi
        blocked = false
        restartCount = 0
        stopJobsOnly()
        running = false
        scope.launch { delay(300); start() }
    }
    fun switchToMic() {
        if (usingMic) return
        usingMic = true
        blocked = false
        _source.value = "MIC"
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        _status.value = "MIC - Nangkep dari speaker"
        startMic()
    }
    fun switchToInternal() {
        if (!usingMic && !blocked) return
        micJob?.cancel()
        usingMic = false
        blocked = false
        restartCount = 0
        _source.value = "INTERNAL"
        _status.value = "MENCOBA VISUALIZER (INTERNAL)..."
        tryStartVisualizer(0)
        lastFftTime = System.currentTimeMillis()
    }
    /**
     * v28: Attach ke sessionId ASLI dari Spotify (didapat via AudioEffectReceiver).
     * Visualizer(sessionId) TIDAK diblokir, beda dengan Visualizer(0).
     */
    fun attachToSession(sessionId: Int, pkg: String) {
        if (sessionId == 0 || sessionId == currentSessionId) return
        if (usingMic) return // lagi pakai MIC, jangan rebut
        Log.d("CandstechEQ", "attachToSession: $sessionId pkg=$pkg")
        micJob?.cancel()
        usingMic = false
        blocked = false
        restartCount = 0
        _source.value = "INTERNAL"
        _sessionId.value = sessionId
        currentSessionId = sessionId
        _status.value = "LIVE - VISUALIZER (SESSION $sessionId - $pkg)"
        tryStartVisualizer(sessionId, pkg)
        lastFftTime = System.currentTimeMillis()
    }
    private fun stopJobsOnly() {
        monitorJob?.cancel(); decayJob?.cancel(); micJob?.cancel()
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
    }
    private fun tryStartVisualizer(targetSession: Int = 0, targetPkg: String = "") {
        try {
            try { visualizer?.enabled = false } catch (_: Exception) {}
            try { visualizer?.release() } catch (_: Exception) {}
            val vis = if (targetSession != 0) Visualizer(targetSession) else Visualizer(0)
            vis.captureSize = 1024
            try { vis.scalingMode = Visualizer.SCALING_MODE_NORMALIZED } catch (_: Exception) {}
            try { vis.measurementMode = Visualizer.MEASUREMENT_MODE_PEAK_RMS } catch (_: Exception) {}
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) onFftVisualizer(fft, rate)
                }
            }, 60, false, true)
            vis.enabled = true
            visualizer = vis
            lastFftTime = System.currentTimeMillis()
            if (blocked) blocked = false
            _sessionId.value = targetSession
            currentSessionId = targetSession
            _status.value = if (targetSession != 0) "LIVE - VISUALIZER (SESSION $targetSession - $targetPkg)" else "LIVE - VISUALIZER (INTERNAL)"
        } catch (e: Exception) {
            _status.value = "VISUALIZER GAGAL - TAP MIC"
            blocked = true
        }
    }
    private fun onFftVisualizer(fft: ByteArray, samplingRate: Int) {
        if (usingMic) return
        lastFftTime = System.currentTimeMillis()
        if (blocked) blocked = false
        val binCount = fft.size / 2
        if (binCount < 2) return
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0
        val out = FloatArray(32)
        var anySignal = false
        for (band in 0 until 32) {
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            val binLow = ((fLow / nyquist) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / nyquist) * binCount).toInt().coerceIn(binLow + 1, binCount)
            var sum = 0.0; var cnt = 0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toDouble(); val im = fft[b * 2 + 1].toDouble()
                sum += sqrt(re * re + im * im); cnt++
            }
            val avg = if (cnt > 0) sum / cnt else 0.0
            if (avg < 1.0) {
                smoothed[band] = smoothed[band] * 0.88f
                out[band] = smoothed[band]
                continue
            }
            anySignal = true
            val db = 20.0 * log10(avg / 128.0)
            var v = ((db + 82.0) / 68.0).coerceIn(0.0, 1.0)
            v = v.pow(0.6)
            val bandBoost = 1.0 + (band / 31.0) * 0.5
            v = (v * 1.15 * bandBoost).coerceIn(0.0, 0.92)
            val prev = smoothed[band].toDouble()
            smoothed[band] = if (v > prev) (prev + (v - prev) * 0.90).toFloat() else (prev * 0.85 + v * 0.15).toFloat()
            out[band] = smoothed[band]
        }
        _spectrum.value = out
        if (anySignal) {
            if (_status.value.startsWith("VISUALIZER") || _status.value.startsWith("MENCOBA")) {
                // Jangan timpa session, pakai currentSessionId yang sudah disimpan di tryStartVisualizer
                _status.value = if (currentSessionId != 0) "LIVE - VISUALIZER (SESSION $currentSessionId)" else "LIVE - VISUALIZER (INTERNAL)"
            }
        } else {
            // FFT datang tapi hening (tidak ada lagu) -> bukan macet, jangan restart
            if (!_status.value.startsWith("LIVE")) _status.value = "HENING - PUTAR LAGU"
        }
    }
    private fun startMic() {
        micJob?.cancel()
        micJob = scope.launch(Dispatchers.Default) {
            val sampleRate = 44100
            val bufSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(bufSize, 4096))
            } catch (e: Exception) { _status.value = "MIC GAGAL: ${e.message}"; return@launch }
            try {
                rec.startRecording()
                val buf = ShortArray(1024)
                val window = DoubleArray(1024) { i -> 0.54 - 0.46 * cos(2.0 * Math.PI * i / 1023.0) }
                while (running && usingMic) {
                    val read = rec.read(buf, 0, 1024)
                    if (read <= 0) { delay(20); continue }
                    val re = DoubleArray(1024); val im = DoubleArray(1024)
                    for (i in 0 until 1024) { re[i] = (buf[i] / 32768.0) * window[i]; im[i] = 0.0 }
                    fft(re, im)
                    val out = FloatArray(32)
                    for (band in 0 until 32) {
                        val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
                        val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
                        val binLow = ((fLow / (sampleRate / 2.0)) * 512).toInt().coerceIn(1, 511)
                        val binHigh = ((fHigh / (sampleRate / 2.0)) * 512).toInt().coerceIn(binLow + 1, 512)
                        var sum = 0.0; var cnt = 0
                        for (b in binLow until binHigh) {
                            val mag = sqrt(re[b] * re[b] + im[b] * im[b]) / 512.0
                            sum += mag; cnt++
                        }
                        val avg = if (cnt > 0) sum / cnt else 0.0
                        if (avg < 0.0005) { smoothed[band] = smoothed[band] * 0.88f; out[band] = smoothed[band]; continue }
                        val db = 20.0 * log10(avg + 1e-9)
                        var v = ((db + 65.0) / 55.0).coerceIn(0.0, 1.0)
                        v = v.pow(0.6)
                        val bandBoost = 1.0 + (band / 31.0) * 0.5
                        v = (v * 1.15 * bandBoost).coerceIn(0.0, 0.92)
                        val prev = smoothed[band].toDouble()
                        smoothed[band] = if (v > prev) (prev + (v - prev) * 0.90).toFloat() else (prev * 0.85 + v * 0.15).toFloat()
                        out[band] = smoothed[band]
                    }
                    _spectrum.value = out
                    _status.value = "LIVE - MIC (dari speaker)"
                    delay(16)
                }
            } catch (e: Exception) { _status.value = "MIC ERROR: ${e.message}" }
            finally { try { rec.stop() } catch (_: Exception) {}; try { rec.release() } catch (_: Exception) {} }
        }
    }
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cwr = 1.0; var cwi = 0.0
                for (k in 0 until len / 2) {
                    val uR = re[i + k]; val uI = im[i + k]
                    val vR = re[i + k + len / 2] * cwr - im[i + k + len / 2] * cwi
                    val vI = re[i + k + len / 2] * cwi + im[i + k + len / 2] * cwr
                    re[i + k] = uR + vR; im[i + k] = uI + vI
                    re[i + k + len / 2] = uR - vR; im[i + k + len / 2] = uI - vI
                    val nwr = cwr * wr - cwi * wi; val nwi = cwr * wi + cwi * wr; cwr = nwr; cwi = nwi
                }
                i += len
            }
            len = len shl 1
        }
    }
    fun stop() {
        running = false
        monitorJob?.cancel(); decayJob?.cancel(); micJob?.cancel()
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        lastFftTime = 0L
    }
    companion object {
        fun spectrumToDbRms(v: Float): Float {
            if (v < 0.01f) return -90f
            val dbPeak = (Math.pow(v.toDouble(), 1.0 / 0.7) * 70.0 - 75.0).toFloat()
            return dbPeak - 12f
        }
    }
}
