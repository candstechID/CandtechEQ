package com.candstech.eq.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.util.Log

/**
 * Holder session ID dari Spotify / app musik lain.
 * Cara kerja yang BENAR (bukan seperti klaim AI Overview yang bilang 100% otomatis):
 * - Broadcast ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION TIDAK dikirim saat Spotify mulai putar lagu.
 * - Broadcast ini HANYA dikirim saat user membuka panel EQ dari dalam app musik itu:
 *   Spotify > Pengaturan > Equalizer > pilih Candstech EQ.
 * - Saat itu Spotify mengirimkan sessionId ASLI-nya. Visualizer(sessionId) inilah yang TIDAK diblokir,
 *   beda dengan Visualizer(0) yang diblokir MIUI/Samsung.
 * - YouTube / YouTube Music TIDAK punya menu Equalizer, jadi TIDAK mengirim broadcast ini sama sekali.
 *   Untuk YouTube, satu-satunya jalan tetap MIC.
 */
object AudioSessionHolder {
    @Volatile var lastSessionId: Int = 0
    @Volatile var lastPackage: String = ""
    @Volatile var lastUpdate: Long = 0L
    private val listeners = mutableListOf<(Int, String) -> Unit>()
    @Synchronized fun post(sessionId: Int, pkg: String) {
        if (sessionId == 0) return
        lastSessionId = sessionId
        lastPackage = pkg
        lastUpdate = System.currentTimeMillis()
        Log.d("CandstechEQ", "AudioSessionHolder: session=$sessionId pkg=$pkg")
        val copy = listeners.toList()
        for (l in copy) { try { l(sessionId, pkg) } catch (_: Exception) {} }
    }
    @Synchronized fun addListener(l: (Int, String) -> Unit) { listeners.add(l) }
    @Synchronized fun removeListener(l: (Int, String) -> Unit) { listeners.remove(l) }
    @Synchronized fun clear() { lastSessionId = 0; lastPackage = ""; lastUpdate = 0L }
}

class AudioEffectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val sessionId = try { intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0) } catch (_: Exception) { 0 }
        val pkg = try { intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) } catch (_: Exception) { null } ?: ""
        Log.d("CandstechEQ", "AudioEffectReceiver: action=$action session=$sessionId pkg=$pkg")
        when (action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                if (sessionId != 0) AudioSessionHolder.post(sessionId, pkg)
            }
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                // Jangan langsung clear, biarkan Visualizer tetap jalan sampai lagu berhenti
            }
        }
    }
}
