package com.candstech.eq

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.data.PresetStore
import com.candstech.eq.dsp.AutoEq
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import com.candstech.eq.engine.CandstechEqEngine
import com.candstech.eq.engine.EqService
import com.candstech.eq.ui.CandstechColorScheme
import com.candstech.eq.ui.CandstechColors
import com.candstech.eq.ui.EqCurveView
import com.candstech.eq.ui.EqFaders
import com.candstech.eq.ui.SpectrumAnalyzer
import com.candstech.eq.ui.MbcTab
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CandstechEqEngine.instance.attachContext(this)
        setContent {
            MaterialTheme(colorScheme = CandstechColorScheme) {
                CandstechAppScreen(
                    onStartService = { startService(Intent(this, EqService::class.java)) }
                )
            }
        }
    }
}

@Composable
fun CandstechAppScreen(onStartService: () -> Unit = {}) {
    val engine = remember { CandstechEqEngine.instance }
    val state by engine.state.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showWelcome by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val spectrumAnalyzer = remember { SpectrumAnalyzer() }
    val liveSpectrum by spectrumAnalyzer.spectrum.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    var hasAudioPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasAudioPermission = granted
        if (granted) spectrumAnalyzer.start()
    }
    LaunchedEffect(Unit) {
        onStartService()
        if (hasAudioPermission) spectrumAnalyzer.start() else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    DisposableEffect(Unit) { onDispose { spectrumAnalyzer.stop() } }

    Box(modifier = Modifier.fillMaxSize().background(CandstechColors.Black)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // HEADER - logo CandsTech, di bawah statusbar
            Row(
                modifier = Modifier.fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.candstech_logo_cropped),
                    contentDescription = "CandsTech",
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart,
                    modifier = Modifier.height(48.dp).weight(1f, fill = true)
                )
                Spacer(modifier = Modifier.width(12.dp))
                // Toggle ON/OFF besar
                Switch(
                    checked = state.enabled,
                    onCheckedChange = { engine.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CandstechColors.Black,
                        checkedTrackColor = CandstechColors.Yellow,
                        uncheckedThumbColor = CandstechColors.Grey,
                        uncheckedTrackColor = CandstechColors.Card
                    )
                )
            }
            Text(
                text = if (state.enabled) "EQ AKTIF  •  System-wide" else "EQ NONAKTIF",
                color = if (state.enabled) CandstechColors.Yellow else CandstechColors.Grey,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Warning clipping seperti Eigentone
            if (engine.willClip(state)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A0A0A)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = CandstechColors.Red, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Waspada: setting ini bisa clipping. Turunkan preamp / gain.", color = Color(0xFFFF8A80), fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // CONTENT per tab
            Box(modifier = Modifier.weight(1f)) {
                when (tab) {
                    0 -> EqTab(state = state, engine = engine, liveSpectrum = liveSpectrum)
                    1 -> ParametricTab(engine = engine, liveSpectrum = liveSpectrum)
                    2 -> PresetTab(engine = engine)
                    3 -> HeadphoneTab(engine = engine)
                    4 -> MbcTab(engine = engine, liveSpectrum = liveSpectrum)
                    5 -> SettingsTab(engine)
                }
            }

            // BOTTOM NAV - 6 tab
            NavigationBar(
                containerColor = CandstechColors.Surface,
                modifier = Modifier.navigationBarsPadding()
            ) {
                val items = listOf(
                    "Equaliser" to Icons.Default.Equalizer,
                    "Parametrik" to Icons.Default.Tune,
                    "Preset" to Icons.Default.Folder,
                    "Headphone" to Icons.Default.Headphones,
                    "Kompresor" to Icons.Default.GraphicEq,
                    "Pengaturan" to Icons.Default.Settings
                )
                items.forEachIndexed { idx, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == idx,
                        onClick = { tab = idx },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CandstechColors.Black,
                            selectedTextColor = CandstechColors.Yellow,
                            unselectedIconColor = CandstechColors.Grey,
                            unselectedTextColor = CandstechColors.Grey,
                            indicatorColor = CandstechColors.Yellow
                        )
                    )
                }
            }
        }

        // Welcome sheet singkat (seperti Eigentone: simple by default)
        if (showWelcome) {
            AlertDialog(
                onDismissRequest = { showWelcome = false },
                containerColor = CandstechColors.Card,
                title = { Text("Selamat datang di Candstech EQ", color = CandstechColors.White, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Equaliser system-wide untuk Spotify, YouTube & semua aplikasi.\n\n1. Nyalakan EQ di atas\n2. Pilih preset CandsTech Signature\n3. Kalau pakai headphone, buka tab Headphone & pilih modelmu untuk koreksi AutoEq.\n\nTanpa root. Tanpa iklan. Tanpa tracking.",
                        color = CandstechColors.Grey
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showWelcome = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CandstechColors.Yellow, contentColor = CandstechColors.Black)
                    ) { Text("Mulai", fontWeight = FontWeight.Bold) }
                }
            )
        }
    }
}

@Composable
fun EqTab(state: CandstechEqEngine.EqState, engine: CandstechEqEngine, liveSpectrum: FloatArray = FloatArray(0)) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            EqCurveView(gains31 = engine.effectiveGains(state), parametric = state.parametric + state.autoEqFilters, liveSpectrum = liveSpectrum, onParametricChange = { idx, f -> val all = state.parametric.toMutableList(); if (idx < all.size) { all[idx] = f; engine.update { st -> st.copy(parametric = all) } } })
        }
        item {
            // Preamp + Bypass + Undo/Redo row
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PREAMP  ${"%.1f".format(state.preampDb)} dB", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = state.preampDb,
                            onValueChange = { newVal -> engine.update { st -> st.copy(preampDb = newVal.coerceIn(-12f, 12f)) } },
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder)
                        )
                    }
                }
                Button(
                    onClick = { engine.setBypass(!state.bypass) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.bypass) CandstechColors.Yellow else CandstechColors.Card,
                        contentColor = if (state.bypass) CandstechColors.Black else CandstechColors.White
                    ),
                    modifier = Modifier.height(56.dp)
                ) { Text(if (state.bypass) "BYPASS ON" else "BYPASS", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item {
            EqFaders(
                gains10 = state.gains10,
                onGainChange = { idx, v -> engine.setBand(idx, v) }
            )
        }
        item {
            // Bass / Treble cepat
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bass" to state.bassDb, "Treble" to state.trebleDb).forEach { (label, value) ->
                    Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("$label  ${"%.0f".format(value)} dB", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Slider(
                                value = value,
                                onValueChange = { newVal ->
                                    if (label == "Bass") engine.update { st -> st.copy(bassDb = newVal) }
                                    else engine.update { st -> st.copy(trebleDb = newVal) }
                                },
                                valueRange = -10f..10f,
                                colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder)
                            )
                        }
                    }
                }
            }
        }
        item {
            Text("Preset cepat", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Presets.ALL) { p ->
                    val selected = p.gains10 == state.gains10
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(20.dp))
                            .background(if (selected) CandstechColors.Yellow else CandstechColors.Card)
                            .clickable { engine.applyPreset(p.id) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(p.name, color = if (selected) CandstechColors.Black else CandstechColors.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun ParametricTab(engine: CandstechEqEngine, liveSpectrum: FloatArray = FloatArray(0)) {
    val state by engine.state.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Parametric EQ — hingga 20 filter", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Bell, shelf, tilt, notch, band-pass, high/low-pass 6–48 dB/oct. Tiap filter bisa stereo / kiri / kanan, dan bisa dynamic.", color = CandstechColors.Grey, fontSize = 13.sp)
        }
        if (state.parametric.isEmpty()) {
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun SettingsTab(engine: CandstechEqEngine = CandstechEqEngine.instance) {
    val state by engine.state.collectAsState()
    var advanced by remember { mutableStateOf(false) }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Pengaturan - REAL, semua langsung ke suara", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Bukan UI doang: tiap switch/slider di sini langsung update DynamicsProcessing.", color = CandstechColors.Grey, fontSize = 12.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Kontrol Lanjutan", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                        Switch(checked = advanced, onCheckedChange = { advanced = it }, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
                    }
                    Text("Kalau OFF, hanya setting yang kamu ubah yang tampil. Kalau ON, semua setting tampil (seperti Eigentone).", color = CandstechColors.Grey, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Clarity (Dynamic EQ)  ${"%.0f".format(state.clarity * 100)}% - REAL ke MBC", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("Masuk ke MBC threshold mid/high. Makin tinggi, harshness & boom makin ditekan saat keras.", color = CandstechColors.Grey, fontSize = 12.sp)
                    Slider(value = state.clarity, onValueChange = { v -> engine.update { it.copy(clarity = v) } }, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Balance  ${"%.2f".format(state.balance)} - REAL ke inputGain kiri/kanan", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("-1 = kiri lebih keras, +1 = kanan lebih keras. Beda gain +-3dB per channel.", color = CandstechColors.Grey, fontSize = 12.sp)
                    Slider(value = state.balance, onValueChange = { v -> engine.update { it.copy(balance = v) } }, valueRange = -1f..1f, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Stereo Width  ${"%.2f".format(state.stereoWidth)} - REAL via Virtualizer", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("0.0 = Sempit (Virtualizer OFF), 1.0 = Normal, 2.0 = Lebar (Virtualizer strength 1000). Beneran ngubah citra stereo.", color = CandstechColors.Grey, fontSize = 12.sp)
                    Slider(value = state.stereoWidth, onValueChange = { v -> engine.update { st -> st.copy(stereoWidth = v) } }, valueRange = 0f..2f, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Sempit", color = CandstechColors.GreyDark, fontSize = 11.sp)
                        Text("Normal", color = CandstechColors.GreyDark, fontSize = 11.sp)
                        Text("Lebar", color = CandstechColors.GreyDark, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            SettingSwitch("Loudness (ISO 226) - REAL", "Shelf bass +2.5dB & treble +1.5dB masuk ke EQ. Bukan cuma label.", state.loudnessEnabled) { newVal -> engine.update { st -> st.copy(loudnessEnabled = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Night Mode - REAL", "MBC threshold -6dB + limiter -3dB + preamp -2dB. Dinamika ditekan.", state.nightMode) { newVal -> engine.update { st -> st.copy(nightMode = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Compressor (MBC) - REAL", "MBC threshold -12dB. Suara keras ditekan, pelan tetap jelas.", state.compressorEnabled) { newVal -> engine.update { st -> st.copy(compressorEnabled = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Limiter - REAL", "Limiter stage on/off di DynamicsProcessing. Cegah clipping.", state.limiterEnabled) { newVal -> engine.update { st -> st.copy(limiterEnabled = newVal) } }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Tentang Candstech EQ - REAL Engine", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("Versi 1.0.0-candstech REAL • Package com.candstech.eq\n\nEngine: Android DynamicsProcessing (session 0, system-wide).\nSemua slider -> effectiveGains() -> EqBand hardware.\nParametric & AutoEq dihitung via Biquad RBJ, bukan cuma gambar.\n\nTurunan konsep dari Eigentone oleh Dragjon (GPL-3.0).\nBranding, warna, logo & preset khas CandsTech.\nTanpa iklan, tanpa tracking, tanpa akun.", color = CandstechColors.Grey, fontSize = 13.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun SettingSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = CandstechColors.White, fontWeight = FontWeight.Bold)
                Text(desc, color = CandstechColors.Grey, fontSize = 12.sp)
            }
            Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
        }
    }
}
