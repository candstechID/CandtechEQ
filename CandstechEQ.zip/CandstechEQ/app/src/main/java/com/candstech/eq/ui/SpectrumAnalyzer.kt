package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(32) { 0f }
    private var running = false

    // KUNCI 1: Hardcode 48000. Parameter 'rate' dari Android sering salah (capture rate, bukan sample rate)
    // yang bikin mapping frekuensi kacau dan jadi tembok.
    private val sampleRate = 48000.0

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            // KUNCI 2: Pakai ukuran maksimal agar resolusi bass tajam (2048 bin = ~23Hz/bin)
            vis.captureSize = range[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) onFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray) {
        val n = fft.size
        val binCount = n / 2
        val freqPerBin = sampleRate / n // Hz per bin yang BENAR

        val mag = FloatArray(binCount)
        for (b in 0 until binCount) {
            val re = fft[b * 2].toInt()
            val im = fft[b * 2 + 1].toInt()
            mag[b] = sqrt((re * re + im * im).toFloat())
        }

        // KUNCI 3: Hitung noise floor (median) untuk menghilangkan "tembok" leakage
        val sorted = mag.copyOf().also { it.sort() }
        val floor = sorted[sorted.size / 2]

        val out = FloatArray(32)
        for (band in 0 until 32) {
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)

            val binLow = (fLow / freqPerBin).toInt().coerceIn(1, binCount - 1)
            val binHigh = (fHigh / freqPerBin).toInt().coerceIn(binLow + 1, binCount)

            var sumSq = 0.0
            var cnt = 0
            for (b in binLow until binHigh) {
                val m = (mag[b] - floor).coerceAtLeast(0f)
                sumSq += (m * m).toDouble()
                cnt++
            }
            val rms = if (cnt > 0) sqrt(sumSq / cnt).toFloat() else 0f

            // OUTPUT SKALA 0.0 - 1.0 (Agar GR di MbcTab tetap jalan tanpa diubah)
            // sqrt = gamma curve agar mid-band terlihat natural, tidak datar
            var v = sqrt((rms / 140.0).coerceIn(0.0, 1.0)).toFloat()
            
            // Noise gate: band sunyi = 0, bukan floor palsu
            if (v < 0.04f) v = 0f

            val prev = smoothed[band]
            // Attack cepat, release lambat (natural)
            smoothed[band] = if (v > prev) prev + (v - prev) * 0.8f else prev * 0.82f + v * 0.18f
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}