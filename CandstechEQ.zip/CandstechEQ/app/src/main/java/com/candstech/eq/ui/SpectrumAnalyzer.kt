package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import com.candstech.eq.dsp.Presets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(31) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(31) { 0f }
    private var running = false

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            vis.captureSize = range[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) onFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray) {
        val n = fft.size
        val binCount = n / 2
        val sampleRate = 48000.0
        val freqPerBin = sampleRate / n

        val mag = FloatArray(binCount)
        for (b in 0 until binCount) {
            val re = fft[b * 2].toInt()
            val im = fft[b * 2 + 1].toInt()
            mag[b] = sqrt((re * re + im * im).toFloat())
        }

        val sorted = mag.copyOf().also { it.sort() }
        val floor = sorted[sorted.size / 4] // Noise floor (25% terbawah)

        val out = FloatArray(31)
        for (band in 0 until 31) {
            val center = Presets.FREQ_31[band]
            var pos = center / freqPerBin
            if (pos < 1.0) pos = 1.0
            if (pos > binCount - 2.0) pos = (binCount - 2.0).coerceAtLeast(1.0)

            val i0 = floor(pos).toInt()
            val i1 = i0 + 1
            val frac = (pos - i0).toFloat()

            val m0 = (mag[i0] - floor).coerceAtLeast(0f)
            val m1 = (mag[i1] - floor).coerceAtLeast(0f)
            val interp = m0 * (1f - frac) + m1 * frac

            // ✅ RAHASIA DOLBY: Gamma Scaling 0.45
            // 1. Normalisasi mentah (0.0 - 1.0)
            val raw = (interp / 140f).coerceIn(0f, 1f)
            // 2. Pangkat 0.45 -> Mengangkat suara pelan agar terlihat, menekan suara keras agar tidak tembok
            var v = Math.pow(raw.toDouble(), 0.45).toFloat()
            
            // Noise gate: jika sangat pelan, anggap 0 agar tidak ada "semut"
            if (v < 0.03f) v = 0f

            // Smoothing (Attack cepat, Release lambat)
            val attack = if (band < 8) 0.65f else 0.85f
            val release = if (band < 8) 0.88f else 0.78f
            val prev = smoothed[band]
            smoothed[band] = if (v > prev) prev + (v - prev) * attack else prev * release + v * (1f - release)
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}