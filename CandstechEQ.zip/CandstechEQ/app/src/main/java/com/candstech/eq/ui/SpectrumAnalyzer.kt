package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import com.candstech.eq.dsp.Presets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    // Output 31 band, persis sama dengan Presets.FREQ_31
    private val _spectrum = MutableStateFlow(FloatArray(31) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(31) { 0f }
    private var running = false

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            vis.captureSize = range[1] // Maksimal untuk resolusi terbaik
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) onFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray) {
        val n = fft.size
        val binCount = n / 2
        val sampleRate = 48000.0 // Hardcode, parameter rate Android tidak reliable
        val freqPerBin = sampleRate / n

        val mag = FloatArray(binCount)
        for (b in 0 until binCount) {
            val re = fft[b * 2].toInt()
            val im = fft[b * 2 + 1].toInt()
            mag[b] = sqrt((re * re + im * im).toFloat())
        }

        val out = FloatArray(31)
        for (band in 0 until 31) {
            val center = Presets.FREQ_31[band]
            // Bandwidth ISO 1/3 Octave: f_low = center / 2^(1/6), f_high = center * 2^(1/6)
            val fLow = center / pow(2.0, 1.0 / 6.0)
            val fHigh = center * pow(2.0, 1.0 / 6.0)

            val binLow = (fLow / freqPerBin).toInt().coerceIn(1, binCount - 1)
            val binHigh = (fHigh / freqPerBin).toInt().coerceIn(binLow + 1, binCount)

            // RMS (Root Mean Square) untuk energi band yang akurat
            var sumSq = 0.0
            var cnt = 0
            for (b in binLow until binHigh) {
                sumSq += (mag[b] * mag[b]).toDouble()
                cnt++
            }
            val rms = if (cnt > 0) sqrt(sumSq / cnt).toFloat() else 0f

            // Konversi ke dB, lalu normalize ke 0.0 - 1.0
            val db = 20f * log10((rms / 140f).coerceAtLeast(1e-4f))
            val v = ((db + 60f) / 60f).coerceIn(0f, 1f)

            // Attack/Release berbeda: Bass lambat, Treble cepat (natural)
            val attack = if (band < 8) 0.6f else 0.8f
            val release = if (band < 8) 0.85f else 0.75f

            val prev = smoothed[band]
            smoothed[band] = if (v > prev) prev + (v - prev) * attack else prev * release + v * (1f - release)
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}