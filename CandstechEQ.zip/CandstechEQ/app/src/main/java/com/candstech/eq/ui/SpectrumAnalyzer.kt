package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(32) { 0f }
    private var running = false

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            // FIX: 512 = sweet spot (resolusi cukup + update rate ~30fps)
            val captureSize = 512.coerceIn(range[0], range[1])
            vis.captureSize = captureSize
            
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) onFft(fft, rate)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray, samplingRate: Int) {
        val binCount = fft.size / 2
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val out = FloatArray(32)
        
        for (band in 0 until 32) {
            // Logarithmic mapping 20Hz - 20kHz (standar spectrum analyzer)
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            
            val binLow = ((fLow / (sr / 2.0)) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / (sr / 2.0)) * binCount).toInt().coerceIn(binLow + 1, binCount)
            
            var sum = 0.0
            var n = 0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toInt()
                val im = fft[b * 2 + 1].toInt()
                sum += sqrt((re * re + im * im).toDouble())
                n++
            }
            
            val avg = if (n > 0) sum / n else 0.0
            
            // ✅ FIX: Normalisasi per-band dengan reference tetap (128 = max byte FFT)
            // Convert magnitude ke dB: 20 * log10(avg / 128)
            // Map range -60dB sampai 0dB ke 0.0 sampai 1.0
            val db = if (avg > 1e-4) {
                20.0 * log10(avg / 128.0)
            } else {
                -60.0
            }
            val v = ((db + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
            
            // ✅ FIX: Smoothing yang benar (attack cepat, release sedang)
            val prev = smoothed[band]
            smoothed[band] = if (v > prev) {
                prev + (v - prev) * 0.7f   // Attack: langsung naik saat ada suara
            } else {
                prev * 0.4f + v * 0.6f     // Release: turun cukup cepat
            }
            
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}