package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(32) { 0f }
    private var running = false

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            val captureSize = 1024.coerceIn(range[0], range[1]) // Lebih besar = resolusi lebih baik
            vis.captureSize = captureSize
            
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) onFft(fft, rate)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray, samplingRate: Int) {
        val binCount = fft.size / 2
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val out = FloatArray(32)
        
        // FIX: Hitung magnitude mentah dulu untuk semua bin
        val magnitudes = DoubleArray(binCount)
        for (b in 0 until binCount) {
            val re = fft[b * 2].toInt()
            val im = fft[b * 2 + 1].toInt()
            magnitudes[b] = sqrt((re * re + im * im).toDouble())
        }
        
        // FIX: Cari max magnitude untuk normalisasi global (mencegah bass mendominasi)
        val maxMag = magnitudes.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
        
        for (band in 0 until 32) {
            // FIX: Hybrid mapping - linear untuk bass, log untuk mid-high
            val fLow: Double
            val fHigh: Double
            
            if (band < 8) {
                // Band 0-7: Linear mapping 20-500 Hz (bass & low-mid)
                fLow = 20.0 + (band / 8.0) * 480.0
                fHigh = 20.0 + ((band + 1) / 8.0) * 480.0
            } else {
                // Band 8-31: Logarithmic mapping 500-20000 Hz
                val t = (band - 8) / 24.0
                val tNext = (band + 1 - 8) / 24.0
                fLow = 500.0 * (20000.0 / 500.0).pow(t)
                fHigh = 500.0 * (20000.0 / 500.0).pow(tNext)
            }
            
            val binLow = ((fLow / (sr / 2.0)) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / (sr / 2.0)) * binCount).toInt().coerceIn(binLow + 1, binCount)
            
            var sum = 0.0
            var n = 0
            for (b in binLow until binHigh) {
                sum += magnitudes[b]
                n++
            }
            
            val avg = if (n > 0) sum / n else 0.0
            
            // FIX: Normalisasi yang benar
            // 1. Normalize ke max magnitude global (mencegah bass mendominasi)
            val normalized = (avg / maxMag).coerceIn(0.0, 1.0)
            
            // 2. Convert ke dB scale (-60dB sampai 0dB)
            val db = if (normalized > 1e-4) {
                20.0 * log10(normalized)
            } else {
                -60.0
            }
            
            // 3. Map ke range 0.0 - 1.0 untuk visual
            val v = ((db + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
            
            // FIX: Smoothing yang lebih responsif
            val prev = smoothed[band]
            smoothed[band] = if (v > prev) {
                // Attack cepat (langsung naik saat ada suara)
                prev + (v - prev) * 0.85f
            } else {
                // Release lebih cepat (tidak "tertinggal" lama)
                prev * 0.75f + v * 0.25f
            }
            
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}