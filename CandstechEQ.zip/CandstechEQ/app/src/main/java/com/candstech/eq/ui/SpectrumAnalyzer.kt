package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import com.candstech.eq.dsp.Presets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*

class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    // Output 31 band, persis sama dengan Presets.FREQ_31
    private val _spectrum = MutableStateFlow(FloatArray(31) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(31) { 0f }
    private var running = false

    // Faktor bandwidth 1/3 Octave (2^(1/6))
    private val octaveFactor = 1.122462048309373

    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            // Gunakan ukuran maksimal (biasanya 1024) untuk resolusi bin terbaik
            vis.captureSize = range[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) onFft(fft, samplingRate)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            vis.enabled = true
            visualizer = vis
            running = true
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        try { visualizer?.enabled = false } catch (e: Exception) {}
        try { visualizer?.release() } catch (e: Exception) {}
        visualizer = null
        running = false
    }

    private fun onFft(fft: ByteArray, samplingRate: Int) {
        val binCount = fft.size / 2
        // Android Visualizer biasanya 44100Hz atau 48000Hz. Default ke 44100 jika tidak valid.
        val sr = if (samplingRate > 1000) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0

        val out = FloatArray(31)
        
        for (band in 0 until 31) {
            val centerFreq = Presets.FREQ_31[band]
            // ✅ Hitung batas bawah dan atas standar ISO 1/3 Octave
            val lowFreq = centerFreq / octaveFactor
            val highFreq = centerFreq * octaveFactor

            // Map frekuensi ke index bin FFT
            val binLow = (lowFreq / nyquist * binCount).toInt().coerceIn(0, binCount - 1)
            val binHigh = (highFreq / nyquist * binCount).toInt().coerceIn(binLow, binCount - 1)

            // Hitung energi RMS (Root Mean Square) untuk band ini
            var sumSq = 0.0
            var count = 0
            for (i in binLow..binHigh) {
                val re = fft[i * 2].toDouble()
                val im = fft[i * 2 + 1].toDouble()
                sumSq += re * re + im * im
                count++
            }
            
            val rms = if (count > 0) sqrt(sumSq / count) else 0.0
            
            // Konversi ke dB. Referensi 0dB ~ 128 (max byte magnitude)
            val db = 20.0 * log10(rms / 128.0 + 1e-5)
            
            // Normalisasi: -60dB = 0.0, 0dB = 1.0
            var v = ((db + 60.0) / 60.0).toFloat().coerceIn(0f, 1f)
            
            // Noise gate: di bawah -42dB dianggap hening
            if (v < 0.05f) v = 0f

            // Smoothing: Attack cepat, release lambat (natural)
            val prev = smoothed[band]
            smoothed[band] = if (v > prev) {
                prev + (v - prev) * 0.6f // Attack
            } else {
                prev * 0.85f + v * 0.15f // Release
            }
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}