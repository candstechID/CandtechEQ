item {
    Text("Preset cepat", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            // 🎤 VOKAL - Fokus: vokal jernih, bass & high gentle (hanya taming peaks)
            "Vokal" to listOf(
                MbcBandState("Sub", true, -18f, 1.5f, 20f, 150f, 0f),      // Sub: -18 dB (aman dari rumble)
                MbcBandState("LowMid", true, -20f, 2f, 15f, 120f, 0f),      // LowMid: kontrol muddy
                MbcBandState("Mid", true, -22f, 2.5f, 10f, 100f, 0.5f),     // Mid: kontrol harshness vokal
                MbcBandState("Hi", true, -24f, 1.5f, 8f, 90f, 0f)           // Hi: gentle sibilance
            ),
            // 🥁 DRUM - Fokus: punchy kick, snare body, cymbal control
            "Drum" to listOf(
                MbcBandState("Sub", true, -12f, 3f, 5f, 80f, 0f),           // Sub: -12 dB (biar kick lewat, cuma compress tail)
                MbcBandState("LowMid", true, -15f, 2.5f, 8f, 90f, 0f),      // LowMid: snare body
                MbcBandState("Mid", true, -18f, 2f, 10f, 100f, 0f),         // Mid: tom control
                MbcBandState("Hi", true, -20f, 2f, 5f, 70f, 0f)             // Hi: cymbal control
            ),
            // 🎛️ MASTERING - Fokus: balanced, "glue" compression yang sangat halus
            "Mastering" to listOf(
                MbcBandState("Sub", true, -14f, 2f, 20f, 200f, 0f),         // Sub: gentle sub control
                MbcBandState("LowMid", true, -16f, 2f, 15f, 180f, 0f),      // LowMid: smooth
                MbcBandState("Mid", true, -18f, 2f, 15f, 180f, 0f),         // Mid: balanced glue
                MbcBandState("Hi", true, -20f, 1.8f, 10f, 150f, 0f)         // Hi: air control
            ),
            // 🌊 SUBSONIC HARMONY - Fokus: sub-bass dalam, TIDAK di-squash
            "Subsonic" to listOf(
                MbcBandState("Sub", true, -10f, 2.0f, 30f, 200f, 0f),       // Sub: -10 dB (Hanya catch sub-bass yang benar-benar liar)
                MbcBandState("LowMid", true, -18f, 2f, 20f, 180f, 0f),      // LowMid: keep clean
                MbcBandState("Mid", true, -22f, 1.5f, 15f, 150f, 0f),       // Mid: very gentle
                MbcBandState("Hi", true, -25f, 1.5f, 10f, 120f, 0f)         // Hi: almost transparent
            )
        ).forEach { (name, preset) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(CandstechColors.Card)
                    .clickable { engine.update { st -> st.copy(mbcBands = preset, mbcEnabled = true) } }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    name,
                    color = CandstechColors.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}