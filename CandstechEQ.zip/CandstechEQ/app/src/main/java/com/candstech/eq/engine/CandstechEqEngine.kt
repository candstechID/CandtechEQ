package com.candstech.eq.engine

import android.content.Context
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Virtualizer
import android.util.Log
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.FilterType
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class MbcBandState(
    val name: String = "Sub",
    val enabled: Boolean = true,
    val thresholdDb: Float = -35f,
    val ratio: Float = 3f,
    val attackMs: Float = 10f,
    val releaseMs: Float = 100f,
    val gainDb: Float = 0f
)

class CandstechEqEngine {
    data class EqState(
        val enabled: Boolean = true,
        val preampDb: Float = 0f,
        val gains31: FloatArray = FloatArray(31),
        val gains10: List<Float> = List(10) { 0f },
        val bandCount: Int = 10,
        val parametric: List<ParametricFilter> = emptyList(),
        val autoEqFilters: List<ParametricFilter> = emptyList(),
        val autoEqStrength: Float = 1f,
        val autoEqHeadphone: String? = null,
        val bassDb: Float = 0f,
        val trebleDb: Float = 0f,
        val balance: Float = 0f,
        val stereoWidth: Float = 1f,
        val limiterEnabled: Boolean = true,
        val clarity: Float = 0f,
        val compressorEnabled: Boolean = false,
        val loudnessEnabled: Boolean = false,
        val nightMode: Boolean = false,
        val bypass: Boolean = false,
        val mbcEnabled: Boolean = false,
        val mbcBands: List<MbcBandState> = listOf(
            MbcBandState("Sub", true, -18f, 3f, 10f, 100f, 0f),
            MbcBandState("LowMid", true, -18f, 2.5f, 10f, 100f, 0f),
            MbcBandState("Mid", true, -18f, 2.5f, 8f, 90f, 0f),
            MbcBandState("Hi", true, -18f, 2f, 5f, 80f, 0f)
        ),
        val mbcCrossoverSub: Float = 120f,
        val mbcCrossoverLowMid: Float = 800f,
        val mbcCrossoverHigh: Float = 4000f
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is EqState) return false
            return enabled == other.enabled && preampDb == other.preampDb &&
                    gains31.contentEquals(other.gains31) && gains10 == other.gains10 &&
                    parametric == other.parametric && autoEqFilters == other.autoEqFilters &&
                    autoEqStrength == other.autoEqStrength && bassDb == other.bassDb &&
                    trebleDb == other.trebleDb && balance == other.balance &&
                    clarity == other.clarity && limiterEnabled == other.limiterEnabled &&
                    compressorEnabled == other.compressorEnabled &&
                    loudnessEnabled == other.loudnessEnabled && nightMode == other.nightMode &&
                    bypass == other.bypass && mbcEnabled == other.mbcEnabled && mbcBands == other.mbcBands &&
                    mbcCrossoverSub == other.mbcCrossoverSub && mbcCrossoverLowMid == other.mbcCrossoverLowMid &&
                    mbcCrossoverHigh == other.mbcCrossoverHigh && stereoWidth == other.stereoWidth
        }
        override fun hashCode(): Int {
            var r = enabled.hashCode()
            r = 31 * r + preampDb.hashCode()
            r = 31 * r + gains31.contentHashCode()
            r = 31 * r + parametric.hashCode()
            return r
        }
    }

    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state
    private var dp: DynamicsProcessing? = null
    private var virtualizer: Virtualizer? = null
    private var lastWidthApplied: Float = -1f
    private var lastConfig: DynamicsProcessing.Config? = null
    private var appContext: Context? = null

    fun current() = _state.value
    fun update(transform: (EqState) -> EqState) {
        _state.value = transform(_state.value)
        applyToHardware()
        persist()
    }
    fun attachContext(ctx: Context) { appContext = ctx.applicationContext; loadPersisted() }

    fun applyPreset(presetId: String) {
        val p = Presets.byId(presetId)
        update {
            it.copy(
                gains10 = p.gains10,
                gains31 = Presets.expandTo31(p.gains10),
                preampDb = p.preampDb,
                bandCount = 10
            )
        }
    }

    fun setBand(bandIndex: Int, gainDb: Float) {
        update {
            val new10 = it.gains10.toMutableList()
            if (bandIndex in new10.indices) new10[bandIndex] = gainDb.coerceIn(-15f, 15f)
            it.copy(gains10 = new10, gains31 = Presets.expandTo31(new10))
        }
    }

    fun setEnabled(enabled: Boolean) = update { it.copy(enabled = enabled) }
    fun setBypass(bypass: Boolean) = update { it.copy(bypass = bypass) }

    fun effectiveGains(state: EqState = _state.value): FloatArray {
        val out = state.gains31.copyOf()
        if (state.parametric.isNotEmpty()) {
            val biquads = state.parametric.filter { it.enabled }.map { BiquadFactory.from(it) }
            for (i in Presets.FREQ_31.indices) {
                var add = 0.0
                for (b in biquads) add += b.magnitudeAt(Presets.FREQ_31[i])
                out[i] = (out[i] + add).toFloat()
            }
        }
        if (state.autoEqFilters.isNotEmpty() && state.autoEqStrength > 0f) {
            val biquads = state.autoEqFilters.filter { it.enabled }.map { BiquadFactory.from(it) }
            for (i in Presets.FREQ_31.indices) {
                var add = 0.0
                for (b in biquads) add += b.magnitudeAt(Presets.FREQ_31[i])
                out[i] = (out[i] + add * state.autoEqStrength).toFloat()
            }
        }
        if (state.bassDb != 0f) {
            val b = BiquadFactory.from(ParametricFilter(FilterType.LOW_SHELF, 120.0, state.bassDb.toDouble(), 0.7))
            for (i in Presets.FREQ_31.indices) out[i] = (out[i] + b.magnitudeAt(Presets.FREQ_31[i])).toFloat()
        }
        if (state.trebleDb != 0f) {
            val b = BiquadFactory.from(ParametricFilter(FilterType.HIGH_SHELF, 8000.0, state.trebleDb.toDouble(), 0.7))
            for (i in Presets.FREQ_31.indices) out[i] = (out[i] + b.magnitudeAt(Presets.FREQ_31[i])).toFloat()
        }
        if (state.loudnessEnabled) {
            val low = BiquadFactory.from(ParametricFilter(FilterType.LOW_SHELF, 100.0, 2.5, 0.7))
            val high = BiquadFactory.from(ParametricFilter(FilterType.HIGH_SHELF, 10000.0, 1.5, 0.7))
            for (i in Presets.FREQ_31.indices) {
                out[i] = (out[i] + low.magnitudeAt(Presets.FREQ_31[i]) + high.magnitudeAt(Presets.FREQ_31[i])).toFloat()
            }
        }
        for (i in out.indices) out[i] = out[i].coerceIn(-15f, 15f)
        return out
    }

    fun channelGains(state: EqState = _state.value): Pair<Float, Float> {
        val base = state.preampDb + if (state.nightMode) -2f else 0f
        val left = (base + (-state.balance * 3f)).coerceIn(-12f, 12f)
        val right = (base + (state.balance * 3f)).coerceIn(-12f, 12f)
        return left to right
    }

    private fun applyStereoWidth(st: EqState) {
        try {
            if (st.stereoWidth == lastWidthApplied && virtualizer != null) return
            if (virtualizer == null) { virtualizer = Virtualizer(0, 0) }
            val v = virtualizer ?: return
            val w = st.stereoWidth.coerceIn(0f, 2f)
            if (w <= 1.01f) { v.enabled = false } else {
                val strength = ((w - 1f) * 1000f).toInt().coerceIn(0, 1000)
                v.enabled = true
                v.setStrength(strength.toShort())
            }
            lastWidthApplied = st.stereoWidth
        } catch (e: Exception) { Log.e("CandstechEQ", "Virtualizer gagal: ${e.message}") }
    }

    fun buildConfig(state: EqState = _state.value): DynamicsProcessing.Config {
        val eff = effectiveGains(state)
        val (leftGain, rightGain) = channelGains(state)
        val builder = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, true, Presets.FREQ_31.size, true, 4, true, 0, true
        )
        builder.setChannelTo(0, DynamicsProcessing.Channel(leftGain, true, Presets.FREQ_31.size, true, 4, true, 0, true))
        builder.setChannelTo(1, DynamicsProcessing.Channel(rightGain, true, Presets.FREQ_31.size, true, 4, true, 0, true))
        val preEq = DynamicsProcessing.Eq(true, true, eff.size)
        for (i in eff.indices) {
            preEq.setBand(i, DynamicsProcessing.EqBand(true, Presets.FREQ_31[i].toFloat(), eff[i]))
        }
        builder.setPreEqAllChannelsTo(preEq)
        builder.setInputGainAllChannelsTo(state.preampDb)

        // ✅ FIX MBC: Cutoff di-set TERPISAH via setCutoffFrequency, BUKAN di constructor MbcBand
        val mbc = DynamicsProcessing.Mbc(true, true, 4)
        val cutoffs4 = floatArrayOf(state.mbcCrossoverSub, state.mbcCrossoverLowMid, state.mbcCrossoverHigh, 20000f)
        for (i in 0 until 4) {
            val band = state.mbcBands.getOrNull(i)
            var threshold = band?.thresholdDb ?: -35f
            var ratio = band?.ratio ?: 2f
            var attack = band?.attackMs ?: 10f
            var release = band?.releaseMs ?: 100f
            var postGain = band?.gainDb ?: 0f
            val isFallbackActive = state.compressorEnabled || state.clarity > 0f || state.nightMode
            var bandEnabled = (band?.enabled ?: true) && state.mbcEnabled
            if (!state.mbcEnabled) {
                threshold = if (state.compressorEnabled) -28f else 0f
                ratio = 2f
                if (state.clarity > 0f && i != 0) { threshold = -6f - state.clarity * 12f; ratio = 2f + state.clarity * 2f }
                if (state.nightMode) { threshold = -28f; ratio = 4f }
                bandEnabled = isFallbackActive
                postGain = 0f
            }
            // ✅ Parameter ke-2 = bandwidth (bukan cutoff). Cutoff di-set terpisah di bawah.
            val b = DynamicsProcessing.MbcBand(
                bandEnabled, 1000f, attack, release, ratio, threshold,
                0f, -90f, 1f, 0f, postGain
            )
            mbc.setBand(i, b)
        }
        // ✅ FIX KRITIS: Set cutoff frequency terpisah untuk setiap band boundary
        for (i in 0 until 3) {
            try { mbc.setCutoffFrequency(i, cutoffs4[i]) } catch (_: Exception) {}
        }
        builder.setMbcAllChannelsTo(mbc)

        val limiterThreshold = if (state.nightMode) -3f else -1f
        val limiter = DynamicsProcessing.Limiter(true, state.limiterEnabled, 0, 10f, 100f, 10f, limiterThreshold, 0f)
        builder.setLimiterAllChannelsTo(limiter)
        return builder.build()
    }

    fun start() {
        try {
            if (dp != null) return
            val config = buildConfig()
            lastConfig = config
            dp = DynamicsProcessing(0, 0, config)
            dp?.setEnabled(_state.value.enabled && !_state.value.bypass)
            applyStereoWidth(_state.value)
            Log.d("CandstechEQ", "REAL DynamicsProcessing started, effGain[0]=${effectiveGains()[0]}, preamp=${_state.value.preampDb}")
        } catch (e: Exception) {
            Log.e("CandstechEQ", "Gagal start DynamicsProcessing: ${e.message}", e)
        }
    }

    fun applyToHardware() {
        try {
            val st = _state.value
            if (dp == null) { if (st.enabled) start(); return }
            val eff = effectiveGains(st)
            val (leftGain, rightGain) = channelGains(st)
            dp?.let { d ->
                for (i in eff.indices) {
                    d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, Presets.FREQ_31[i].toFloat(), eff[i]))
                }
                d.setInputGainByChannel(0, leftGain)
                d.setInputGainByChannel(1, rightGain)
                val cutoffs4 = floatArrayOf(st.mbcCrossoverSub, st.mbcCrossoverLowMid, st.mbcCrossoverHigh, 20000f)
                for (i in 0 until 4) {
                    val band = st.mbcBands.getOrNull(i)
                    var threshold = band?.thresholdDb ?: -35f
                    var ratio = band?.ratio ?: 2f
                    var attack = band?.attackMs ?: 10f
                    var release = band?.releaseMs ?: 100f
                    var postGain = band?.gainDb ?: 0f
                    val isFallbackActive = st.compressorEnabled || st.clarity > 0f || st.nightMode
                    var bandEnabled = (band?.enabled ?: true) && st.mbcEnabled
                    if (!st.mbcEnabled) {
                        threshold = if (st.compressorEnabled) -28f else 0f
                        ratio = 2f
                        if (st.clarity > 0f && i != 0) { threshold = -6f - st.clarity * 12f; ratio = 2f + st.clarity * 2f }
                        if (st.nightMode) { threshold = -28f; ratio = 4f }
                        bandEnabled = isFallbackActive
                        postGain = 0f
                    }
                    d.setMbcBandAllChannelsTo(i, DynamicsProcessing.MbcBand(
                        bandEnabled, 1000f, attack, release, ratio, threshold,
                        0f, -90f, 1f, 0f, postGain
                    ))
                }
                // ✅ FIX: Set cutoff terpisah saat applyToHardware juga
                for (i in 0 until 3) {
                    try { d.mbc setCutoffFrequency(i, cutoffs4[i]) } catch (_: Exception) {}
                }
                d.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, st.limiterEnabled, 0, 10f, 100f, 10f, if (st.nightMode) -3f else -1f, 0f))
                d.setEnabled(st.enabled && !st.bypass)
            }
            lastConfig = buildConfig(st)
        } catch (e: Exception) {
            Log.e("CandstechEQ", "apply gagal: ${e.message}")
        }
    }

    fun stop() {
        try { dp?.setEnabled(false); dp?.release() } catch (_: Exception) {}
        dp = null
    }

    fun willClip(state: EqState = _state.value): Boolean {
        val eff = effectiveGains(state)
        val maxGain = (eff.maxOrNull() ?: 0f) + state.preampDb
        return maxGain > 6f
    }

    private fun persist() {
        try {
            val ctx = appContext ?: return
            val prefs = ctx.getSharedPreferences("candstech_eq_state", Context.MODE_PRIVATE)
            val json = Gson().toJson(PersistedState(_state.value))
            prefs.edit().putString("state", json).apply()
        } catch (e: Exception) {}
    }

    private fun loadPersisted() {
        try {
            val ctx = appContext ?: return
            val json = ctx.getSharedPreferences("candstech_eq_state", Context.MODE_PRIVATE).getString("state", null) ?: return
            val p = Gson().fromJson(json, PersistedState::class.java) ?: return
            _state.value = _state.value.copy(
                preampDb = p.preampDb, gains31 = p.gains31?.toFloatArray() ?: _state.value.gains31,
                gains10 = p.gains10 ?: _state.value.gains10, parametric = p.parametric ?: emptyList(),
                autoEqFilters = p.autoEqFilters ?: emptyList(), autoEqStrength = p.autoEqStrength,
                autoEqHeadphone = p.autoEqHeadphone, bassDb = p.bassDb, trebleDb = p.trebleDb,
                balance = p.balance, clarity = p.clarity, limiterEnabled = p.limiterEnabled,
                compressorEnabled = p.compressorEnabled, loudnessEnabled = p.loudnessEnabled,
                nightMode = p.nightMode
            )
        } catch (e: Exception) {}
    }

    private data class PersistedState(
        val preampDb: Float = 0f, val gains31: List<Float>? = null, val gains10: List<Float>? = null,
        val parametric: List<ParametricFilter>? = null, val autoEqFilters: List<ParametricFilter>? = null,
        val autoEqStrength: Float = 1f, val autoEqHeadphone: String? = null,
        val bassDb: Float = 0f, val trebleDb: Float = 0f, val balance: Float = 0f,
        val clarity: Float = 0f, val limiterEnabled: Boolean = true,
        val compressorEnabled: Boolean = false, val loudnessEnabled: Boolean = false,
        val nightMode: Boolean = false
    ) {
        constructor(s: EqState) : this(
            s.preampDb, s.gains31.toList(), s.gains10, s.parametric, s.autoEqFilters, s.autoEqStrength,
            s.autoEqHeadphone, s.bassDb, s.trebleDb, s.balance, s.clarity, s.limiterEnabled,
            s.compressorEnabled, s.loudnessEnabled, s.nightMode
        )
    }

    companion object {
        val instance: CandstechEqEngine by lazy { CandstechEqEngine() }
    }
}