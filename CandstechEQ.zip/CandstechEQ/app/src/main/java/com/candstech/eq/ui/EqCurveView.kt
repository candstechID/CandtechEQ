package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import kotlin.math.ln

val ProQColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFFD600), Color(0xFFFF6EB4), Color(0xFF00E5FF), Color(0xFFFF8A00), Color(0xFFFF5252), Color(0xFFB388FF), Color(0xFF69F0AE), Color(0xFFFFAB00), Color(0xFF40C4FF))

@Composable
fun EqCurveView(
    gains31: FloatArray,
    parametric: List<ParametricFilter>,
    liveSpectrum: FloatArray = FloatArray(0),
    onParametricChange: (Int, ParametricFilter) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val totalCurve = BiquadFactory.totalCurve(gains31, Presets.FREQ_31, emptyList())
    val activeFilters = parametric.filter { it.enabled }
    val isLive = liveSpectrum.any { it > 0.05f }
    var dragIdx by remember { mutableStateOf(-1) }

    Box(modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF121216)).padding(12.dp)) {
        Column {
            // Header
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("SPECTRUM & EQ CURVE", color = CandstechColors.Grey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("20Hz — 20kHz", color = CandstechColors.GreyDark, fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))

            BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                val wPx = constraints.maxWidth.toFloat(); val hPx = constraints.maxHeight.toFloat()
                
                // ✅ KURVA EQ: Skala independen (-15dB sampai +15dB). TIDAK TERPENGARUH visualizer.
                fun xFor(freq: Double): Float = ((ln(freq) - ln(20.0)) / (ln(20000.0) - ln(20.0)) * wPx).toFloat()
                fun yForEq(db: Double): Float = (hPx / 2 - (db.coerceIn(-15.0, 15.0) / 15.0 * hPx / 2)).toFloat()
                fun freqFor(x: Float): Double = kotlin.math.exp(ln(20.0) + (x / wPx) * (ln(20000.0) - ln(20.0)))
                fun dbFor(y: Float): Double = ((hPx / 2 - y) / (hPx / 2) * 15.0).coerceIn(-15.0, 15.0)

                Canvas(modifier = Modifier.fillMaxSize().pointerInput(parametric) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            var best = -1; var bestDist = 60f
                            parametric.forEachIndexed { idx, f ->
                                if (!f.enabled) return@forEachIndexed
                                val dx = xFor(f.freqHz) - offset.x; val dy = yForEq(f.gainDb) - offset.y
                                val d = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (d < bestDist) { bestDist = d; best = idx }
                            }
                            dragIdx = best
                        },
                        onDrag = { change, _ ->
                            if (dragIdx >= 0 && dragIdx < parametric.size) {
                                val f = parametric[dragIdx]
                                onParametricChange(dragIdx, f.copy(freqHz = freqFor(change.position.x.coerceIn(0f, wPx)), gainDb = dbFor(change.position.y.coerceIn(0f, hPx))))
                            }
                        },
                        onDragEnd = { dragIdx = -1 }, onDragCancel = { dragIdx = -1 }
                    )
                }) {
                    val w = size.width; val h = size.height
                    
                    // Grid
                    for (i in 0..10) { val x = w * i / 10f; drawLine(Color(0xFF222228), Offset(x, 0f), Offset(x, h), strokeWidth = 0.7f) }
                    for (i in 0..4) { val y = h * i / 4f; drawLine(Color(0xFF222228), Offset(0f, y), Offset(w, y), strokeWidth = 0.7f) }
                    drawLine(Color(0xFF44444E), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.2f) // Garis 0dB

                    // ✅ VISUALIZER DI BELAKANG (Skala 0.0 - 1.0 dari Gamma, tidak menarik kurva EQ)
                    if (isLive && liveSpectrum.size == 31) {
                        for (i in 0 until 31) {
                            val v = liveSpectrum[i] // Sudah di-gamma di SpectrumAnalyzer
                            if (v <= 0.01f) continue
                            val freq = Presets.FREQ_31[i]
                            val xCenter = xFor(freq)
                            val nextFreq = if (i < 30) Presets.FREQ_31[i+1] else freq * 1.2
                            val xNext = xFor(nextFreq)
                            val barWidth = (xNext - xCenter).coerceAtLeast(2f)
                            
                            // Tinggi bar murni dari v (0-1), tidak peduli dB
                            val barHeight = (v.coerceIn(0f, 1f) * h * 0.95f).coerceAtLeast(2f)
                            
                            val x = xCenter - barWidth / 2
                            val y = h - barHeight
                            
                            // Warna dinamis
                            val color = when {
                                v > 0.85f -> Color(0xFFFF5252)
                                v > 0.60f -> Color(0xFFFFD600)
                                else -> Color(0xFF00E676)
                            }.copy(alpha = 0.35f) // Alpha rendah agar kurva EQ tetap terbaca
                            
                            drawRect(color = color, topLeft = Offset(x, y), size = Size(barWidth, barHeight))
                        }
                    }

                    // Filter Parametrik
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val indiv = BiquadFactory.totalCurve(FloatArray(0), Presets.FREQ_31, listOf(f))
                        val pPath = Path()
                        indiv.forEachIndexed { i2, (freq, db) -> val x = xFor(freq); val y = yForEq(db); if (i2 == 0) pPath.moveTo(x, y) else pPath.lineTo(x, y) }
                        drawPath(pPath, color = col.copy(alpha = 0.7f), style = Stroke(width = 2f, cap = StrokeCap.Round))
                    }

                    // ✅ KURVA EQ TOTAL (Paling depan, tebal, tidak tenggelam)
                    val path = Path()
                    totalCurve.forEachIndexed { idx, (freq, db) -> val x = xFor(freq); val y = yForEq(db); if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                    drawPath(path, brush = Brush.horizontalGradient(listOf(CandstechColors.GradientStart, CandstechColors.Yellow, CandstechColors.GradientEnd)), style = Stroke(width = 3.5f, cap = StrokeCap.Round))

                    // Titik Filter
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val cx = xFor(f.freqHz); val cy = yForEq(f.gainDb)
                        drawCircle(Color(0xFF121216), radius = 12f, center = Offset(cx, cy))
                        drawCircle(col, radius = 9f, center = Offset(cx, cy))
                        drawCircle(Color.White.copy(alpha = 0.8f), radius = 12f, center = Offset(cx, cy), style = Stroke(width = 1.5f))
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { 
                listOf("20", "100", "1k", "10k", "20k").forEach { Text(it, color = CandstechColors.GreyDark, fontSize = 10.sp) } 
            }
        }
    }
}