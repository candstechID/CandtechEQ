package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow

val ProQColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFFD600), Color(0xFFFF6EB4), Color(0xFF00E5FF), Color(0xFFFF8A00), Color(0xFFFF5252), Color(0xFFB388FF), Color(0xFF69F0AE), Color(0xFFFFAB00), Color(0xFF40C4FF))

// ✅ Dolby Atmos colors
val DolbyCyan = Color(0xFF00D4FF)
val DolbyBlue = Color(0xFF0066FF)
val DolbyPurple = Color(0xFF7B2FBE)

@Composable
fun EqCurveView(
    gains31: FloatArray,
    parametric: List<ParametricFilter>,
    liveSpectrum: FloatArray = FloatArray(0),
    onParametricChange: (Int, ParametricFilter) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val totalCurve = BiquadFactory.totalCurve(gains31, Presets.FREQ_31, emptyList())
    val activeFilters = parametric.filter { it.enabled }
    val isLive = liveSpectrum.any { it > 0.03f }
    var dragIdx by remember { mutableStateOf(-1) }
    
    // ✅ Peak hold untuk kurva Dolby
    val peakHold = remember { mutableStateOf(FloatArray(31) { 0f }) }
    val peakDecay = remember { mutableStateOf(FloatArray(31) { 0f }) }

    Box(modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF0A0A0F)).padding(12.dp)) {
        Column {
            // Signal Meter
            val sigPeak = if (liveSpectrum.isNotEmpty()) (liveSpectrum.maxOrNull() ?: 0f) else 0f
            val sigDb = (20f * log10(sigPeak.coerceAtLeast(1e-4f))).coerceIn(-60f, 0f)
            val sigFrac = ((sigDb + 60f) / 60f).coerceIn(0f, 1f)
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("SIGNAL", color = Color(0xFF888899), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("${"%.1f".format(sigDb)} dB", color = if (sigDb > -12f) Color(0xFFFF5252) else if (sigDb > -24f) DolbyCyan else Color(0xFF888899), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Box(modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF1A1A22))) {
                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(sigFrac).background(Brush.horizontalGradient(listOf(DolbyBlue, DolbyCyan, Color(0xFFFF5252)))))
            }
            Spacer(modifier = Modifier.height(12.dp))

            BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                val wPx = constraints.maxWidth.toFloat(); val hPx = constraints.maxHeight.toFloat()
                fun xFor(freq: Double): Float = ((ln(freq) - ln(20.0)) / (ln(20000.0) - ln(20.0)) * wPx).toFloat()
                fun yFor(db: Double): Float = (hPx - (db.coerceIn(-60.0, 0.0) / 60.0 * hPx)).toFloat()
                fun freqFor(x: Float): Double = kotlin.math.exp(ln(20.0) + (x / wPx) * (ln(20000.0) - ln(20.0)))
                fun dbFor(y: Float): Double = ((hPx - y) / hPx * 60.0 - 60.0).coerceIn(-15.0, 15.0)

                Canvas(modifier = Modifier.fillMaxSize().pointerInput(parametric) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            var best = -1; var bestDist = 60f
                            parametric.forEachIndexed { idx, f ->
                                if (!f.enabled) return@forEachIndexed
                                val dx = xFor(f.freqHz) - offset.x; val dy = yFor(f.gainDb) - offset.y
                                val d = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (d < bestDist) { bestDist = d; best = idx }
                            }
                            dragIdx = best
                        },
                        onDrag = { change, _ ->
                            if (dragIdx >= 0 && dragIdx < parametric.size) {
                                val f = parametric[dragIdx]
                                onParametricChange(dragIdx, f.copy(freqHz = freqFor(change.position.x.coerceIn(0f, wPx)), gainDb = dbFor(change.position.y.coerceIn(0f, hPx))))
                            }
                        },
                        onDragEnd = { dragIdx = -1 }, onDragCancel = { dragIdx = -1 }
                    )
                }) {
                    val w = size.width; val h = size.height
                    
                    // Grid
                    for (i in 0..10) { val x = w * i / 10f; drawLine(Color(0xFF1A1A22), Offset(x, 0f), Offset(x, h), strokeWidth = 0.5f) }
                    for (i in 0..6) { val y = h * i / 6f; drawLine(Color(0xFF1A1A22), Offset(0f, y), Offset(w, y), strokeWidth = 0.5f) }

                    // ✅ DOLBY ATMOS STYLE: Smooth curve dengan gradient
                    if (isLive && liveSpectrum.size == 31) {
                        // Update peak hold
                        val currentPeak = peakHold.value
                        val currentDecay = peakDecay.value
                        for (i in 0 until 31) {
                            if (liveSpectrum[i] > currentPeak[i]) {
                                currentPeak[i] = liveSpectrum[i]
                                currentDecay[i] = 0f
                            } else {
                                currentDecay[i] += 0.01f
                                currentPeak[i] = (currentPeak[i] - currentDecay[i]).coerceAtLeast(liveSpectrum[i])
                            }
                        }
                        peakHold.value = currentPeak
                        peakDecay.value = currentDecay

                        // Convert ke path points (smooth bezier)
                        val points = mutableListOf<Offset>()
                        val peakPoints = mutableListOf<Offset>()
                        for (i in 0 until 31) {
                            val freq = Presets.FREQ_31[i]
                            val x = xFor(freq)
                            // ✅ Scaling dB yang benar: v=1.0 → 0dB, v=0.0 → -60dB
                            val db = (liveSpectrum[i] * 60f - 60f).coerceIn(-60f, 0f)
                            val peakDb = (currentPeak[i] * 60f - 60f).coerceIn(-60f, 0f)
                            val y = yFor(db)
                            val peakY = yFor(peakDb)
                            points.add(Offset(x, y))
                            peakPoints.add(Offset(x, peakY))
                        }

                        // Draw peak hold line (dotted)
                        val peakPath = Path()
                        peakPath.moveTo(peakPoints[0].x, peakPoints[0].y)
                        for (i in 1 until peakPoints.size) {
                            val prev = peakPoints[i - 1]
                            val curr = peakPoints[i]
                            val cpx = (prev.x + curr.x) / 2f
                            peakPath.cubicTo(cpx, prev.y, cpx, curr.y, curr.x, curr.y)
                        }
                        drawPath(peakPath, color = DolbyCyan.copy(alpha = 0.3f), style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f))))

                        // Draw main curve dengan gradient fill
                        val curvePath = Path()
                        curvePath.moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            val prev = points[i - 1]
                            val curr = points[i]
                            val cpx = (prev.x + curr.x) / 2f
                            curvePath.cubicTo(cpx, prev.y, cpx, curr.y, curr.x, curr.y)
                        }
                        
                        // Fill di bawah kurva
                        val fillPath = Path()
                        fillPath.addPath(curvePath)
                        fillPath.lineTo(w, h)
                        fillPath.lineTo(0f, h)
                        fillPath.close()
                        drawPath(fillPath, brush = Brush.verticalGradient(listOf(DolbyCyan.copy(alpha = 0.15f), DolbyBlue.copy(alpha = 0.05f), Color.Transparent)))
                        
                        // Draw curve line
                        drawPath(curvePath, brush = Brush.horizontalGradient(listOf(DolbyBlue, DolbyCyan, DolbyPurple)), style = Stroke(width = 2.5f, cap = StrokeCap.Round))
                    }

                    // Parametric filters
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val indiv = BiquadFactory.totalCurve(FloatArray(0), Presets.FREQ_31, listOf(f))
                        val pPath = Path()
                        indiv.forEachIndexed { i2, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (i2 == 0) pPath.moveTo(x, y) else pPath.lineTo(x, y) }
                        drawPath(pPath, color = col.copy(alpha = 0.6f), style = Stroke(width = 1.5f, cap = StrokeCap.Round))
                    }

                    // Total EQ curve
                    val path = Path()
                    totalCurve.forEachIndexed { idx, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                    drawPath(path, color = Color(0xFFD6FF00), style = Stroke(width = 2f, cap = StrokeCap.Round))

                    // Filter knobs
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val cx = xFor(f.freqHz); val cy = yFor(f.gainDb)
                        drawCircle(Color.White, radius = 8f, center = Offset(cx, cy))
                        drawCircle(col, radius = 6f, center = Offset(cx, cy))
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { 
                listOf("20", "100", "1k", "10k", "20k").forEach { Text(it, color = Color(0xFF666677), fontSize = 9.sp) } 
            }
        }
    }
}