package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.Presets
import kotlin.math.roundToInt

@Composable
private fun VerticalFader(
    value: Float,
    onValueChange: (Float) -> Unit,
    height: Dp = 280.dp,
    modifier: Modifier = Modifier
) {
    val min = -15f
    val max = 15f

    Canvas(
        modifier = modifier
            .width(40.dp)
            .height(height)
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { onValueChange(0f) })
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    val h = size.height.toFloat()
                    val y = change.position.y.coerceIn(0f, h)
                    val raw = max - (y / h) * (max - min)
                    onValueChange(raw.roundToInt().toFloat().coerceIn(min, max))
                    change.consume()
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val trackW = 6.dp.toPx()
        val radius = CornerRadius(trackW / 2f, trackW / 2f)

        drawRoundRect(
            color = Color(0xFF2A2A2A),
            topLeft = Offset(cx - trackW / 2f, 0f),
            size = Size(trackW, h),
            cornerRadius = radius
        )

        val frac = (value - min) / (max - min)
        val centerY = h / 2f
        val valY = h - frac * h
        val top = minOf(centerY, valY)
        val bot = maxOf(centerY, valY)
        drawRoundRect(
            color = CandstechColors.Yellow,
            topLeft = Offset(cx - trackW / 2f, top),
            size = Size(trackW, (bot - top).coerceAtLeast(1f)),
            cornerRadius = radius
        )

        drawLine(
            color = Color(0xFF7A7A7A),
            start = Offset(cx - trackW, centerY),
            end = Offset(cx + trackW, centerY),
            strokeWidth = 2f
        )

        for (t in -15..15 step 5) {
            val ty = h - ((t - min) / (max - min)) * h
            drawLine(
                color = Color(0xFF444444),
                start = Offset(cx + trackW + 2.dp.toPx(), ty),
                end = Offset(w, ty),
                strokeWidth = 1.5f
            )
        }

        val thumbH = 26.dp.toPx()
        val thumbW = 30.dp.toPx()
        val thumbR = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        drawRoundRect(
            color = CandstechColors.Yellow,
            topLeft = Offset(cx - thumbW / 2f, valY - thumbH / 2f),
            size = Size(thumbW, thumbH),
            cornerRadius = thumbR
        )
        drawRoundRect(
            color = Color(0xFF000000),
            topLeft = Offset(cx - thumbW / 2f, valY - thumbH / 2f),
            size = Size(thumbW, thumbH),
            cornerRadius = thumbR,
            style = Stroke(width = 2.dp.toPx())
        )
        drawLine(
            color = Color(0xFF000000),
            start = Offset(cx - thumbW / 2f + 5.dp.toPx(), valY),
            end = Offset(cx + thumbW / 2f - 5.dp.toPx(), valY),
            strokeWidth = 2.dp.toPx()
        )
    }
}

@Composable
fun EqFaders(
    gains10: List<Float>,
    onGainChange: (Int, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Top
        ) {
            gains10.forEachIndexed { idx, gain ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(40.dp)
                ) {
                    Text(
                        text = if (gain > 0) "+${"%.0f".format(gain)}" else "%.0f".format(gain),
                        color = if (gain == 0f) CandstechColors.Grey else CandstechColors.Yellow,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    VerticalFader(
                        value = gain,
                        onValueChange = { onGainChange(idx, it) },
                        height = 280.dp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = formatFreq(Presets.FREQ_10[idx]),
                        color = CandstechColors.Grey,
                        fontSize = 10.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Geser atas-bawah untuk ubah gain. Double-tap = 0 dB.",
            color = CandstechColors.GreyDark,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

fun formatFreq(f: Double): String = if (f >= 1000) {
    "${(f / 1000).let { if (it % 1.0 == 0.0) it.toInt().toString() else "%.1f".format(it) }}k"
} else {
    "${f.toInt()}"
}