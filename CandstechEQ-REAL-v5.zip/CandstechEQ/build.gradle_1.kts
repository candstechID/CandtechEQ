// Top-level build file - Candstech EQ
// Based on Eigentone (https://github.com/Dragjon/eigentone) - GPL-3.0
// Rebranded to Candstech EQ by CandsTech.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
