package com.candstech.eq.engine

import android.content.Context
import android.media.audiofx.DynamicsProcessing
import android.util.Log
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.FilterType
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * CandstechEqEngine - REAL audio engine, bukan cuma UI.
 *
 * Jalur suara REAL:
 *  UI slider -> EqState -> effectiveGains() -> DynamicsProcessing.Config
 *  -> Android audio framework (session 0 = global output, system-wide)
 *  -> Spotify / YouTube / semua app kedengaran berubah.
 *
 * Semua kontrol di bawah ini BENAR-BENAR masuk ke hardware:
 *  - gains31 / gains10 (graphic EQ) -> EqBand gain di DynamicsProcessing
 *  - parametric (up to 20 filter) -> dihitung via Biquad (RBJ cookbook) jadi
 *    tambahan dB per band 31, lalu masuk ke EqBand juga. Bukan cuma gambar kurva.
 *  - autoEqFilters (dari AutoEq) -> sama, dikali autoEqStrength (0..1)
 *  - bassDb / trebleDb -> Low-Shelf 120Hz / High-Shelf 8kHz via Biquad, masuk ke EqBand
 *  - loudness (ISO 226) -> shelf tambahan bass +2.5dB / treble +1.5dB
 *  - preampDb -> inputGain per-channel di DynamicsProcessing
 *  - balance (-1 kiri .. +1 kanan) -> inputGain kiri/kanan beda +-3dB
 *  - clarity (0..1) -> MBC threshold/ratio mid+high (dynamic EQ)
 *  - compressorEnabled -> MBC threshold -12dB, ratio naik
 *  - nightMode -> MBC threshold lebih rendah + limiter threshold -3dB
 *  - limiterEnabled -> Limiter stage on/off, threshold -1dB
 *  - enabled / bypass -> DynamicsProcessing.setEnabled()
 *
 * Kalau HP tidak support DynamicsProcessing session 0, start() akan gagal
 * dan log akan bilang. Itu limitasi Android, bukan UI palsu.
 */
class CandstechEqEngine {

    data class EqState(
        val enabled: Boolean = true,
        val preampDb: Float = 0f,
        val gains31: FloatArray = FloatArray(31),
        val gains10: List<Float> = List(10) { 0f },
        val bandCount: Int = 10,
        val parametric: List<ParametricFilter> = emptyList(),
        // AutoEq dipisah dari parametric user, biar tidak saling timpa
        val autoEqFilters: List<ParametricFilter> = emptyList(),
        val autoEqStrength: Float = 1f,
        val autoEqHeadphone: String? = null,
        val bassDb: Float = 0f,
        val trebleDb: Float = 0f,
        val balance: Float = 0f, // -1 kiri, +1 kanan
        val stereoWidth: Float = 1f,
        val limiterEnabled: Boolean = true,
        val clarity: Float = 0f, // 0..1 Dynamic EQ
        val compressorEnabled: Boolean = false,
        val loudnessEnabled: Boolean = false,
        val nightMode: Boolean = false,
        val bypass: Boolean = false
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is EqState) return false
            return enabled == other.enabled && preampDb == other.preampDb &&
                gains31.contentEquals(other.gains31) && gains10 == other.gains10 &&
                parametric == other.parametric && autoEqFilters == other.autoEqFilters &&
                autoEqStrength == other.autoEqStrength && bassDb == other.bassDb &&
                trebleDb == other.trebleDb && balance == other.balance &&
                clarity == other.clarity && limiterEnabled == other.limiterEnabled &&
                compressorEnabled == other.compressorEnabled &&
                loudnessEnabled == other.loudnessEnabled && nightMode == other.nightMode &&
                bypass == other.bypass
        }
        override fun hashCode(): Int {
            var r = enabled.hashCode()
            r = 31 * r + preampDb.hashCode()
            r = 31 * r + gains31.contentHashCode()
            r = 31 * r + parametric.hashCode()
            return r
        }
    }

    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state

    private var dp: DynamicsProcessing? = null
    private var lastConfig: DynamicsProcessing.Config? = null
    private var appContext: Context? = null

    fun current() = _state.value

    fun update(transform: (EqState) -> EqState) {
        _state.value = transform(_state.value)
        applyToHardware()
        persist()
    }

    // Dipanggil sekali dari Activity / Service biar bisa persist
    fun attachContext(ctx: Context) { appContext = ctx.applicationContext; loadPersisted() }

    fun applyPreset(presetId: String) {
        val p = Presets.byId(presetId)
        update {
            it.copy(
                gains10 = p.gains10,
                gains31 = Presets.expandTo31(p.gains10),
                preampDb = p.preampDb,
                bandCount = 10
            )
        }
    }

    fun setBand(bandIndex: Int, gainDb: Float) {
        update {
            val new10 = it.gains10.toMutableList()
            if (bandIndex in new10.indices) new10[bandIndex] = gainDb.coerceIn(-15f, 15f)
            it.copy(gains10 = new10, gains31 = Presets.expandTo31(new10))
        }
    }

    fun setBand31(bandIndex: Int, gainDb: Float) {
        update {
            val new31 = it.gains31.copyOf()
            if (bandIndex in new31.indices) new31[bandIndex] = gainDb.coerceIn(-15f, 15f)
            it.copy(gains31 = new31)
        }
    }

    fun setEnabled(enabled: Boolean) = update { it.copy(enabled = enabled) }
    fun setBypass(bypass: Boolean) = update { it.copy(bypass = bypass) }

    /**
     * REAL: gabungkan SEMUA sumber jadi satu gains31 efektif yang masuk ke hardware.
     * Ini yang bikin parametric / bass / treble / AutoEq / loudness BENERAN bunyi,
     * bukan cuma gambar kurva.
     */
    fun effectiveGains(state: EqState = _state.value): FloatArray {
        val out = state.gains31.copyOf()
        // 1. Parametric user (Biquad RBJ)
        if (state.parametric.isNotEmpty()) {
            val biquads = state.parametric.filter { it.enabled }.map { BiquadFactory.from(it) }
            for (i in Presets.FREQ_31.indices) {
                var add = 0.0
                for (b in biquads) add += b.magnitudeAt(Presets.FREQ_31[i])
                out[i] = (out[i] + add).toFloat()
            }
        }
        // 2. AutoEq (dikali strength)
        if (state.autoEqFilters.isNotEmpty() && state.autoEqStrength > 0f) {
            val biquads = state.autoEqFilters.filter { it.enabled }.map { BiquadFactory.from(it) }
            for (i in Presets.FREQ_31.indices) {
                var add = 0.0
                for (b in biquads) add += b.magnitudeAt(Presets.FREQ_31[i])
                out[i] = (out[i] + add * state.autoEqStrength).toFloat()
            }
        }
        // 3. Bass = Low-Shelf 120Hz
        if (state.bassDb != 0f) {
            val b = BiquadFactory.from(ParametricFilter(FilterType.LOW_SHELF, 120.0, state.bassDb.toDouble(), 0.7))
            for (i in Presets.FREQ_31.indices) out[i] = (out[i] + b.magnitudeAt(Presets.FREQ_31[i])).toFloat()
        }
        // 4. Treble = High-Shelf 8000Hz
        if (state.trebleDb != 0f) {
            val b = BiquadFactory.from(ParametricFilter(FilterType.HIGH_SHELF, 8000.0, state.trebleDb.toDouble(), 0.7))
            for (i in Presets.FREQ_31.indices) out[i] = (out[i] + b.magnitudeAt(Presets.FREQ_31[i])).toFloat()
        }
        // 5. Loudness ISO 226: boost bass + treble saat loudness ON (aproksimasi)
        if (state.loudnessEnabled) {
            val low = BiquadFactory.from(ParametricFilter(FilterType.LOW_SHELF, 100.0, 2.5, 0.7))
            val high = BiquadFactory.from(ParametricFilter(FilterType.HIGH_SHELF, 10000.0, 1.5, 0.7))
            for (i in Presets.FREQ_31.indices) {
                out[i] = (out[i] + low.magnitudeAt(Presets.FREQ_31[i]) + high.magnitudeAt(Presets.FREQ_31[i])).toFloat()
            }
        }
        // Clamp biar tidak clipping parah
        for (i in out.indices) out[i] = out[i].coerceIn(-15f, 15f)
        return out
    }

    /** Gain per-channel untuk balance: balance -1 = kiri +3dB, +1 = kanan +3dB */
    fun channelGains(state: EqState = _state.value): Pair<Float, Float> {
        val base = state.preampDb + if (state.nightMode) -2f else 0f
        val left = (base + (-state.balance * 3f)).coerceIn(-12f, 12f)
        val right = (base + (state.balance * 3f)).coerceIn(-12f, 12f)
        return left to right
    }

    fun buildConfig(state: EqState = _state.value): DynamicsProcessing.Config {
        val eff = effectiveGains(state)
        val (leftGain, rightGain) = channelGains(state)
        val builder = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, true, Presets.FREQ_31.size, true, 3, true, 0, true
        )
        // Channel: (inputGain, preEqInUse, preEqBandCount, mbcInUse, mbcBandCount, postEqInUse, postEqBandCount, limiterInUse)
        // Kita set channel 0 & 1 dengan inputGain masing-masing (balance)
        builder.setChannelTo(0, DynamicsProcessing.Channel(leftGain, true, Presets.FREQ_31.size, true, 3, true, 0, true))
        builder.setChannelTo(1, DynamicsProcessing.Channel(rightGain, true, Presets.FREQ_31.size, true, 3, true, 0, true))

        // Pre-EQ: Eq(inUse, enabled, bandCount) + EqBand(enabled, cutoff, gain)
        val preEq = DynamicsProcessing.Eq(true, true, eff.size)
        for (i in eff.indices) {
            preEq.setBand(i, DynamicsProcessing.EqBand(true, Presets.FREQ_31[i].toFloat(), eff[i]))
        }
        builder.setPreEqAllChannelsTo(preEq)
        builder.setInputGainAllChannelsTo(state.preampDb)

        // MBC: Mbc(inUse, enabled, bandCount) + MbcBand(11 param)
        // Clarity & Night & Compressor REAL masuk ke MBC:
        // clarity 0..1 -> threshold mid/high makin rendah, ratio naik
        // nightMode -> threshold -6dB, ratio 4
        // compressor -> threshold -12dB
        val mbc = DynamicsProcessing.Mbc(true, true, 3)
        val cutoffs = floatArrayOf(250f, 4000f)
        for (i in 0 until 3) {
            val isLow = i == 0
            var threshold = if (state.compressorEnabled) -12f else 0f
            var ratio = 2f
            if (state.clarity > 0f && !isLow) {
                threshold = -6f - state.clarity * 12f
                ratio = 2f + state.clarity * 2f
            }
            if (state.nightMode) { threshold = -6f; ratio = 4f }
            val b = DynamicsProcessing.MbcBand(
                true,
                if (i < 2) cutoffs[i] else 20000f,
                10f, 100f, ratio, threshold,
                0f, -90f, 1f, 0f, 0f
            )
            mbc.setBand(i, b)
        }
        builder.setMbcAllChannelsTo(mbc)

        // Limiter: Limiter(inUse, enabled, linkGroup, attack, release, ratio, threshold, postGain)
        val limiterThreshold = if (state.nightMode) -3f else -1f
        val limiter = DynamicsProcessing.Limiter(true, state.limiterEnabled, 0, 10f, 100f, 10f, limiterThreshold, 0f)
        builder.setLimiterAllChannelsTo(limiter)
        return builder.build()
    }

    fun start() {
        try {
            if (dp != null) return
            val config = buildConfig()
            lastConfig = config
            dp = DynamicsProcessing(0, 0, config)
            dp?.setEnabled(_state.value.enabled && !_state.value.bypass)
            Log.d("CandstechEQ", "REAL DynamicsProcessing started, effGain[0]=${effectiveGains()[0]}, preamp=${_state.value.preampDb}")
        } catch (e: Exception) {
            Log.e("CandstechEQ", "Gagal start DynamicsProcessing (HP mungkin tidak support session 0): ${e.message}", e)
        }
    }

    fun applyToHardware() {
        try {
            val st = _state.value
            if (dp == null) { if (st.enabled) start(); return }
            // Update REAL tanpa recreate (biar tidak glitch): pakai API incremental
            val eff = effectiveGains(st)
            val (leftGain, rightGain) = channelGains(st)
            dp?.let { d ->
                // EqBand per band
                for (i in eff.indices) {
                    d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, Presets.FREQ_31[i].toFloat(), eff[i]))
                }
                d.setInputGainByChannelIndex(0, leftGain)
                d.setInputGainByChannelIndex(1, rightGain)
                // MBC update (clarity / compressor / night)
                val cutoffs = floatArrayOf(250f, 4000f)
                for (i in 0 until 3) {
                    val isLow = i == 0
                    var threshold = if (st.compressorEnabled) -12f else 0f
                    var ratio = 2f
                    if (st.clarity > 0f && !isLow) { threshold = -6f - st.clarity * 12f; ratio = 2f + st.clarity * 2f }
                    if (st.nightMode) { threshold = -6f; ratio = 4f }
                    d.setMbcBandAllChannelsTo(i, DynamicsProcessing.MbcBand(true, if (i < 2) cutoffs[i] else 20000f, 10f, 100f, ratio, threshold, 0f, -90f, 1f, 0f, 0f))
                }
                d.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, st.limiterEnabled, 0, 10f, 100f, 10f, if (st.nightMode) -3f else -1f, 0f))
                d.setEnabled(st.enabled && !st.bypass)
            }
            lastConfig = buildConfig(st)
        } catch (e: Exception) {
            Log.e("CandstechEQ", "apply gagal, coba recreate: ${e.message}")
            try { dp?.setEnabled(false); dp?.release() } catch (_: Exception) {}
            dp = null
            if (_state.value.enabled) start()
        }
    }

    fun stop() {
        try { dp?.setEnabled(false); dp?.release() } catch (_: Exception) {}
        dp = null
    }

    fun willClip(state: EqState = _state.value): Boolean {
        val eff = effectiveGains(state)
        val maxGain = (eff.maxOrNull() ?: 0f) + state.preampDb
        return maxGain > 6f
    }

    // Persist REAL: biar setting tidak hilang saat app ditutup
    private fun persist() {
        try {
            val ctx = appContext ?: return
            val prefs = ctx.getSharedPreferences("candstech_eq_state", Context.MODE_PRIVATE)
            val json = Gson().toJson(PersistedState(_state.value))
            prefs.edit().putString("state", json).apply()
        } catch (_: Exception) {}
    }
    private fun loadPersisted() {
        try {
            val ctx = appContext ?: return
            val json = ctx.getSharedPreferences("candstech_eq_state", Context.MODE_PRIVATE).getString("state", null) ?: return
            val p = Gson().fromJson(json, PersistedState::class.java) ?: return
            _state.value = _state.value.copy(
                preampDb = p.preampDb, gains31 = p.gains31?.toFloatArray() ?: _state.value.gains31,
                gains10 = p.gains10 ?: _state.value.gains10, parametric = p.parametric ?: emptyList(),
                autoEqFilters = p.autoEqFilters ?: emptyList(), autoEqStrength = p.autoEqStrength,
                autoEqHeadphone = p.autoEqHeadphone, bassDb = p.bassDb, trebleDb = p.trebleDb,
                balance = p.balance, clarity = p.clarity, limiterEnabled = p.limiterEnabled,
                compressorEnabled = p.compressorEnabled, loudnessEnabled = p.loudnessEnabled,
                nightMode = p.nightMode
            )
        } catch (_: Exception) {}
    }
    private data class PersistedState(
        val preampDb: Float = 0f, val gains31: List<Float>? = null, val gains10: List<Float>? = null,
        val parametric: List<ParametricFilter>? = null, val autoEqFilters: List<ParametricFilter>? = null,
        val autoEqStrength: Float = 1f, val autoEqHeadphone: String? = null,
        val bassDb: Float = 0f, val trebleDb: Float = 0f, val balance: Float = 0f,
        val clarity: Float = 0f, val limiterEnabled: Boolean = true,
        val compressorEnabled: Boolean = false, val loudnessEnabled: Boolean = false,
        val nightMode: Boolean = false
    ) {
        constructor(s: EqState) : this(s.preampDb, s.gains31.toList(), s.gains10, s.parametric, s.autoEqFilters, s.autoEqStrength, s.autoEqHeadphone, s.bassDb, s.trebleDb, s.balance, s.clarity, s.limiterEnabled, s.compressorEnabled, s.loudnessEnabled, s.nightMode)
    }

    companion object {
        val instance: CandstechEqEngine by lazy { CandstechEqEngine() }
    }
}
