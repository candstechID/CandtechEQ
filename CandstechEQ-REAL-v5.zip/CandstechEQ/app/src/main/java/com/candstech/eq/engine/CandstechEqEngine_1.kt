package com.candstech.eq.engine

import android.media.audiofx.DynamicsProcessing
import android.util.Log
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * CandstechEqEngine - wrapper DynamicsProcessing, turunan dari Eigentone engine/.
 * Eigentone memakai DynamicsProcessing untuk EQ system-wide tanpa root.
 * Engine ini: bangun Config dari gains 31-band + preamp + limiter + MBC + clarity.
 *
 * Catatan Android: DynamicsProcessing dengan session 0 = global output.
 * Di beberapa HP, efek global butuh service foreground + MODIFY_AUDIO_SETTINGS.
 * Jika DynamicsProcessing tidak tersedia, fallback ke Equalizer biasa di EqService.
 */
class CandstechEqEngine {

    data class EqState(
        val enabled: Boolean = true,
        val preampDb: Float = 0f,
        val gains31: FloatArray = FloatArray(31),
        val gains10: List<Float> = List(10) { 0f },
        val bandCount: Int = 10,
        val parametric: List<ParametricFilter> = emptyList(),
        val autoEqStrength: Float = 1f,
        val autoEqHeadphone: String? = null,
        val bassDb: Float = 0f,
        val trebleDb: Float = 0f,
        val balance: Float = 0f, // -1 kiri, +1 kanan
        val stereoWidth: Float = 1f,
        val limiterEnabled: Boolean = true,
        val clarity: Float = 0f,
        val compressorEnabled: Boolean = false,
        val loudnessEnabled: Boolean = false,
        val bypass: Boolean = false
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is EqState) return false
            return enabled == other.enabled && preampDb == other.preampDb && gains31.contentEquals(other.gains31)
        }
        override fun hashCode(): Int = 31 * enabled.hashCode() + preampDb.hashCode()
    }

    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state

    private var dp: DynamicsProcessing? = null
    private var lastConfig: DynamicsProcessing.Config? = null

    fun current() = _state.value

    fun update(transform: (EqState) -> EqState) {
        _state.value = transform(_state.value)
        applyToHardware()
    }

    fun applyPreset(presetId: String) {
        val p = Presets.byId(presetId)
        update {
            it.copy(
                gains10 = p.gains10,
                gains31 = Presets.expandTo31(p.gains10),
                preampDb = p.preampDb,
                bandCount = 10
            )
        }
    }

    fun setBand(bandIndex: Int, gainDb: Float) {
        update {
            val new10 = it.gains10.toMutableList()
            if (bandIndex in new10.indices) new10[bandIndex] = gainDb.coerceIn(-15f, 15f)
            it.copy(gains10 = new10, gains31 = Presets.expandTo31(new10))
        }
    }

    fun setBand31(bandIndex: Int, gainDb: Float) {
        update {
            val new31 = it.gains31.copyOf()
            if (bandIndex in new31.indices) new31[bandIndex] = gainDb.coerceIn(-15f, 15f)
            it.copy(gains31 = new31)
        }
    }

    fun setEnabled(enabled: Boolean) = update { it.copy(enabled = enabled) }
    fun setBypass(bypass: Boolean) = update { it.copy(bypass = bypass) }

    /**
     * Bangun DynamicsProcessing.Config dari state.
     * Mapping: tiap band 31-band -> DynamicsProcessing.EqBand(gain, freq)
     * Preamp -> preEq gain, Limiter -> DynamicsProcessing.Limiter
     */
    fun buildConfig(state: EqState = _state.value): DynamicsProcessing.Config {
        val builder = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, // stereo
            true, // preEq
            Presets.FREQ_31.size, // preEq bands = 31
            true, // mbc
            3, // mbc bands
            true, // postEq
            0, // postEq bands (kita pakai preEq saja)
            true // limiter
        )
        // Channel: (inputGain Float, preEqInUse Boolean, preEqBandCount Int, mbcInUse Boolean, mbcBandCount Int, postEqInUse Boolean, postEqBandCount Int, limiterInUse Boolean)
        val channel = DynamicsProcessing.Channel(0f, true, Presets.FREQ_31.size, true, 3, true, 0, true)
        builder.setChannelTo(0, channel)
        builder.setChannelTo(1, DynamicsProcessing.Channel(0f, true, Presets.FREQ_31.size, true, 3, true, 0, true))

        // Pre-EQ: Eq(inUse Boolean, enabled Boolean, bandCount Int)
        val preEq = DynamicsProcessing.Eq(true, true, state.gains31.size)
        for (i in state.gains31.indices) {
            val freq = Presets.FREQ_31[i].toFloat()
            // EqBand(enabled Boolean, cutoffFrequency Float, gain Float)
            val band = DynamicsProcessing.EqBand(true, freq, state.gains31[i])
            preEq.setBand(i, band)
        }
        builder.setPreEqAllChannelsTo(preEq)
        builder.setInputGainAllChannelsTo(state.preampDb)

        // MBC: Mbc(inUse Boolean, enabled Boolean, bandCount Int)
        val mbc = DynamicsProcessing.Mbc(true, true, 3)
        val cutoffs = floatArrayOf(250f, 4000f)
        for (i in 0 until 3) {
            // MbcBand(enabled, cutoff, attack, release, ratio, threshold, knee, noiseGate, expander, preGain, postGain) = 11 param
            val b = DynamicsProcessing.MbcBand(
                true,
                if (i < 2) cutoffs[i] else 20000f,
                10f, // attack ms
                100f, // release ms
                2f, // ratio
                if (state.compressorEnabled) -12f else 0f, // threshold
                0f, // kneeWidth
                -90f, // noiseGateThreshold
                1f, // expanderRatio
                0f, // preGain
                0f // postGain
            )
            mbc.setBand(i, b)
        }
        builder.setMbcAllChannelsTo(mbc)

        // Limiter: Limiter(inUse Boolean, enabled Boolean, linkGroup Int, attack Float, release Float, ratio Float, threshold Float, postGain Float)
        val limiter = DynamicsProcessing.Limiter(
            true,
            state.limiterEnabled,
            0, // linkGroup
            10f, // attack
            100f, // release
            10f, // ratio
            -1f, // threshold dB
            0f // postGain
        )
        builder.setLimiterAllChannelsTo(limiter)
        return builder.build()
    }

    fun start() {
        try {
            if (dp != null) return
            val config = buildConfig()
            lastConfig = config
            // Session 0 = global. Di Eigentone, session diambil dari AudioManager / service.
            dp = DynamicsProcessing(0, 0, config)
            dp?.setEnabled(_state.value.enabled && !_state.value.bypass)
            Log.d("CandstechEQ", "DynamicsProcessing started")
        } catch (e: Exception) {
            Log.e("CandstechEQ", "Gagal start DynamicsProcessing: ${e.message}", e)
        }
    }

    fun applyToHardware() {
        try {
            val st = _state.value
            val config = buildConfig(st)
            lastConfig = config
            if (dp != null) {
                // DynamicsProcessing tidak punya setProperties(config), jadi recreate dengan config baru
                try { dp?.setEnabled(false); dp?.release() } catch (_: Exception) {}
                dp = null
                if (st.enabled && !st.bypass) start()
            } else {
                if (st.enabled) start()
            }
        } catch (e: Exception) {
            Log.e("CandstechEQ", "apply gagal: ${e.message}", e)
        }
    }

    fun stop() {
        try {
            dp?.setEnabled(false)
            dp?.release()
        } catch (_: Exception) { }
        dp = null
    }

    /** Hitung apakah setting bisa clipping - warning seperti Eigentone */
    fun willClip(state: EqState = _state.value): Boolean {
        val maxGain = (state.gains31.maxOrNull() ?: 0f) + state.preampDb + state.bassDb
        return maxGain > 6f
    }

    companion object {
        // Singleton sederhana untuk dipakai Activity + Service
        val instance: CandstechEqEngine by lazy { CandstechEqEngine() }
    }
}
