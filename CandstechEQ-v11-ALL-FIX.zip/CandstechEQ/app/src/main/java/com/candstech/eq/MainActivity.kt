package com.candstech.eq

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.data.PresetStore
import com.candstech.eq.dsp.AutoEq
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import com.candstech.eq.engine.CandstechEqEngine
import com.candstech.eq.engine.EqService
import com.candstech.eq.ui.CandstechColorScheme
import com.candstech.eq.ui.CandstechColors
import com.candstech.eq.ui.EqCurveView
import com.candstech.eq.ui.EqFaders
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CandstechEqEngine.instance.attachContext(this)
        setContent {
            MaterialTheme(colorScheme = CandstechColorScheme) {
                CandstechAppScreen(
                    onStartService = { startService(Intent(this, EqService::class.java)) }
                )
            }
        }
    }
}

@Composable
fun CandstechAppScreen(onStartService: () -> Unit = {}) {
    val engine = remember { CandstechEqEngine.instance }
    val state by engine.state.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showWelcome by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) { onStartService() }

    Box(modifier = Modifier.fillMaxSize().background(CandstechColors.Black)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // HEADER - logo CandsTech, di bawah statusbar biar tidak ketiban jam/baterai
            Row(
                modifier = Modifier.fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo cropped (transparan) + ContentScale.Fit biar muat penuh, tidak kepotong atas/bawah
                Image(
                    painter = painterResource(id = R.drawable.candstech_logo_cropped),
                    contentDescription = "CandsTech",
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart,
                    modifier = Modifier.height(48.dp).weight(1f, fill = true)
                )
                Spacer(modifier = Modifier.width(12.dp))
                // Toggle ON/OFF besar
                Switch(
                    checked = state.enabled,
                    onCheckedChange = { engine.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CandstechColors.Black,
                        checkedTrackColor = CandstechColors.Yellow,
                        uncheckedThumbColor = CandstechColors.Grey,
                        uncheckedTrackColor = CandstechColors.Card
                    )
                )
            }
            Text(
                text = if (state.enabled) "EQ AKTIF  •  System-wide" else "EQ NONAKTIF",
                color = if (state.enabled) CandstechColors.Yellow else CandstechColors.Grey,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Warning clipping seperti Eigentone
            if (engine.willClip(state)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A0A0A)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = CandstechColors.Red, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Waspada: setting ini bisa clipping. Turunkan preamp / gain.", color = Color(0xFFFF8A80), fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // CONTENT per tab
            Box(modifier = Modifier.weight(1f)) {
                when (tab) {
                    0 -> EqTab(state = state, engine = engine)
                    1 -> ParametricTab(engine = engine)
                    2 -> PresetTab(engine = engine)
                    3 -> HeadphoneTab(engine = engine)
                    4 -> SettingsTab(engine)
                }
            }

            // BOTTOM NAV - 5 tab seperti Eigentone
            NavigationBar(
                containerColor = CandstechColors.Surface,
                modifier = Modifier.navigationBarsPadding()
            ) {
                val items = listOf(
                    "Equaliser" to Icons.Default.Equalizer,
                    "Parametrik" to Icons.Default.Tune,
                    "Preset" to Icons.Default.Folder,
                    "Headphone" to Icons.Default.Headphones,
                    "Pengaturan" to Icons.Default.Settings
                )
                items.forEachIndexed { idx, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == idx,
                        onClick = { tab = idx },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CandstechColors.Black,
                            selectedTextColor = CandstechColors.Yellow,
                            unselectedIconColor = CandstechColors.Grey,
                            unselectedTextColor = CandstechColors.Grey,
                            indicatorColor = CandstechColors.Yellow
                        )
                    )
                }
            }
        }

        // Welcome sheet singkat (seperti Eigentone: simple by default)
        if (showWelcome) {
            AlertDialog(
                onDismissRequest = { showWelcome = false },
                containerColor = CandstechColors.Card,
                title = { Text("Selamat datang di Candstech EQ", color = CandstechColors.White, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Equaliser system-wide untuk Spotify, YouTube & semua aplikasi.\n\n1. Nyalakan EQ di atas\n2. Pilih preset CandsTech Signature\n3. Kalau pakai headphone, buka tab Headphone & pilih modelmu untuk koreksi AutoEq.\n\nTanpa root. Tanpa iklan. Tanpa tracking.",
                        color = CandstechColors.Grey
                    )
                },
                confirmButton = {
                    Button(
                        onClick = { showWelcome = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CandstechColors.Yellow, contentColor = CandstechColors.Black)
                    ) { Text("Mulai", fontWeight = FontWeight.Bold) }
                }
            )
        }
    }
}

@Composable
fun EqTab(state: CandstechEqEngine.EqState, engine: CandstechEqEngine) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            EqCurveView(gains31 = engine.effectiveGains(state), parametric = emptyList())
        }
        item {
            // Preamp + Bypass + Undo/Redo row
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card), modifier = Modifier.weight(1f)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PREAMP  ${"%.1f".format(state.preampDb)} dB", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Slider(
                            value = state.preampDb,
                            onValueChange = { newVal -> engine.update { st -> st.copy(preampDb = newVal.coerceIn(-12f, 12f)) } },
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder)
                        )
                    }
                }
                Button(
                    onClick = { engine.setBypass(!state.bypass) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.bypass) CandstechColors.Yellow else CandstechColors.Card,
                        contentColor = if (state.bypass) CandstechColors.Black else CandstechColors.White
                    ),
                    modifier = Modifier.height(56.dp)
                ) { Text(if (state.bypass) "BYPASS ON" else "BYPASS", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
        item {
            EqFaders(
                gains10 = state.gains10,
                onGainChange = { idx, v -> engine.setBand(idx, v) }
            )
        }
        item {
            // Bass / Treble cepat
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Bass" to state.bassDb, "Treble" to state.trebleDb).forEach { (label, value) ->
                    Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card), modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("$label  ${"%.0f".format(value)} dB", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Slider(
                                value = value,
                                onValueChange = { newVal ->
                                    if (label == "Bass") engine.update { st -> st.copy(bassDb = newVal) }
                                    else engine.update { st -> st.copy(trebleDb = newVal) }
                                },
                                valueRange = -10f..10f,
                                colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder)
                            )
                        }
                    }
                }
            }
        }
        item {
            Text("Preset cepat", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Presets.ALL) { p ->
                    val selected = p.gains10 == state.gains10
                    Box(
                        modifier = Modifier.clip(RoundedCornerShape(20.dp))
                            .background(if (selected) CandstechColors.Yellow else CandstechColors.Card)
                            .clickable { engine.applyPreset(p.id) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(p.name, color = if (selected) CandstechColors.Black else CandstechColors.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun ParametricTab(engine: CandstechEqEngine) {
    val state by engine.state.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Parametric EQ — hingga 20 filter", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Bell, shelf, tilt, notch, band-pass, high/low-pass 6–48 dB/oct. Tiap filter bisa stereo / kiri / kanan, dan bisa dynamic.", color = CandstechColors.Grey, fontSize = 13.sp)
        }
        if (state.parametric.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Belum ada filter parametrik.", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                        Text("Tambah filter pertama — contoh: Bell 1kHz +2 dB Q 1.0 untuk vokal lebih maju.", color = CandstechColors.Grey, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                engine.update { st -> st.copy(parametric = st.parametric + ParametricFilter()) }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CandstechColors.Yellow, contentColor = CandstechColors.Black)
                        ) { Text("Tambah Filter", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        } else {
            items(state.parametric.size) { idx ->
                val f = state.parametric[idx]
                Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Filter ${idx + 1} • ${f.type} • ${f.freqHz.toInt()} Hz", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            TextButton(onClick = {
                                engine.update { st -> st.copy(parametric = st.parametric.filterIndexed { i, _ -> i != idx }) }
                            }) { Text("Hapus", color = CandstechColors.Red, fontSize = 12.sp) }
                        }
                        Text("Gain ${"%.1f".format(f.gainDb)} dB  •  Q ${"%.1f".format(f.q)}", color = CandstechColors.Grey, fontSize = 12.sp)
                        Slider(value = f.gainDb.toFloat(), onValueChange = { v ->
                            engine.update { st ->
                                val list = st.parametric.toMutableList()
                                list[idx] = f.copy(gainDb = v.toDouble())
                                st.copy(parametric = list)
                            }
                        }, valueRange = -15f..15f, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                        Slider(value = f.freqHz.toFloat(), onValueChange = { v ->
                            engine.update { st ->
                                val list = st.parametric.toMutableList()
                                list[idx] = f.copy(freqHz = v.toDouble())
                                st.copy(parametric = list)
                            }
                        }, valueRange = 20f..20000f, colors = SliderDefaults.colors(thumbColor = CandstechColors.Lime, activeTrackColor = CandstechColors.Lime, inactiveTrackColor = CandstechColors.CardBorder))
                    }
                }
            }
            item {
                Button(
                    onClick = { engine.update { st -> st.copy(parametric = st.parametric + ParametricFilter(freqHz = 3000.0)) } },
                    colors = ButtonDefaults.buttonColors(containerColor = CandstechColors.Yellow, contentColor = CandstechColors.Black),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Tambah Filter Lagi", fontWeight = FontWeight.Bold) }
            }
        }
        item {
            Text("Import dari file ParametricEQ / GraphicEQ (AutoEq) juga bisa dari tab Headphone & Preset.", color = CandstechColors.GreyDark, fontSize = 12.sp)
        }
    }
}

@Composable
fun PresetTab(engine: CandstechEqEngine) {
    val state by engine.state.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Preset CandsTech", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Preset dengan label kuning adalah preset khas CandsTech. Sisanya preset umum.", color = CandstechColors.Grey, fontSize = 13.sp)
        }
        items(Presets.ALL.size) { idx ->
            val p = Presets.ALL[idx]
            val selected = p.gains10 == state.gains10
            Card(
                colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF2A2A00) else CandstechColors.Card),
                modifier = Modifier.fillMaxWidth().clickable { engine.applyPreset(p.id) }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(p.name, color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (p.isCandstech) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(CandstechColors.Yellow).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                    Text("CANDSTECH", color = CandstechColors.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(p.desc, color = CandstechColors.Grey, fontSize = 12.sp)
                    }
                    if (selected) Icon(Icons.Default.Check, contentDescription = null, tint = CandstechColors.Yellow)
                }
            }
        }
        item {
            Text("Preset akan otomatis tersimpan per-output / per-app di versi penuh (lihat PresetStore).", color = CandstechColors.GreyDark, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun HeadphoneTab(engine: CandstechEqEngine) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val filtered = AutoEq.POPULAR.filter { it.contains(query, ignoreCase = true) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Koreksi Headphone (AutoEq)", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Pilih headphone-mu. Candstech EQ akan download kurva koreksi dari database AutoEq dan menyesuaikannya ke target Harman / bass yang kamu mau.", color = CandstechColors.Grey, fontSize = 13.sp)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Cari headphone… misal Sony WH-1000XM5", color = CandstechColors.GreyDark) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CandstechColors.Grey) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = CandstechColors.White,
                    unfocusedTextColor = CandstechColors.White,
                    focusedBorderColor = CandstechColors.Yellow,
                    unfocusedBorderColor = CandstechColors.CardBorder,
                    cursorColor = CandstechColors.Yellow
                )
            )
        }
        items(filtered.size) { idx ->
            val name = filtered[idx]
            val isSel = selected == name
            Card(
                colors = CardDefaults.cardColors(containerColor = if (isSel) Color(0xFF2A2A00) else CandstechColors.Card),
                modifier = Modifier.fillMaxWidth().clickable {
                    selected = name
                    status = "Mengunduh profil AutoEq untuk $name…"
                    scope.launch {
                        val prof = AutoEq.fetchProfile(name)
                        if (prof != null) {
                            val filters = AutoEq.parseParametricEQ(prof.parametricText)
                            engine.update { st -> st.copy(autoEqFilters = filters, autoEqHeadphone = name, autoEqStrength = 1f) }
                            status = "Profil $name diterapkan: ${filters.size} filter AutoEq."
                        } else {
                            status = "Gagal download. Cek internet / coba model lain. Format file AutoEq bisa di-import manual dari tab Preset."
                        }
                    }
                }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Headphones, contentDescription = null, tint = if (isSel) CandstechColors.Yellow else CandstechColors.Grey)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(name, color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
        if (status.isNotEmpty()) {
            item {
                Text(status, color = CandstechColors.Yellow, fontSize = 13.sp)
            }
        }
        item {
            Text("Target & Kekuatan", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Kekuatan koreksi 0% = tanpa koreksi, 100% = koreksi penuh AutoEq.", color = CandstechColors.Grey, fontSize = 12.sp)
            val st by engine.state.collectAsState()
            Slider(
                value = st.autoEqStrength,
                onValueChange = { newVal -> engine.update { it.copy(autoEqStrength = newVal) } },
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder)
            )
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Cek Pendengaran & Find My Sound", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("Di versi penuh Eigentone, ada hearing check per-telinga + tes A/B Find My Sound. Di build ini, hook-nya sudah disiapkan — lihat docs/HEARING_CHECK.md.", color = CandstechColors.Grey, fontSize = 13.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun SettingsTab(engine: CandstechEqEngine = CandstechEqEngine.instance) {
    val state by engine.state.collectAsState()
    var advanced by remember { mutableStateOf(false) }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Pengaturan - REAL, semua langsung ke suara", color = CandstechColors.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Bukan UI doang: tiap switch/slider di sini langsung update DynamicsProcessing.", color = CandstechColors.Grey, fontSize = 12.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Kontrol Lanjutan", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                        Switch(checked = advanced, onCheckedChange = { advanced = it }, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
                    }
                    Text("Kalau OFF, hanya setting yang kamu ubah yang tampil. Kalau ON, semua setting tampil (seperti Eigentone).", color = CandstechColors.Grey, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Clarity (Dynamic EQ)  ${"%.0f".format(state.clarity * 100)}% - REAL ke MBC", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("Masuk ke MBC threshold mid/high. Makin tinggi, harshness & boom makin ditekan saat keras.", color = CandstechColors.Grey, fontSize = 12.sp)
                    Slider(value = state.clarity, onValueChange = { v -> engine.update { it.copy(clarity = v) } }, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Balance  ${"%.2f".format(state.balance)} - REAL ke inputGain kiri/kanan", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("-1 = kiri lebih keras, +1 = kanan lebih keras. Beda gain +-3dB per channel.", color = CandstechColors.Grey, fontSize = 12.sp)
                    Slider(value = state.balance, onValueChange = { v -> engine.update { it.copy(balance = v) } }, valueRange = -1f..1f, colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder))
                }
            }
        }
        item {
            SettingSwitch("Loudness (ISO 226) - REAL", "Shelf bass +2.5dB & treble +1.5dB masuk ke EQ. Bukan cuma label.", state.loudnessEnabled) { newVal -> engine.update { st -> st.copy(loudnessEnabled = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Night Mode - REAL", "MBC threshold -6dB + limiter -3dB + preamp -2dB. Dinamika ditekan.", state.nightMode) { newVal -> engine.update { st -> st.copy(nightMode = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Compressor (MBC) - REAL", "MBC threshold -12dB. Suara keras ditekan, pelan tetap jelas.", state.compressorEnabled) { newVal -> engine.update { st -> st.copy(compressorEnabled = newVal) } }
            Spacer(modifier = Modifier.height(8.dp))
            SettingSwitch("Limiter - REAL", "Limiter stage on/off di DynamicsProcessing. Cegah clipping.", state.limiterEnabled) { newVal -> engine.update { st -> st.copy(limiterEnabled = newVal) } }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Tentang Candstech EQ - REAL Engine", color = CandstechColors.White, fontWeight = FontWeight.Bold)
                    Text("Versi 1.0.0-candstech REAL • Package com.candstech.eq\n\nEngine: Android DynamicsProcessing (session 0, system-wide).\nSemua slider -> effectiveGains() -> EqBand hardware.\nParametric & AutoEq dihitung via Biquad RBJ, bukan cuma gambar.\n\nTurunan konsep dari Eigentone oleh Dragjon (GPL-3.0).\nBranding, warna, logo & preset khas CandsTech.\nTanpa iklan, tanpa tracking, tanpa akun.", color = CandstechColors.Grey, fontSize = 13.sp)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun SettingSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CandstechColors.Card)) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = CandstechColors.White, fontWeight = FontWeight.Bold)
                Text(desc, color = CandstechColors.Grey, fontSize = 12.sp)
            }
            Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = CandstechColors.Yellow, checkedThumbColor = CandstechColors.Black))
        }
    }
}
