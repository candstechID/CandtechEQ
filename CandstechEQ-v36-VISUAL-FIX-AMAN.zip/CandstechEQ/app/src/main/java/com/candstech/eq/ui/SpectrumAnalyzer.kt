package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*
class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(32) { 0f }
    private var running = false
    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            vis.captureSize = Visualizer.getCaptureSizeRange()[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) onFft(fft, rate) }
            }, 60, false, true)
            vis.enabled = true; visualizer = vis; running = true
        } catch (e: Exception) { running = false }
    }
    fun stop() {
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null; running = false
    }
    // v36 FIX VISUAL SAJA: cuma rumus di onFft yang diubah. start()/stop() tetap persis v23 - Visualizer(0) sekali, tanpa restart, tanpa MIC, tanpa monitor. Jadi EQ tidak keganggu.
    private fun onFft(fft: ByteArray, samplingRate: Int) {
        val binCount = fft.size / 2
        if (binCount < 2) return
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0
        val out = FloatArray(32)
        for (band in 0 until 32) {
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            val binLow = ((fLow / nyquist) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / nyquist) * binCount).toInt().coerceIn(binLow + 1, binCount)
            var peak = 0.0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toDouble(); val im = fft[b * 2 + 1].toDouble()
                val mag = sqrt(re * re + im * im)
                if (mag > peak) peak = mag
            }
            if (peak < 1.0) { smoothed[band] = smoothed[band] * 0.82f; out[band] = smoothed[band]; continue }
            val db = 20.0 * log10(peak / 128.0)
            // v36: range lebih lebar -85..-15 (v23 cuma -75..-5) biar lagu pelan tetap keliatan, lagu kenceng nggak mentok
            var v = ((db + 85.0) / 70.0).coerceIn(0.0, 1.0)
            // v36: pink boost - treble di-boost biar nggak kalah sama bass (20Hz=1.0x, 20kHz=1.9x)
            val pink = 1.0 + (band / 31.0) * 0.9
            v = (v * pink).coerceIn(0.0, 1.0)
            // v36: pow 0.5 (v23 0.7) biar lebih responsif, nggak datar
            v = v.pow(0.5)
            val prev = smoothed[band].toDouble()
            // v36: naik cepat 0.95 (v23 0.85) biar beat langsung naik, turun lebih pelan 0.82 biar nggak kedip-kedip
            smoothed[band] = if (v > prev) (prev + (v - prev) * 0.95).toFloat() else (prev * 0.82 + v * 0.18).toFloat()
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
    companion object {
        fun spectrumToDbRms(v: Float): Float {
            if (v < 0.01f) return -90f
            val dbPeak = (Math.pow(v.toDouble(), 1.0 / 0.7) * 70.0 - 75.0).toFloat()
            return dbPeak - 12f
        }
    }
}
