package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*
/**
 * Spectrum Analyzer AKURAT v21
 * Fix dari v20:
 * - v20 pakai RATA-RATA magnitude + rumus (20*log10(avg/128+1)/40) -> hasil cuma 0.03, makanya datar di bawah.
 * - v21 pakai PEAK magnitude per band + dBFS beneran: db = 20*log10(peak/128), map -75dB..-5dB -> 0..1
 * - Smoothing: attack cepat (naik langsung), release pelan (turun smooth, tidak lompat)
 * - Capture 1024 (resolusi 43Hz), update 60fps, bukan 10kHz
 * - Kalau peak < 1.0 (hening) -> 0, tidak ada spektrum palsu
 */
class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val smoothed = FloatArray(32) { 0f }
    private var running = false
    fun start() {
        if (running) return
        try {
            val vis = Visualizer(0)
            // 1024 = resolusi frekuensi terbaik (512 bin, ~43Hz/bin di 44.1kHz)
            vis.captureSize = Visualizer.getCaptureSizeRange()[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) { if (fft != null) onFft(fft, rate) }
            }, 60, false, true) // 60 fps, bukan max/2 (10kHz) yang bikin UI kejang
            vis.enabled = true; visualizer = vis; running = true
        } catch (e: Exception) { running = false }
    }
    fun stop() {
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null; running = false
    }
    private fun onFft(fft: ByteArray, samplingRate: Int) {
        val binCount = fft.size / 2
        if (binCount < 2) return
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0
        val out = FloatArray(32)
        for (band in 0 until 32) {
            // Log-spaced 20Hz - 20kHz, kayak telinga manusia
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            val binLow = ((fLow / nyquist) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / nyquist) * binCount).toInt().coerceIn(binLow + 1, binCount)
            // PEAK, bukan rata-rata - biar bass kick / vokal tidak kehapus
            var peak = 0.0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toDouble()
                val im = fft[b * 2 + 1].toDouble()
                val mag = sqrt(re * re + im * im)
                if (mag > peak) peak = mag
            }
            // Hening total -> 0, jangan kasih nilai palsu
            if (peak < 1.0) {
                smoothed[band] = smoothed[band] * 0.90f
                out[band] = smoothed[band]
                continue
            }
            // dBFS beneran: peak 0..181, referensi 128. 0dB = paling keras, -75dB = hening
            val db = 20.0 * log10(peak / 128.0)
            // Map -75dB..-5dB -> 0..1. Lagu normal (-30..-10dB) jadi 0.6..0.9, keliatan jelas
            var v = ((db + 75.0) / 70.0).coerceIn(0.0, 1.0)
            // Angkat nilai kecil biar spektrum tidak kempes: pow 0.7
            v = v.pow(0.7)
            val prev = smoothed[band].toDouble()
            // Attack cepat (naik 85% langsung), release pelan (turun 10% per frame)
            smoothed[band] = if (v > prev) (prev + (v - prev) * 0.85).toFloat() else (prev * 0.90 + v * 0.10).toFloat()
            out[band] = smoothed[band]
        }
        _spectrum.value = out
    }
}
