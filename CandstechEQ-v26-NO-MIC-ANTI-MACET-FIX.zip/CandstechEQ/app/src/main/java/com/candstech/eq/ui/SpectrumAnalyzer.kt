package com.candstech.eq.ui

import android.media.audiofx.Visualizer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.*
/**
 * Spectrum v26 - NO-MIC + ANTI-MACET + ANTI-CLIP
 * v25 macet karena: kalau Visualizer berhenti ngirim FFT (ganti lagu / ganti output / sistem ambil alih),
 * tidak ada yang nurunin nilai. Spektrum ke-tahan di frame terakhir.
 * Fix v26:
 * 1. NO-MIC TOTAL: fallback mic dihapus. 100% Visualizer(0) = audio internal. Tidak ada AudioRecord.
 * 2. HEARTBEAT: catat lastFftTime. Kalau 1.2 detik tidak ada FFT baru -> auto-restart Visualizer.
 * 3. DECAY TICKER: kalau tidak ada FFT 200ms, spektrum di-decay 0.88 tiap 50ms sampai 0, jadi tidak freeze.
 * 4. ANTI-CLIP: boost dikecilin, max clamp 0.92, pow 0.6. Bass tidak mentok rata lagi.
 * 5. ANTI-SPIKE: pakai RATA-RATA magnitude per band, bukan PEAK. Treble tidak tajem jarum lagi.
 */
class SpectrumAnalyzer {
    private var visualizer: Visualizer? = null
    private val _spectrum = MutableStateFlow(FloatArray(32) { 0f })
    val spectrum: StateFlow<FloatArray> = _spectrum
    private val _status = MutableStateFlow("MENUNGGU IZIN")
    val status: StateFlow<String> = _status
    private val smoothed = FloatArray(32) { 0f }
    private var running = false
    private var scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var monitorJob: Job? = null
    private var decayJob: Job? = null
    @Volatile private var lastFftTime = 0L
    @Volatile private var restartCount = 0
    fun start() {
        if (running) return
        running = true
        _status.value = "MENCOBA VISUALIZER (INTERNAL)..."
        tryStartVisualizer()
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (running) {
                delay(200)
                val since = System.currentTimeMillis() - lastFftTime
                if (lastFftTime != 0L && since > 1200) {
                    _status.value = "VISUALIZER MACET - RESTART OTOMATIS..."
                    restartCount++
                    try { visualizer?.enabled = false } catch (_: Exception) {}
                    try { visualizer?.release() } catch (_: Exception) {}
                    visualizer = null
                    delay(200)
                    if (running) tryStartVisualizer()
                    lastFftTime = System.currentTimeMillis()
                }
            }
        }
        decayJob?.cancel()
        decayJob = scope.launch {
            while (running) {
                delay(50)
                val since = System.currentTimeMillis() - lastFftTime
                if (lastFftTime != 0L && since > 200) {
                    var any = false
                    for (i in smoothed.indices) {
                        if (smoothed[i] > 0.01f) { smoothed[i] = smoothed[i] * 0.88f; any = true }
                    }
                    if (any) _spectrum.value = smoothed.copyOf()
                    else if (_spectrum.value.any { it > 0.01f }) _spectrum.value = FloatArray(32) { 0f }
                }
            }
        }
    }
    fun restart() {
        stop()
        scope.launch { delay(300); start() }
    }
    private fun tryStartVisualizer() {
        try {
            try { visualizer?.enabled = false } catch (_: Exception) {}
            try { visualizer?.release() } catch (_: Exception) {}
            val vis = Visualizer(0)
            vis.captureSize = Visualizer.getCaptureSizeRange()[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, rate: Int) {}
                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, rate: Int) {
                    if (fft != null) onFftVisualizer(fft, rate)
                }
            }, 60, false, true)
            vis.enabled = true
            visualizer = vis
            lastFftTime = System.currentTimeMillis()
            _status.value = if (restartCount > 0) "LIVE - VISUALIZER (INTERNAL, restart ke-$restartCount)" else "LIVE - VISUALIZER (INTERNAL)"
        } catch (e: Exception) {
            _status.value = "VISUALIZER GAGAL - TAP ULANG"
        }
    }
    private fun onFftVisualizer(fft: ByteArray, samplingRate: Int) {
        lastFftTime = System.currentTimeMillis()
        val binCount = fft.size / 2
        if (binCount < 2) return
        val sr = if (samplingRate > 0) samplingRate.toDouble() else 44100.0
        val nyquist = sr / 2.0
        val out = FloatArray(32)
        for (band in 0 until 32) {
            val fLow = 20.0 * (20000.0 / 20.0).pow(band / 32.0)
            val fHigh = 20.0 * (20000.0 / 20.0).pow((band + 1) / 32.0)
            val binLow = ((fLow / nyquist) * binCount).toInt().coerceIn(1, binCount - 1)
            val binHigh = ((fHigh / nyquist) * binCount).toInt().coerceIn(binLow + 1, binCount)
            var sum = 0.0; var cnt = 0
            for (b in binLow until binHigh) {
                val re = fft[b * 2].toDouble(); val im = fft[b * 2 + 1].toDouble()
                sum += sqrt(re * re + im * im); cnt++
            }
            val avg = if (cnt > 0) sum / cnt else 0.0
            if (avg < 1.0) {
                smoothed[band] = smoothed[band] * 0.88f
                out[band] = smoothed[band]
                continue
            }
            val db = 20.0 * log10(avg / 128.0)
            var v = ((db + 82.0) / 68.0).coerceIn(0.0, 1.0)
            v = v.pow(0.6)
            val bandBoost = 1.0 + (band / 31.0) * 0.5
            v = (v * 1.15 * bandBoost).coerceIn(0.0, 0.92)
            val prev = smoothed[band].toDouble()
            smoothed[band] = if (v > prev) (prev + (v - prev) * 0.90).toFloat() else (prev * 0.85 + v * 0.15).toFloat()
            out[band] = smoothed[band]
        }
        _spectrum.value = out
        if (_status.value.startsWith("VISUALIZER MACET") || _status.value.startsWith("VISUALIZER JALAN")) {
            _status.value = "LIVE - VISUALIZER (INTERNAL)"
        }
    }
    fun stop() {
        running = false
        monitorJob?.cancel(); decayJob?.cancel()
        try { visualizer?.enabled = false } catch (_: Exception) {}
        try { visualizer?.release() } catch (_: Exception) {}
        visualizer = null
        lastFftTime = 0L
    }
    companion object {
        fun spectrumToDbRms(v: Float): Float {
            if (v < 0.01f) return -90f
            val dbPeak = (Math.pow(v.toDouble(), 1.0 / 0.7) * 70.0 - 75.0).toFloat()
            return dbPeak - 12f
        }
    }
}
