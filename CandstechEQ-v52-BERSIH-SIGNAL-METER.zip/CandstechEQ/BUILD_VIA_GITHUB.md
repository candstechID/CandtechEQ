# Build via GitHub Repo (tanpa Android Studio) — Candstech EQ

Cara paling gampang: push project ini ke GitHub, GitHub Actions akan build APK-nya otomatis. Kamu tinggal download dari HP / laptop.

## 1. Buat repo baru di GitHub

1. Buka https://github.com/new
2. **Repository name:** `candstech-eq`
3. Pilih **Public** atau **Private** (bebas, Actions gratis untuk public)
4. **JANGAN** centang "Add a README" / .gitignore / license — biar tidak konflik
5. Klik **Create repository**

## 2. Upload project ini ke repo itu

### Cara A — Via web (paling gampang, tanpa git)

1. Di halaman repo baru, klik **uploading an existing file**
2. Drag & drop isi folder `CandstechEQ` (semua file + folder `.github`) ke sana
   - Pastikan folder `.github/workflows/build.yml` ikut ke-upload. Di GitHub web, folder yang diawali titik kadang ke-hide, kalau tidak ke-upload, buat manual: klik **Add file > Create new file**, isi path `.github/workflows/build.yml`, paste isi file `build.yml` dari ZIP ini.
3. Klik **Commit changes**

### Cara B — Via terminal / git (lebih rapi)

```bash
# di dalam folder CandstechEQ yang sudah di-unzip
git init
git add -A
git commit -m "Candstech EQ v1.0.0 - rebrand Eigentone"
git branch -M main
git remote add origin https://github.com/USERNAME-KAMU/candstech-eq.git
git push -u origin main
```

Ganti `USERNAME-KAMU` dengan username GitHub kamu.

Kalau sebelumnya sudah pernah push dan mau update:
```bash
git add -A
git commit -m "Update: tambah GitHub Actions build"
git push
```

## 3. Tunggu build-nya jalan

1. Buka repo kamu > tab **Actions**
2. Kamu akan lihat workflow **"Build Candstech EQ APK"** sedang jalan (kuning / berputar)
3. Tunggu 3-7 menit sampai hijau (centang)

Kalau merah / gagal:
- Klik workflow yang gagal > klik job yang merah > baca log paling bawah
- Error paling sering: `SDK not found` / `Gradle` — biasanya hilang kalau di-Run ulang: klik **Re-run jobs > Re-run all jobs**
- Kalau masih gagal, kirim screenshot log-nya ke saya, saya betulin workflow-nya.

## 4. Download APK-nya

1. Di halaman workflow yang sudah hijau, scroll ke bawah ke bagian **Artifacts**
2. Download:
   - `CandstechEQ-debug-APK` — **pakai yang ini untuk install langsung di HP** (sudah signed debug, bisa langsung install)
   - `CandstechEQ-release-APK` — versi release
3. File-nya format `.zip`, di dalamnya ada `.apk`. Extract dulu di HP (pakai Files / ZArchiver) atau di laptop lalu pindah ke HP.
4. Di HP, buka file APK > **Install** > izinkan "Install dari sumber tidak dikenal" kalau diminta.

## 5. Install & pakai

1. Buka **Candstech EQ**
2. Izinkan notifikasi (biar service tetap jalan)
3. Nyalakan EQ
4. Pilih preset **CandsTech Signature**
5. Tab **Headphone** > pilih headphone-mu untuk AutoEq

## Untuk rilis Play Store (opsional, nanti)

Debug APK **tidak bisa** dipakai untuk update di Play Store kalau nanti mau publish. Untuk Play Store butuh Release Signed:

1. Buat keystore sekali di laptop (lihat bawah)
2. Isi Secrets di GitHub: Repo > **Settings > Secrets and variables > Actions**
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. Jalankan manual: Tab **Actions** > **Build Release Signed APK** > **Run workflow**

Cara buat keystore + base64:
```bash
keytool -genkeypair -v -keystore candstech-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias candstech
# isi password + data, JANGAN sampai hilang file ini

# di Linux/Mac:
base64 -w 0 candstech-release.jks > keystore.txt
# di Windows PowerShell:
[Convert]::ToBase64String([IO.File]::ReadAllBytes("candstech-release.jks")) | Out-File keystore.txt
# copy isi keystore.txt ke Secret KEYSTORE_BASE64
```

**PENTING:** Simpan `candstech-release.jks` + password-nya di tempat aman (jangan upload ke repo). Kalau hilang, kamu tidak bisa update app yang sama di Play Store, harus uninstall + install ulang.

## Update app ke depannya

Setiap kali kamu edit code dan `git push`, GitHub akan build APK baru otomatis. Jadi workflow-nya:
`Edit code > push > tunggu Actions hijau > download APK baru`

Tidak perlu Android Studio sama sekali untuk build.
