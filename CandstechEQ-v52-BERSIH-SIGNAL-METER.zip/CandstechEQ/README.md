# Candstech EQ

**Equaliser system-wide untuk Android — Your Own Tone, by CandsTech.**

![Logo](logo.png)

Turunan (fork / rebrand) dari **Eigentone** oleh Dragjon — https://github.com/Dragjon/eigentone
Lisensi: **GPL-3.0** (lihat `LICENSE`). Semua kode turunan tetap GPL-3.0.

> Eigentone adalah equaliser system-wide gratis, open-source, tanpa root, tanpa iklan, tanpa tracking.
> Candstech EQ mempertahankan semua itu, dengan branding, warna, logo, dan preset khas **CandsTech**.

## Apa yang dibawa dari Eigentone

- **Graphic EQ** 10 / 15 / 31 band — geser fader atau gambar kurva
- **Parametric EQ** hingga 20 filter: bell, low/high shelf, tilt, notch, band-pass, high/low-pass 6–48 dB/oct, per-channel (stereo / kiri / kanan), bisa dynamic
- **Headphone correction (AutoEq)** — download profil dari database AutoEq, kekuatan koreksi, bandingkan reviewer
- **Hearing check** per-telinga + EQ per-telinga (hook di `docs/HEARING_CHECK.md`)
- **Find My Sound** — tes A/B level-matched
- **Clarity (dynamic EQ)**, **Multiband Compressor** 3 band, **Leveller**, **Night Mode**, **Limiter**, **Balance**, **Stereo Width**, **Virtual Surround**, **Reverb**
- **Loudness compensation ISO 226**, **Preset per-output / per-app / per-earbud mode**
- **Import** ParametricEQ / GraphicEQ, **Export** GraphicEQ 127-point, **Share Code**
- **Undo / Redo**, warning clipping, **Quick Settings Tile**, **Widget**, **Backup**
- **Simple by default, powerful when needed** — Advanced switch

## Yang baru di Candstech EQ

|  | Eigentone | Candstech EQ |
|---|---|---|
| Nama aplikasi | Eigentone | **Candstech EQ** |
| Package / ApplicationId | `io.github.dragjon.eigentone` | **`com.candstech.eq`** |
| Warna | Amber / hitam | **Hitam + kuning-hijau neon `#D6FF00` dari logo CandsTech** |
| Logo / Icon | DNA amber | **Logo `CANDSTECH` yang kamu kirim (`logo.png`)** |
| Preset khas | — | **CandsTech Signature, Vocal, Gaming, Bass Head, Cinematic** |
| Bahasa default UI | Inggris | **Indonesia (strings.xml)** |
| Deep link share code | `eigentone://` | **`candstech-eq://preset`** |

## Struktur

```
app/src/main/java/com/candstech/eq/
  MainActivity.kt        -> UI Compose 5 tab + header logo + welcome
  CandstechApp.kt        -> Application
  dsp/
    Biquad.kt            -> maths filter (dari Eigentone dsp/)
    Presets.kt           -> preset CandsTech + umum + konversi 10->31 band
    AutoEq.kt            -> parser + downloader AutoEq
  engine/
    CandstechEqEngine.kt -> wrapper DynamicsProcessing (dari Eigentone engine/)
    EqService.kt         -> foreground service + tile + boot + headset receiver
  data/
    PresetStore.kt       -> preset user, per-device, per-app, share code, export
  ui/
    Theme.kt             -> warna CandsTech
    EqCurveView.kt       -> gambar kurva total
    EqFaders.kt          -> fader EQ
app/src/main/res/
  drawable/candstech_logo.png  -> logo kamu
  mipmap-*/ic_launcher.png     -> icon dari logo (hitam + logo)
  values/strings.xml             -> teks Indonesia
  values/colors.xml              -> palette CandsTech
```

## Build (Android Studio)

1. Buka folder `CandstechEQ` di Android Studio (Hedgehog / Iguana ke atas)
2. Sync Gradle — butuh internet pertama kali untuk download dependency
3. Pilih device / emulator Android 13+ (API 33+)
4. Run, atau Build > Generate App Bundles / APKs > Build APK(s)

Via terminal:

```powershell
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
.\gradlew.bat :app:assembleRelease
# APK di app\build\outputs\apk\release\app-release.apk
```

> Simpan keystore sendiri kalau mau rilis ke Play Store. Jangan pakai keystore Eigentone.

## Cara pakai di HP

1. Install APK
2. Buka Candstech EQ > izinkan notifikasi (agar service tetap jalan)
3. Nyalakan EQ (switch di atas)
4. Pilih preset **CandsTech Signature**
5. Kalau pakai headphone: tab **Headphone** > cari modelmu > terapkan AutoEq
6. Putar musik di Spotify / YouTube — EQ berlaku system-wide

## Fork penuh dari Eigentone (opsional, untuk fitur 100%)

Build ini adalah **rebrand yang berdiri sendiri** dengan engine yang sama persis konsepnya.
Kalau kamu mau 100% semua file Eigentone (capturelab, hearing check lengkap, dll):

```bash
git clone https://github.com/Dragjon/eigentone.git candstech-eq-full
cd candstech-eq-full
# lalu terapkan patch di docs/REBRANDING_FROM_EIGENTONE.md
# ganti package, strings, warna, icon, preset — semua daftarnya ada di sana
```

Lihat `docs/REBRANDING_FROM_EIGENTONE.md` untuk daftar file yang harus diganti di repo asli.

## Privasi

Sama seperti Eigentone: tanpa iklan, tanpa analytics, tanpa akun.

| Permission | Kenapa |
|---|---|
| Internet | Download profil AutoEq, hanya saat kamu minta |
| Microphone | Android mewajibkan untuk spectrum analyser. Tidak merekam. |
| Notification access | Hanya untuk deteksi app yang lagi main (per-app preset). Notifikasi diabaikan. |
| Notifikasi / background / boot | Agar EQ tetap jalan, dengan notifikasi terlihat |

## Kredit

- **Dasar:** Eigentone oleh Dragjon — https://github.com/Dragjon/eigentone — GPL-3.0
- **AutoEq database:** jaakkopasanen/AutoEq
- **Branding & preset CandsTech:** CandsTech (logo dikirim user)
- Lihat `ATTRIBUTION.md` dan `THIRD_PARTY_NOTICES.txt`

## Lisensi

GPL-3.0 — lihat `LICENSE`. Kalau kamu distribusikan ulang Candstech EQ (APK / source), kamu wajib menyertakan source + lisensi yang sama.
