# Attribution & Lisensi

Candstech EQ adalah karya turunan dari Eigentone.

- **Eigentone** — Copyright (c) Dragjon
  - Repo: https://github.com/Dragjon/eigentone
  - Lisensi: GNU General Public License v3.0 (GPL-3.0)
  - Semua kode yang berasal dari Eigentone tetap di bawah GPL-3.0.

- **AutoEq** — database pengukuran headphone
  - Repo: https://github.com/jaakkopasanen/AutoEq
  - Digunakan hanya untuk download profil koreksi saat user meminta.

- **CandsTech branding**
  - Logo `CANDSTECH` dikirim oleh pemilik brand CandsTech.
  - Warna, nama "Candstech EQ", preset "CandsTech Signature / Vocal / Gaming / Bass Head / Cinematic", dan teks Indonesia adalah karya baru CandsTech.
  - Karya baru ini juga dirilis di bawah GPL-3.0 sebagai bagian dari proyek turunan ini.

## Kewajiban GPL-3.0 (ringkas)

Jika kamu mendistribusikan Candstech EQ (APK atau source):
1. Sertakan file LICENSE ini.
2. Sertakan / tawarkan source code lengkap.
3. Pertahankan atribusi Eigentone di atas.
4. Distribusi turunan selanjutnya juga harus GPL-3.0.

Teks lengkap GPL-3.0 ada di file LICENSE.
