package com.candstech.eq.dsp

import kotlin.math.*

/**
 * Biquad filter - maths inti dari Eigentone (dsp/).
 * Dipakai untuk menghitung kurva EQ, preview, dan konversi ke DynamicsProcessing.
 * Lisensi: GPL-3.0, turunan dari Eigentone.
 */
data class Biquad(val b0: Double, val b1: Double, val b2: Double, val a1: Double, val a2: Double) {
    fun magnitudeAt(freq: Double, sampleRate: Double = 48000.0): Double {
        val w = 2 * PI * freq / sampleRate
        val cosW = cos(w)
        val cos2W = cos(2 * w)
        val sinW = sin(w)
        val sin2W = sin(2 * w)
        val numRe = b0 + b1 * cosW + b2 * cos2W
        val numIm = -b1 * sinW - b2 * sin2W
        val denRe = 1.0 + a1 * cosW + a2 * cos2W
        val denIm = -a1 * sinW - a2 * sin2W
        val num = sqrt(numRe * numRe + numIm * numIm)
        val den = sqrt(denRe * denRe + denIm * denIm)
        return 20 * log10((num / den).coerceAtLeast(1e-9))
    }
}

enum class FilterType { PEAK, LOW_SHELF, HIGH_SHELF, LOW_PASS, HIGH_PASS, NOTCH, BAND_PASS, TILT }

data class ParametricFilter(
    val type: FilterType = FilterType.PEAK,
    val freqHz: Double = 1000.0,
    val gainDb: Double = 0.0,
    val q: Double = 1.0,
    val slopeDbPerOct: Double = 12.0,
    val channel: Int = 0,
    val dynamic: Boolean = false,
    val enabled: Boolean = true
)

object BiquadFactory {
    fun from(filter: ParametricFilter, sampleRate: Double = 48000.0): Biquad {
        val A = 10.0.pow(filter.gainDb / 40.0)
        val w0 = 2 * PI * filter.freqHz / sampleRate
        val cosW0 = cos(w0)
        val alpha = sin(w0) / (2 * filter.q)
        val sqrtA = sqrt(A)
        return when (filter.type) {
            FilterType.PEAK -> {
                val b0 = 1 + alpha * A; val b1 = -2 * cosW0; val b2 = 1 - alpha * A
                val a0 = 1 + alpha / A; val a1 = -2 * cosW0; val a2 = 1 - alpha / A
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.LOW_SHELF -> {
                val b0 = A * ((A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha)
                val b1 = 2 * A * ((A - 1) - (A + 1) * cosW0)
                val b2 = A * ((A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha)
                val a0 = (A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha
                val a1 = -2 * ((A - 1) + (A + 1) * cosW0)
                val a2 = (A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.HIGH_SHELF -> {
                val b0 = A * ((A + 1) + (A - 1) * cosW0 + 2 * sqrtA * alpha)
                val b1 = -2 * A * ((A - 1) + (A + 1) * cosW0)
                val b2 = A * ((A + 1) + (A - 1) * cosW0 - 2 * sqrtA * alpha)
                val a0 = (A + 1) - (A - 1) * cosW0 + 2 * sqrtA * alpha
                val a1 = 2 * ((A - 1) - (A + 1) * cosW0)
                val a2 = (A + 1) - (A - 1) * cosW0 - 2 * sqrtA * alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.LOW_PASS -> {
                val b0 = (1 - cosW0) / 2; val b1 = 1 - cosW0; val b2 = (1 - cosW0) / 2
                val a0 = 1 + alpha; val a1 = -2 * cosW0; val a2 = 1 - alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.HIGH_PASS -> {
                val b0 = (1 + cosW0) / 2; val b1 = -(1 + cosW0); val b2 = (1 + cosW0) / 2
                val a0 = 1 + alpha; val a1 = -2 * cosW0; val a2 = 1 - alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.NOTCH -> {
                val b0 = 1.0; val b1 = -2 * cosW0; val b2 = 1.0
                val a0 = 1 + alpha; val a1 = -2 * cosW0; val a2 = 1 - alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.BAND_PASS -> {
                val b0 = alpha; val b1 = 0.0; val b2 = -alpha
                val a0 = 1 + alpha; val a1 = -2 * cosW0; val a2 = 1 - alpha
                Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
            FilterType.TILT -> {
                val tiltFilter = filter.copy(type = FilterType.LOW_SHELF, q = 0.5)
                from(tiltFilter, sampleRate)
            }
        }
    }

    fun totalCurve(
        graphicGains: FloatArray,
        graphicFreqs: DoubleArray,
        parametric: List<ParametricFilter>
    ): List<Pair<Double, Double>> {
        val probe = doubleArrayOf(20.0, 31.0, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0, 16000.0, 20000.0)
        val biquads = parametric.filter { it.enabled }.map { from(it) }
        return probe.map { f ->
            var db = 0.0
            if (graphicGains.isNotEmpty()) {
                val logF = ln(f)
                var bestIdx = 0; var bestDist = Double.MAX_VALUE
                graphicFreqs.forEachIndexed { i, gf ->
                    val d = kotlin.math.abs(ln(gf) - logF)
                    if (d < bestDist) { bestDist = d; bestIdx = i }
                }
                db += graphicGains.getOrElse(bestIdx) { 0f }.toDouble()
            }
            biquads.forEach { db += it.magnitudeAt(f) }
            f to db
        }
    }
}
