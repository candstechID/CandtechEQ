package com.candstech.eq.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.Presets
@Composable
fun VerticalSlider(value: Float, onValueChange: (Float) -> Unit, valueRange: ClosedFloatingPointRange<Float>, height: Dp = 220.dp, steps: Int = 30, modifier: Modifier = Modifier) {
    Box(modifier = modifier.height(height).width(44.dp), contentAlignment = Alignment.Center) {
        Slider(value = value, onValueChange = onValueChange, valueRange = valueRange, steps = steps,
            colors = SliderDefaults.colors(thumbColor = CandstechColors.Yellow, activeTrackColor = CandstechColors.Yellow, inactiveTrackColor = CandstechColors.CardBorder),
            modifier = Modifier.width(height).graphicsLayer { rotationZ = 270f })
    }
}
@Composable
fun EqFaders(gains10: List<Float>, onGainChange: (Int, Float) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
            gains10.forEachIndexed { idx, gain ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(44.dp)) {
                    Text(text = if (gain > 0) "+${"%.0f".format(gain)}" else "%.0f".format(gain), color = if (gain == 0f) CandstechColors.Grey else CandstechColors.Yellow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    VerticalSlider(value = gain, onValueChange = { onGainChange(idx, it) }, valueRange = -15f..15f, steps = 30, height = 220.dp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = formatFreq(Presets.FREQ_10[idx]), color = CandstechColors.Grey, fontSize = 10.sp)
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Geser atas-bawah untuk ubah gain.", color = CandstechColors.GreyDark, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}
fun formatFreq(f: Double): String = if (f >= 1000) "${(f / 1000).let { if (it % 1.0 == 0.0) it.toInt().toString() else "%.1f".format(it) }}k" else "${f.toInt()}"
