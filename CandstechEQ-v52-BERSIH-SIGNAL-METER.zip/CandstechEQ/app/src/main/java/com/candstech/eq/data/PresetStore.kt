package com.candstech.eq.data

import android.content.Context
import com.candstech.eq.dsp.EqPreset
import com.candstech.eq.dsp.Presets
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * PresetStore - simpan preset user, preset per-output, per-app, per-earbud mode.
 * Sama konsepnya dengan Eigentone data/: presets + undo + share codes.
 */
class PresetStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("candstech_eq", Context.MODE_PRIVATE)
    private val gson = Gson()

    data class SavedPreset(
        val id: String,
        val name: String,
        val gains10: List<Float>,
        val preampDb: Float,
        val createdAt: Long = System.currentTimeMillis()
    )

    data class DeviceMapping(
        val deviceName: String,
        val presetId: String
    )

    fun getUserPresets(): List<SavedPreset> {
        val json = prefs.getString("user_presets", "[]") ?: "[]"
        val type = object : TypeToken<List<SavedPreset>>() {}.type
        return try { gson.fromJson(json, type) } catch (_: Exception) { emptyList() }
    }

    fun savePreset(name: String, gains10: List<Float>, preampDb: Float): SavedPreset {
        val list = getUserPresets().toMutableList()
        val preset = SavedPreset("user_${System.currentTimeMillis()}", name, gains10, preampDb)
        list.add(preset)
        prefs.edit().putString("user_presets", gson.toJson(list)).apply()
        return preset
    }

    fun deletePreset(id: String) {
        val list = getUserPresets().filter { it.id != id }
        prefs.edit().putString("user_presets", gson.toJson(list)).apply()
    }

    fun getPresetForDevice(deviceName: String): String? {
        return prefs.getString("device_$deviceName", null)
    }

    fun setPresetForDevice(deviceName: String, presetId: String) {
        prefs.edit().putString("device_$deviceName", presetId).apply()
    }

    fun getPresetForApp(packageName: String): String? {
        return prefs.getString("app_$packageName", null)
    }

    // --- Share code: encode gains jadi string pendek (base64-like) ---
    fun encodeShareCode(gains10: List<Float>, preampDb: Float): String {
        val raw = (listOf(preampDb) + gains10).joinToString(",") { "%.1f".format(it) }
        return android.util.Base64.encodeToString(raw.toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP)
    }

    fun decodeShareCode(code: String): Pair<Float, List<Float>>? {
        return try {
            val decoded = String(android.util.Base64.decode(code, android.util.Base64.URL_SAFE))
            val parts = decoded.split(",").map { it.toFloat() }
            if (parts.size < 11) null else parts[0] to parts.drop(1)
        } catch (_: Exception) { null }
    }

    // --- Export GraphicEQ (127 point) seperti Eigentone ---
    fun exportGraphicEQ(gains31: FloatArray): String {
        val sb = StringBuilder("GraphicEQ: ")
        val freqs = Presets.FREQ_31
        for (i in freqs.indices) {
            sb.append("${freqs[i].toInt()} ${"%.2f".format(gains31[i])}; ")
        }
        return sb.toString().trim()
    }

    fun getCurrentPresetId(): String = prefs.getString("current_preset", "candstech-signature") ?: "candstech-signature"
    fun setCurrentPresetId(id: String) { prefs.edit().putString("current_preset", id).apply() }
}
