package com.candstech.eq.dsp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * AutoEq - sama seperti Eigentone: download profil dari repo AutoEq (jaakkopasanen/AutoEq)
 * Hanya dipanggil saat user memilih headphone.
 */
object AutoEq {
    data class AutoEqProfile(
        val headphoneName: String,
        val source: String,
        val parametricText: String,
        val graphicText: String = ""
    )

    val POPULAR = listOf(
        "Sony WH-1000XM5", "Sony WF-1000XM5", "Sony WH-1000XM4",
        "Apple AirPods Pro 2", "Apple AirPods Max",
        "Samsung Galaxy Buds2 Pro", "Samsung Galaxy Buds FE",
        "JBL Tune 770NC", "Anker Soundcore Q45", "Moondrop Aria",
        "KZ ZSN Pro X", "Truthear Zero", "Sennheiser HD 600", "Audio-Technica ATH-M50x"
    )

    fun parseParametricEQ(text: String): List<ParametricFilter> {
        val out = mutableListOf<ParametricFilter>()
        // Format AutoEq: Filter 1: ON PK Fc 100 Hz Gain 2.0 dB Q 1.0
        val pattern = "Filter\\s+\\d+:\\s+ON\\s+(PK|LS|HS|LP|HP|NO)\\s+Fc\\s+([0-9.]+)\\s+Hz\\s+Gain\\s+([\\-0-9.]+)\\s+dB\\s+Q\\s+([0-9.]+)"
        val regex = Regex(pattern)
        regex.findAll(text).forEach { m ->
            val type = when (m.groupValues[1]) {
                "PK" -> FilterType.PEAK
                "LS" -> FilterType.LOW_SHELF
                "HS" -> FilterType.HIGH_SHELF
                "LP" -> FilterType.LOW_PASS
                "HP" -> FilterType.HIGH_PASS
                else -> FilterType.NOTCH
            }
            out.add(
                ParametricFilter(
                    type,
                    m.groupValues[2].toDoubleOrNull() ?: 1000.0,
                    m.groupValues[3].toDoubleOrNull() ?: 0.0,
                    m.groupValues[4].toDoubleOrNull() ?: 1.0
                )
            )
        }
        return out
    }

    fun parseGraphicEQ(text: String): FloatArray {
        val pairs = Regex("([0-9.]+)\\s+([\\-0-9.]+)").findAll(text).mapNotNull {
            val f = it.groupValues[1].toDoubleOrNull()
            val g = it.groupValues[2].toFloatOrNull()
            if (f != null && g != null) f to g else null
        }.toList()
        return FloatArray(31) { i ->
            val target = Presets.FREQ_31[i]
            pairs.minByOrNull { kotlin.math.abs(kotlin.math.ln(it.first) - kotlin.math.ln(target)) }?.second ?: 0f
        }
    }

    suspend fun fetchProfile(headphone: String, source: String = "oratory1990"): AutoEqProfile? = withContext(Dispatchers.IO) {
        try {
            val slug = headphone.replace(" ", "%20")
            val url = "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results/$source/$slug/ParametricEQ.txt"
            val text = URL(url).readText()
            AutoEqProfile(headphone, source, text)
        } catch (e: Exception) {
            null
        }
    }
}
