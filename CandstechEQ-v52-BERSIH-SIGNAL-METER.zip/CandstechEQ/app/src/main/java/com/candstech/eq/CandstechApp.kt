package com.candstech.eq

import android.app.Application
import com.candstech.eq.engine.CandstechEqEngine

class CandstechApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Engine dibuat lazy, tidak langsung start sampai user nyalakan / service jalan.
    }
}
