package com.candstech.eq.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.candstech.eq.dsp.BiquadFactory
import com.candstech.eq.dsp.ParametricFilter
import com.candstech.eq.dsp.Presets
import kotlin.math.ln
val ProQColors = listOf(Color(0xFFAA55FF), Color(0xFF4AA8FF), Color(0xFF3DDC84), Color(0xFFFFD600), Color(0xFFFF6EB4), Color(0xFF00E5FF), Color(0xFFFF8A00), Color(0xFFFF5252), Color(0xFFB388FF), Color(0xFF69F0AE), Color(0xFFFFAB00), Color(0xFF40C4FF))
@Composable
fun EqCurveView(gains31: FloatArray, parametric: List<ParametricFilter>, liveSpectrum: FloatArray = FloatArray(0), onParametricChange: (Int, ParametricFilter) -> Unit = { _, _ -> }, modifier: Modifier = Modifier) {
    val totalCurve = BiquadFactory.totalCurve(gains31, Presets.FREQ_31, emptyList())
    val activeFilters = parametric.filter { it.enabled }
    val isLive = liveSpectrum.any { it > 0.02f }
    var dragIdx by remember { mutableStateOf(-1) }
    Box(modifier = modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF1A1A1E)).padding(12.dp)) {
        Column {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("KURVA SUARA  \u2022  Pro-Q Style", color = CandstechColors.Grey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("+12  \u2022  0  \u2022  -12", color = CandstechColors.GreyDark, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Text("\u25CF", color = CandstechColors.Yellow, fontSize = 10.sp); Text("Total", color = CandstechColors.Grey, fontSize = 10.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Text("\u25CF", color = if (isLive) Color(0xFF00E676) else CandstechColors.GreyDark, fontSize = 10.sp); Text("LIVE", color = CandstechColors.Grey, fontSize = 10.sp) }
                if (activeFilters.isNotEmpty()) { Text("${activeFilters.size} filter - geser titik", color = CandstechColors.Grey, fontSize = 10.sp) }
            }
            Spacer(modifier = Modifier.height(8.dp))
            // Signal Meter - ganti visualizer di kurva, taruh di atas kurva
            val sigAvg = if (liveSpectrum.isNotEmpty()) liveSpectrum.average().toFloat() else 0f
            val sigDb = (sigAvg * 40f - 40f).coerceIn(-60f, 0f)
            val sigFrac = ((sigDb + 60f) / 60f).coerceIn(0f, 1f)
            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("SIGNAL", color = CandstechColors.Grey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${"%.1f".format(sigDb)} dB", color = if (sigDb > -12f) Color(0xFFFF5252) else if (sigDb > -24f) CandstechColors.Yellow else CandstechColors.Grey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2A2A))) {
                    Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(sigFrac).background(Brush.horizontalGradient(listOf(Color(0xFF3DDC84), Color(0xFFFFD600), Color(0xFFFF5252)))))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("-60", color = CandstechColors.GreyDark, fontSize = 9.sp)
                    Text("-30", color = CandstechColors.GreyDark, fontSize = 9.sp)
                    Text("-12", color = CandstechColors.GreyDark, fontSize = 9.sp)
                    Text("0", color = CandstechColors.GreyDark, fontSize = 9.sp)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(170.dp)) {
                val wPx = constraints.maxWidth.toFloat(); val hPx = constraints.maxHeight.toFloat()
                fun xFor(freq: Double): Float = ((ln(freq) - ln(20.0)) / (ln(20000.0) - ln(20.0)) * wPx).toFloat()
                fun yFor(db: Double): Float = (hPx / 2 - (db.coerceIn(-12.0, 12.0) / 12.0 * hPx / 2)).toFloat()
                fun freqFor(x: Float): Double = kotlin.math.exp(ln(20.0) + (x / wPx) * (ln(20000.0) - ln(20.0)))
                fun dbFor(y: Float): Double = ((hPx / 2 - y) / (hPx / 2) * 12.0).coerceIn(-15.0, 15.0)
                Canvas(modifier = Modifier.fillMaxSize().pointerInput(parametric) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            var best = -1; var bestDist = 60f
                            parametric.forEachIndexed { idx, f ->
                                if (!f.enabled) return@forEachIndexed
                                val dx = xFor(f.freqHz) - offset.x; val dy = yFor(f.gainDb) - offset.y
                                val d = kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (d < bestDist) { bestDist = d; best = idx }
                            }
                            dragIdx = best
                        },
                        onDrag = { change, _ ->
                            if (dragIdx >= 0 && dragIdx < parametric.size) {
                                val f = parametric[dragIdx]
                                onParametricChange(dragIdx, f.copy(freqHz = freqFor(change.position.x.coerceIn(0f, wPx)), gainDb = dbFor(change.position.y.coerceIn(0f, hPx))))
                            }
                        },
                        onDragEnd = { dragIdx = -1 }, onDragCancel = { dragIdx = -1 }
                    )
                }) {
                    val w = size.width; val h = size.height
                    for (i in 0..10) { val x = w * i / 10f; drawLine(Color(0xFF2A2A30), Offset(x, 0f), Offset(x, h), strokeWidth = 0.7f) }
                    for (i in 0..4) { val y = h * i / 4f; drawLine(Color(0xFF2A2A30), Offset(0f, y), Offset(w, y), strokeWidth = 0.7f) }
                    drawLine(Color(0xFF55555E), Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.2f)
                    // Visualizer di kurva dihapus - ganti Signal Meter di atas kurva
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val indiv = BiquadFactory.totalCurve(FloatArray(0), Presets.FREQ_31, listOf(f))
                        val pPath = Path()
                        indiv.forEachIndexed { i2, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (i2 == 0) pPath.moveTo(x, y) else pPath.lineTo(x, y) }
                        val fill = Path().apply { addPath(pPath); lineTo(w, h / 2); lineTo(0f, h / 2); close() }
                        drawPath(fill, brush = Brush.verticalGradient(listOf(col.copy(alpha = 0.22f), Color.Transparent)))
                        drawPath(pPath, color = col.copy(alpha = 0.85f), style = Stroke(width = 2f, cap = StrokeCap.Round))
                    }
                    val path = Path()
                    totalCurve.forEachIndexed { idx, (freq, db) -> val x = xFor(freq); val y = yFor(db); if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                    drawPath(path, brush = Brush.horizontalGradient(listOf(CandstechColors.GradientStart, CandstechColors.Yellow, CandstechColors.GradientEnd)), style = Stroke(width = 3f, cap = StrokeCap.Round))
                    val fillPath = Path().apply { addPath(path); lineTo(w, h / 2); lineTo(0f, h / 2); close() }
                    drawPath(fillPath, brush = Brush.verticalGradient(listOf(CandstechColors.Yellow.copy(alpha = 0.10f), Color.Transparent)))
                    parametric.forEachIndexed { idx, f ->
                        if (!f.enabled) return@forEachIndexed
                        val col = ProQColors[idx % ProQColors.size]
                        val cx = xFor(f.freqHz); val cy = yFor(f.gainDb)
                        drawCircle(Color.White, radius = 11f, center = Offset(cx, cy))
                        drawCircle(col, radius = 8f, center = Offset(cx, cy))
                        drawCircle(Color.White.copy(alpha = 0.6f), radius = 11f, center = Offset(cx, cy), style = Stroke(width = 1.5f))
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("20", "100", "1k", "10k", "20k").forEach { Text(it, color = CandstechColors.GreyDark, fontSize = 10.sp) } }
        }
    }
}
