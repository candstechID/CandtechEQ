package com.candstech.eq.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.candstech.eq.MainActivity
import com.candstech.eq.R

/**
 * Foreground service agar EQ tetap jalan saat app ditutup.
 * Sama seperti Eigentone: notification visible, start at boot, Quick Settings tile.
 */
class EqService : Service() {
    companion object {
        const val CHANNEL_ID = "candstech_eq"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.candstech.eq.START"
        const val ACTION_STOP = "com.candstech.eq.STOP"
        const val ACTION_TOGGLE = "com.candstech.eq.TOGGLE"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                CandstechEqEngine.instance.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                val cur = CandstechEqEngine.instance.current()
                CandstechEqEngine.instance.setEnabled(!cur.enabled)
                updateNotification()
                return START_STICKY
            }
            else -> {
                CandstechEqEngine.instance.attachContext(this)
                CandstechEqEngine.instance.start()
                startForeground(NOTIF_ID, buildNotification())
                return START_STICKY
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Candstech EQ", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Equaliser system-wide Candstech EQ sedang aktif"
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this, 1, Intent(this, EqService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, EqService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val enabled = CandstechEqEngine.instance.current().enabled
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Candstech EQ — ${if (enabled) "AKTIF" else "NONAKTIF"}")
            .setContentText("Equaliser system-wide sedang berjalan. Ketuk untuk buka.")
            .setContentIntent(openIntent)
            .addAction(0, if (enabled) "Matikan" else "Nyalakan", toggleIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification() {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIF_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences("candstech_eq", Context.MODE_PRIVATE)
            if (prefs.getBoolean("auto_start", true)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(Intent(context, EqService::class.java))
                } else {
                    context.startService(Intent(context, EqService::class.java))
                }
            }
        }
    }
}

class HeadsetReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // REAL: headset tersambung / lepas -> re-apply EQ ke hardware (session baru)
        if (intent?.action == android.media.AudioManager.ACTION_HEADSET_PLUG) {
            val plugged = intent.getIntExtra("state", 0) == 1
            android.util.Log.d("CandstechEQ", "Headset plugged=" + plugged)
            CandstechEqEngine.instance.applyToHardware()
        }
    }
}

class CandstechTileService : android.service.quicksettings.TileService() {
    override fun onClick() {
        super.onClick()
        val engine = CandstechEqEngine.instance
        engine.setEnabled(!engine.current().enabled)
        qsTile?.state = if (engine.current().enabled) android.service.quicksettings.Tile.STATE_ACTIVE else android.service.quicksettings.Tile.STATE_INACTIVE
        qsTile?.updateTile()
        startService(Intent(this, EqService::class.java))
    }
}
