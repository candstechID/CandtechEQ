package com.candstech.eq.ui

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

/**
 * Tema CandsTech - hitam pekat + kuning-hijau neon dari logo.
 * Logo: CANDSTECH dengan gradasi #F2FF00 -> #7AC400 di atas #000000.
 */
object CandstechColors {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF0A0A0A)
    val Card = Color(0xFF141414)
    val CardBorder = Color(0xFF2A2A2A)
    val Yellow = Color(0xFFD6FF00)
    val YellowMid = Color(0xFFC6E500)
    val Lime = Color(0xFFA8D600)
    val GreenDark = Color(0xFF5A7A00)
    val White = Color(0xFFFFFFFF)
    val Grey = Color(0xFF9E9E9E)
    val GreyDark = Color(0xFF6A6A6A)
    val Red = Color(0xFFFF3B30)
    val GradientStart = Color(0xFFF2FF00)
    val GradientEnd = Color(0xFF7AC400)
}

val CandstechColorScheme = darkColorScheme(
    primary = CandstechColors.Yellow,
    onPrimary = CandstechColors.Black,
    secondary = CandstechColors.Lime,
    background = CandstechColors.Black,
    surface = CandstechColors.Surface,
    onBackground = CandstechColors.White,
    onSurface = CandstechColors.White,
    surfaceVariant = CandstechColors.Card,
    onSurfaceVariant = CandstechColors.Grey,
    error = CandstechColors.Red
)
