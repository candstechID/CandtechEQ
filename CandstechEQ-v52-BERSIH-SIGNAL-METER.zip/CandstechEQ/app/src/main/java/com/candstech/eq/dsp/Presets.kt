package com.candstech.eq.dsp

/**
 * Preset bawaan Candstech EQ.
 * 10-band: 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
 */
data class EqPreset(
    val id: String,
    val name: String,
    val desc: String,
    val gains10: List<Float>,
    val preampDb: Float = 0f,
    val isCandstech: Boolean = false
)

object Presets {
    val FREQ_10 = doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)
    val FREQ_15 = doubleArrayOf(25.0, 40.0, 63.0, 100.0, 160.0, 250.0, 400.0, 630.0, 1000.0, 1600.0, 2500.0, 4000.0, 6300.0, 10000.0, 16000.0)
    val FREQ_31 = doubleArrayOf(20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0, 800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0, 16000.0, 20000.0)

    fun expandTo31(gains10: List<Float>): FloatArray {
        val out = FloatArray(31)
        for (i in 0 until 31) {
            val f = FREQ_31[i]
            var idx = 0
            for (j in FREQ_10.indices) if (FREQ_10[j] <= f) idx = j
            val next = (idx + 1).coerceAtMost(9)
            val denom = kotlin.math.ln(FREQ_10[next]) - kotlin.math.ln(FREQ_10[idx])
            val t = if (denom == 0.0) 0.0 else (kotlin.math.ln(f) - kotlin.math.ln(FREQ_10[idx])) / denom
            out[i] = (gains10[idx] + (gains10[next] - gains10[idx]) * t.toFloat()).coerceIn(-15f, 15f)
        }
        return out
    }

    val ALL = listOf(
        EqPreset("candstech-signature", "CandsTech Signature", "V-shape halus, enak buat semua lagu. Preset utama CandsTech.", listOf(2.5f, 2.0f, 1.0f, 0f, -0.5f, -0.5f, 0f, 1.0f, 2.0f, 2.5f), -1f, true),
        EqPreset("candstech-vocal", "CandsTech Vocal", "Vokal maju, podcast & lagu akustik lebih jelas.", listOf(-1f, -1f, 0f, 0.5f, 1.5f, 2.5f, 2.5f, 1.5f, 0.5f, 0f), 0f, true),
        EqPreset("candstech-gaming", "CandsTech Gaming", "Footstep & clarity untuk game FPS.", listOf(-1f, 0f, 0f, 0f, 0.5f, 1.0f, 2.0f, 3.0f, 2.0f, 1.0f), -1f, true),
        EqPreset("candstech-bass", "CandsTech Bass Head", "Bass dalam, tetap rapi. Buat EDM / hip-hop.", listOf(5f, 4.5f, 3.5f, 2f, 0.5f, 0f, 0f, 0.5f, 1f, 1f), -2f, true),
        EqPreset("candstech-cinematic", "CandsTech Cinematic", "Lebar & megah buat nonton film.", listOf(3f, 2.5f, 1.5f, 0.5f, 0f, 0f, 0.5f, 1f, 1.5f, 2f), -1f, true),
        EqPreset("flat", "Flat", "Tanpa perubahan. Titik awal yang jujur.", listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f), 0f),
        EqPreset("bass", "Bass Boost", "Naikkan low-end.", listOf(4f, 3.5f, 2.5f, 1.5f, 0.5f, 0f, 0f, 0f, 0f, 0f), -1f),
        EqPreset("treble", "Treble Boost", "Detail & air di atas.", listOf(0f, 0f, 0f, 0f, 0f, 0.5f, 1f, 2f, 3f, 3.5f), -1f),
        EqPreset("v-shape", "V-Shape", "Bass + treble, mid mundur.", listOf(3f, 2.5f, 1.5f, 0f, -1f, -1.5f, -1f, 0.5f, 2f, 3f), -1f),
        EqPreset("rock", "Rock", "Gitar & drum lebih galak.", listOf(2f, 1.5f, 0.5f, -0.5f, -1f, 0f, 1f, 2f, 2.5f, 2f), 0f),
        EqPreset("pop", "Pop", "Vokal pop maju.", listOf(0f, 0.5f, 1f, 1.5f, 2f, 2f, 1.5f, 1f, 0.5f, 0f), 0f),
        EqPreset("jazz", "Jazz", "Hangat, smooth.", listOf(1f, 1f, 0.5f, 0f, -0.5f, 0f, 0.5f, 1f, 1.5f, 1f), 0f),
        EqPreset("classical", "Classical", "Dinamis, natural.", listOf(0f, 0f, 0.5f, 0f, 0f, 0f, 0f, 0.5f, 1f, 1.5f), 0f),
        EqPreset("podcast", "Podcast / Vocal", "Potong bass, vokal jernih.", listOf(-3f, -2f, -1f, 0f, 1f, 2f, 2f, 1.5f, 1f, 0f), 0f)
    )
    fun byId(id: String) = ALL.firstOrNull { it.id == id } ?: ALL.first()
}
