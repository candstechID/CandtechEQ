# Keep the DynamicsProcessing engine, do not obfuscate its class names
-keep class com.candstech.eq.engine.** { *; }
-keep class com.candstech.eq.dsp.** { *; }
